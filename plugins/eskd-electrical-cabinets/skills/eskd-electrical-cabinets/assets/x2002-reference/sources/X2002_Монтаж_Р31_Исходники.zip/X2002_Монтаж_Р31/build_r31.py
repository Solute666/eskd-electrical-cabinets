#!/usr/bin/env python3
"""X2002 R31: lower UZ1, add connecting duct, extend DIN2."""
from pathlib import Path
import argparse, copy, json, math, sys
from collections import defaultdict

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'src'))
import draw
import fitz

OUT = ROOT / 'output'
QA = ROOT / 'qa'
OUT.mkdir(exist_ok=True); QA.mkdir(exist_ok=True)
draw.OUT = OUT
CFG = json.loads((ROOT / 'data/cabinet_R29.json').read_text())
OLD = json.loads((ROOT / 'data/layout_positions_R30.json').read_text())
MODEL = json.loads((ROOT / 'data/mount_model_R29.json').read_text())
CFG['rail_y'] = [110, 290, 515, 740, 920]
CFG['duct_y'] = [20, 200, 380, 650, 830]

def dump(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2))

def fmt(v):
    return f'{v:g}'.replace('.', ',')

def prepare():
    g = copy.deepcopy(OLD)
    g.update(revision=31, modified_sheets=[1])
    for a in g['placements']:
        if a['tag']=='UZ1':a['y']=373
        if a['tag']=='KSR1':a['x']=440
        if a['tag'] in ['G1','A1','A2','A3','A4']:a['x']=round(a['x']-15,4)
    for r in g['rails']:
        if r['tag'] in ['DIN2','DIN3']:r['w']=430
    for d in g['ducts']:
        if d['tag']=='К3':d['w']=440
    g['ducts'].append({'tag':'КВ3','x':480,'y':220,'w':40,'h':410})
    g['changes_R31']={
        'UZ1': 'Y 270 → 373; нижняя грань Y=580, до короба К4 50 мм.',
        'КВ3': 'Новый короб 40×60: X=480, Y=220, L=410; соединяет К2, К3, К4.',
        'DIN2': 'X=45, L=430; конец X=475, зазор до КВ3 5 мм.',
        'DIN3': 'X=45, L=430; укорочена перед КВ3. Группа G1/A1–A4 смещена на 15 мм влево; KSR1 X=440.',
        'PLC_sides': 'Паспорт AS, §4.3.1: >50 мм до корпуса шкафа. Внутренние боковые резервы модели 35 слева и 30 справа; не заявлены как паспортный минимум до соседних аппаратов.'}
    budget={
        'scope':'Расход нарезных деталей панели ШС. Закупочные количества Р29 сохранены.',
        'rail_m_per_cabinet':round(sum(r['w'] for r in g['rails'])/1000,3),
        'duct_40x60_m_per_cabinet':round(sum(max(d['w'],d['h']) for d in g['ducts'] if d['w']!=60)/1000,3),
        'duct_60x80_m_per_cabinet':1.15,
        'procurement_changed':False,
        'duct_40x60_purchase_m_two_cabinets':10,
        'cut_plan_40x60_mm_two_cabinets':[[1150,650],[1150,650],[650,650,650],[650,650,650],[440,440,410,410]],
        'rail_purchase_mm': [2000,2000,2000,2000],
        'cut_plan_rail_mm_two_cabinets':[[635,635,635],[635,635,635],[430,430,430,430]],
        'wire_cut_lengths':'По фактической трассе; ведомость отрезков не сформирована.'}
    dump(ROOT/'data/layout_positions_R31.json',g)
    dump(QA/'materials_R31.json',budget)
    return g,budget

def table(s,x,y,widths,heads,rows,rh=11,h=2.5):
    for i,row in enumerate([heads]+rows):
        lines=[s.wrap('' if v is None else str(v),w-4,h,i==0) for v,w in zip(row,widths)]
        height=max(rh,max(map(len,lines))*5.1+4)
        xx=x
        for txt,w in zip(lines,widths):
            s.rect(xx,y,w,height,.2,'NOTES')
            for j,line in enumerate(txt):s.t(xx+2,y+5.5+j*5.1,line,h,i==0)
            xx+=w
        y+=height
    return y

def dim(s,x1,y1,x2,y2,label,h=2.5):
    s.ln(x1,y1,x2,y2,.18,'MECHANICAL')
    for x,y in [(x1,y1),(x2,y2)]:s.ln(x-1.3,y+1.3,x+1.3,y-1.3,.22,'MECHANICAL')
    if abs(y1-y2)<1e-7:s.t((x1+x2)/2,y1-2,label,h,a='center')
    else:s.t(x1-2.4,(y1+y2)/2,label,h,a='center',rot=90)

def clearance_zones(g):
    by_tag={a['tag']:a for a in g['placements']}
    definitions=[(['G1','A1','A2','A3','A4'],[35,50,30,50]),
                 (['G2'],[5,40,5,20]),(['KSR1'],[5,50,5,50]),(['UZ1'],[30,50,30,50])]
    zones=[]
    for members,(left,top,right,bottom) in definitions:
        bodies=[by_tag[t] for t in members]
        x=min(a['x'] for a in bodies)-left;y=min(a['y'] for a in bodies)-top
        x2=max(a['x']+a['w'] for a in bodies)+right;y2=max(a['y']+a['h'] for a in bodies)+bottom
        zones.append({'tag':'/'.join(members),'members':members,'x':x,'y':y,'w':x2-x,'h':y2-y})
    return zones

def board(g,budget):
    s=draw.Sheet(1,'ШС1. Размещение аппаратов на монтажной панели','A1',31,'Э4',12)
    ox,oy,k=65,65,.4
    X=lambda v:ox+v*k;Y=lambda v:oy+v*k
    p,ducts,rails=g['placements'],g['ducts'],g['rails']
    s.rect(ox,oy,CFG['panel']['width']*k,CFG['panel']['height']*k,.6,'MECHANICAL')
    dim(s,ox,57,X(750),57,'750');dim(s,30,oy,30,Y(1150),'1150')
    for xx in [ox,X(750)]:s.ln(xx,57,xx,oy,.18,'MECHANICAL')
    for yy in [oy,Y(1150)]:s.ln(30,yy,ox,yy,.18,'MECHANICAL')
    axes=sorted(g['duct_axes']+g['rail_axes'])
    for a,b in zip(axes,axes[1:]):dim(s,52,Y(a),52,Y(b),str(b-a))
    for v in axes:s.ln(50,Y(v),ox,Y(v),.15,'MECHANICAL')
    s.t(43,295,'Шаг между осями, мм',2.5,a='center',rot=90)
    for d in ducts:
        x,y,w,h=(d[q] for q in ['x','y','w','h'])
        s.rect(X(x),Y(y),w*k,h*k,.3,'MECHANICAL')
        if w>h:
            for dd in [4,h-4]:s.ln(X(x),Y(y+dd),X(x+w),Y(y+dd),.15,'MECHANICAL')
            s.t(X(x+w/2),Y(y+h/2)+1,'Короб 40×60',2.5,a='center')
        else:
            for dd in [4,w-4]:s.ln(X(x+dd),Y(y),X(x+dd),Y(y+h),.15,'MECHANICAL')
            s.t(X(x+w/2),Y(y+h/2),'КВ3 · 40×60' if d['tag']=='КВ3' else '40×60 · управление' if w==40 else '60×80 · силовые цепи',2.5,a='center',rot=90)
    for r in rails:
        for dy in [-17.5,0,17.5]:
            yy=r['y']+dy;segments=[(r['x'],r['x']+r['w'])]
            for a in p:
                if a['y']<=yy<=a['y']+a['h']:
                    next_segments=[]
                    for lo,hi in segments:
                        l,h=max(lo,a['x']),min(hi,a['x']+a['w'])
                        if h>l:
                            if lo<l:next_segments.append((lo,l))
                            if h<hi:next_segments.append((h,hi))
                        else:next_segments.append((lo,hi))
                    segments=next_segments
            for lo,hi in segments:s.ln(X(lo),Y(yy),X(hi),Y(yy),.15 if dy==0 else .3,'MECHANICAL',dy==0)
        for xx in [r['x'],r['x']+r['w']]:s.ln(X(xx),Y(r['y']-17.5),X(xx),Y(r['y']+17.5),.3,'MECHANICAL')
        s.t(374,Y(r['y'])+1,r['tag'],2.5,True)
    for z in clearance_zones(g):s.rect(X(z['x']),Y(z['y']),z['w']*k,z['h']*k,.18,'MECHANICAL',True)
    for a in p:
        x,y,w,h=(a[q] for q in ['x','y','w','h']);tag=a['tag']
        s.rect(X(x),Y(y),w*k,h*k,.35,'MECHANICAL')
        if tag.startswith('XT'):
            i=int(tag[2:]);yy=y-7 if i%2 else y+h+8
            s.t(X(x+w/2),Y(yy),tag,2.3,a='center')
            ts=[t for t in MODEL['terminals'] if t['terminal'].split(':')[0]==tag];xx=x
            for t in ts[:-1]:
                xx+=10.2 if '10' in t['model'] else 8.2 if t['model'].startswith('MTU-6') else 5.2
                s.ln(X(xx),Y(y),X(xx),Y(y+h),.15,'MECHANICAL')
        elif tag.startswith('EQS'):
            for dd in [12.5,22.5]:s.ln(X(x),Y(y+dd),X(x+w),Y(y+dd),.2,'MECHANICAL')
            s.t(X(x+w/2),Y(y)+4,tag,2.1,a='center')
        elif tag=='A8':
            s.t(X(x+w/2),Y(y+8),'A8',2.5,True,'center')
        else:
            htxt=1.8 if w<10 else 2.5
            s.t(X(x+w/2),Y(y+h/2)+(.8 if not a['rotate'] else 0),tag,htxt,True,'center',rot=90 if a['rotate'] else 0)
        if tag=='UZ1':
            s.rect(X(x+15),Y(y+23),79*k,32*k,.2,'MECHANICAL')
            s.t(X(x+w/2),Y(y+h/2)+8,'MS300',2.5,a='center')
        if tag=='KM1':s.t(X(x+w/2),Y(y+h/2)+6,'+ Z1',2.3,a='center')
        if tag=='A8':
            for j in range(5):s.rect(X(x+8.5),Y(y+23+j*20),14*k,7*k,.15,'MECHANICAL')
    dim(s,X(650),Y(950),X(650),Y(1150),'200')
    for yy in [950,1150]:s.ln(X(615),Y(yy),X(655),Y(yy),.15,'MECHANICAL')
    s.t(X(335),Y(1105),'Зона ввода и укладки кабелей',2.5,a='center')
    s.t(65,540,'ШС1: DKC R5ST1284, 1200×800×400 мм.',2.5)
    s.t(65,549,'Комплектная монтажная плата: 1150×750 мм.',2.5)
    s.t(65,558,'Вид спереди. Масштаб 1:2,5. Размеры в миллиметрах.',2.5)
    s.t(s.W-190+176,s.H-60+29,'1:2,5',3,a='center',layer='FRAME')

    s.heading(405,54,'Размещение на рейках',419)
    table(s,405,66,[33,31,355],['Рейка','Ось Y','Аппараты слева направо'],[
        ['DIN1','110','QF0–QF4; QFD1; FV1; XL1–XL3; PE2.'],
        ['DIN2','290','A8; A9; KV1; FU1–FU10; KM1 с Z1; N1.'],
        ['DIN3','515','G2; G1 → A1 → A2 → A3 → A4; KSR1.'],
        ['DIN4','740','K1–K16; XD2; XD3; XPE1; PE1.'],
        ['DIN5','920','XT1–XT11 по порядку; под клеммами короб отсутствует.'],
    ],rh=16)
    y=175
    for txt in [
        'Оси коробов Y = 20; 200; 380; 650; 830. X/Y отсчитывать от левого верхнего угла платы. Обычный шаг коробов 180; до оси рейки 90.',
        'Ряд DIN3: шаг коробов 270; по 135 до оси рейки. UZ1: X = 550, Y = 373; корпус 109×207; до нижнего короба 50, до левого 30, до правого 31. Пунктир — свободная зона.',
        'Зазоры сверху/снизу: ПЛК и KSR1 ≥50; G2 ≥40/20; UZ1 ≥50, по бокам ≥30. КВ3 40×60: X = 480, Y = 220, L = 410; соединяет короба Y = 200; 380; 650.',
        'Рейки 35 мм: X начала 45; длина DIN1/4/5 — 635, DIN2/3 — 430; конец X = 475, до КВ3 — 5. Крепёжные отверстия выполнять по шаблонам фактически поставленных аппаратов.',
        'PE2, A8, N1, PE1 — вертикально. EQS1: обе секции под клеммами, Y = 1010; X = 120 / 450. От нижней грани клемм до края платы 200. A8: 31×127,4.',
        'HL0 — сверху внутри; XS1 — внутри двери; SQ1 — у двери; SK1/SK2 — в верхней зоне, как в принятой компоновке.',
    ]:y=s.paragraph(405,y,txt,419,2.5,5.5)+5
    s.heading(405,238,'Привязка аппаратов по ширине',419)
    table(s,405,250,[33,386],['Рейка','X левой грани, мм'],[
        ['DIN1','QF0: 55. Промежутки между аппаратами 7; перед PE2 — 10.'],
        ['DIN2','A8: 55; A9: 96; KV1: 160; FU1–FU10: 188; KM1: 282; N1: 349.'],
        ['DIN3','G2: 55; G1: 135; A1: 212,9; A2: 292,9; A3: 331,1; A4: 369,3; KSR1: 440.'],
        ['DIN4','K1: 55; между реле 3. XD2: 301; XD3: 366,2; XPE1: 415,8; PE1: 465,4.'],
        ['DIN5','XT1: 55; XT1–XT11 последовательно; между группами 8. Номера клемм слева направо.'],
    ],rh=17)
    s.heading(405,370,'Размещение на корпусе',419)
    for x,side,title in [(431,'правая','Правая боковина'),(516,'левая','Левая боковина')]:
        s.t(x+20,382,title,2.5,True,'center');s.rect(x,397,40,120,.4,'MECHANICAL')
        s.t(x,525,'Передний край',2.2)
        dim(s,x,391,x+40,391,'400',2.2)
        for item in CFG['side_centers']:
            if item['side']!=side:continue
            xx=x+item['from_front']*.1;yy=397+item['from_top']*.1
            if item['tag'] in ('M2','EF1'):s.rect(xx-10,yy-10,20,20,.3,'MECHANICAL')
            else:s.circle(xx,yy,2)
            s.ln(xx-2,yy,xx+2,yy,.15,'MECHANICAL');s.ln(xx,yy-2,xx,yy+2,.15,'MECHANICAL')
            s.t(x+44,yy+1,item['tag'],2.5,True)
    dim(s,415,397,415,517,'1200',2.5)
    table(s,585,384,[28,53,78,80],['Обозн.','Стенка','Центр от низа','Центр от переда'],[
        [r['tag'],r['side'],str(r['from_bottom']),str(r['from_front'])] for r in CFG['side_centers']
    ],rh=14,h=2.3)
    table(s,585,456,[73,166],['Материал','Расход / закупка на 2 пары'],[
        ['Короб 40×60','4,60 м на ШС; закупка 10 м'],
        ['Короб 60×80','1,15 м на ШС; закупка 6 м'],
        ['DIN-рейка 35','2,765 м на ШС; закупка 4×2 м'],
    ],rh=12,h=2.3)
    s.paragraph(405,539,'Боковины: масштаб 1:10; показаны центры установки. QS1 — ось рукоятки. Вырезы и крепёж — по паспортам аппаратов. Зоны за боковыми аппаратами оставить свободными.',230,2.3,5.2)
    s.paragraph(65,571,'Силовые трассы — справа; управление и связь — слева. Длины отрезков проводов определять по фактической трассе.',310,2.3,5.2)
    s.finish()

def validate(g):
    errors=[];text_issues=[]
    def intersects(a,b):return min(a['x']+a['w'],b['x']+b['w'])-max(a['x'],b['x'])>.01 and min(a['y']+a['h'],b['y']+b['h'])-max(a['y'],b['y'])>.01
    for i,a in enumerate(g['placements']):
        if a['x']<40 or a['y']<0 or a['x']+a['w']>690 or a['y']+a['h']>1150:errors.append(['panel bounds',a['tag']])
        for b in g['placements'][i+1:]+g['ducts']:
            if intersects(a,b):errors.append(['intersection',a['tag'],b['tag']])
        rail=next((r for r in g['rails'] if r['tag']==a.get('rail')),None)
        if rail and not (rail['x']<=a['x'] and a['x']+a['w']<=rail['x']+rail['w'] and a['y']<=rail['y']<=a['y']+a['h']):
            errors.append(['not on declared rail',a['tag']])
    for z in clearance_zones(g):
        if z['x']<0 or z['y']<0 or z['x']+z['w']>750 or z['y']+z['h']>1150:errors.append(['clearance bounds',z['tag']])
        for b in g['placements']+g['ducts']:
            if b['tag'] not in z['members'] and intersects(z,b):errors.append(['clearance collision',z['tag'],b['tag']])
    for s in draw.SHEETS:
        texts=[a for a in s.texts if a['layer']=='TEXT']
        for i,a in enumerate(texts):
            bb=a['bbox']
            if bb[0]<21 or bb[2]>s.W-6 or bb[1]<5 or bb[3]>s.H-6:text_issues.append(['bounds',s.code,s.n,a['text']])
            if bb[2]>s.W-190 and bb[3]>s.H-60:text_issues.append(['stamp',s.code,s.n,a['text']])
            for b in texts[i+1:]:
                cc=b['bbox']
                if min(bb[2],cc[2])-max(bb[0],cc[0])>.6 and min(bb[3],cc[3])-max(bb[1],cc[1])>.6:text_issues.append(['text overlap',s.code,s.n,a['text'],b['text']])
        au=s.doc.audit()
        if au.errors or au.fixes:errors.append(['DXF',s.code,s.n,len(au.errors),len(au.fixes)])
    report={'revision':31,'modified_mount_pages':[1],'errors':errors,'text_issues':text_issues,
            'checked_placements':len(g['placements']),'checked_ducts':len(g['ducts']),'checked_rails':len(g['rails']),
            'clearances':clearance_zones(g),'open_requirement':g['open_requirement'],'electrical_connections_changed':False,'cutting_holes_specified':False,
            'scope':'Размеры и зазоры вида спереди. Дверь ШО, электрические связи и сверление не изменяются. Глубина компоновки не пересчитывалась.'}
    dump(QA/'geometry_R31.json',report)
    print(json.dumps(report,ensure_ascii=False))
    if errors or text_issues:raise SystemExit(2)

def combine():
    full=fitz.open()
    with fitz.open(OUT/'X2002_Э4_Р31_Лист_01.pdf') as d:full.insert_pdf(d)
    with fitz.open(ROOT/'baseline/mount_R30.pdf') as old:
        full.insert_pdf(old,from_page=1);toc=old.get_toc()
    full.set_toc(toc);full.set_metadata({'title':'X2002. Монтажная схема. Р31','subject':'Лист 1 — Р31: ПЧ опущен к коробу с зазором 50 мм; добавлен вертикальный короб КВ3; DIN2 продлена до КВ3. Листы 2–12 сохранены из Р30. Соединения не изменены.','author':''})
    full.save(OUT/'X2002_ШС1_Монтажная_схема_Р31.pdf',garbage=4,deflate=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--prepare-only',action='store_true');a=ap.parse_args()
    geometry,budget=prepare()
    if not a.prepare_only:
        draw.SHEETS.clear();board(geometry,budget);validate(geometry);combine()
    else:print(json.dumps(budget,ensure_ascii=False,indent=2))
