#!/usr/bin/env python3
"""Verify front-view geometry and source continuity for mounting sheet 1 only."""
from pathlib import Path
import hashlib,json,sys,subprocess,importlib.util
import fitz
ROOT=Path(__file__).resolve().parent
SKILL=ROOT/'qa_tools'
g=json.loads((ROOT/'data/layout_positions_R31.json').read_text())
old=json.loads((ROOT/'data/layout_positions_R30.json').read_text())
m=json.loads((ROOT/'data/mount_model_R29.json').read_text())
# This adapter inventories dimensioned installation objects/cut pieces.
# It deliberately is not a replacement of the procurement specification.
c={'id':'ШС','part':g['enclosure']['part'],'enclosure_mm':[800,1200,400],
   'panel_mm':[750,1150],'panel_origin_mm':[25,25],'door_mm':[800,1200],
   'source':g['enclosure']['source'],'quantity':2,
   'origin_scope':'Условная центровка контура панели для проверки вмещаемости; не привязка отверстий к корпусу.',
   'door_scope':'Габаритный контур корпуса; дверные аппараты в этой проверке отсутствуют.'}
a={'cabinets':[c],'devices':[],'placements':[],'mechanical':[],'bom':[],
   'scope':'Вид спереди двух одинаковых ШС. BOM в этом адаптере — число показанных монтажных объектов и нарезных деталей. Не закупочная спецификация.'}
def inventory(ident,part):
    a['bom'].append({'part':part,'members':[{'id':ident,'quantity':2}],
       'installed_qty':2,'spare_qty':0,'stock_qty':0,'purchase_qty':2,'unit':'монтажный объект',
       'quantity_scope':'Требуемое число показанных объектов; не закупочный артикул/объём.'})
inventory('ШС',c['part'])
for p in g['placements']:
    b=[p['x'],p['y'],p['x']+p['w'],p['y']+p['h']]
    part='Монтажная сборка '+p['tag']
    a['devices'].append({'id':p['tag'],'part':part,'cabinet':'ШС',
        'dimensions_mm':[b[2]-b[0],b[3]-b[1]],'bom_quantity':1})
    clearance=[0,0,0,0]
    if p['tag'] in ['G1','A1','A2','A3','A4']:
        clearance=[35 if p['tag']=='G1' else 0,50,30 if p['tag']=='A4' else 0,50]
    if p['tag']=='G2':clearance=[5,40,5,20]
    if p['tag']=='KSR1':clearance=[5,50,5,50]
    if p['tag']=='UZ1':clearance=[30,50,30,50]
    a['placements'].append({'device':p['tag'],'cabinet':'ШС','surface':'panel',
      'bbox_mm':b,'clearance_mm':clearance,'rail':p.get('rail'),
      'source':'data/layout_positions_R30.json; R31 placement changes and clearances listed in README.md'})
    inventory(p['tag'],part)
for r in g['rails']:
    part=f"Отрезок DIN 35 {r['tag']} L={r['w']} мм"
    a['mechanical'].append({'id':r['tag'],'kind':'rail','cabinet':'ШС','part':part,
      'x_mm':r['x'],'y_mm':r['y'],'length_mm':r['w']})
    inventory(r['tag'],part)
for d in g['ducts']:
    part=f"Отрезок короба {d['tag']} {d['w']}×{d['h']} мм в плане"
    a['mechanical'].append({'id':'DUCT_'+d['tag'],'kind':'duct','cabinet':'ШС','part':part,
       'bbox_mm':[d['x'],d['y'],d['x']+d['w'],d['y']+d['h']]})
    inventory('DUCT_'+d['tag'],part)
(ROOT/'data/assembly_geometry_adapter.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
subprocess.run([sys.executable,str(SKILL/'audit_assembly.py'),str(ROOT/'data/assembly_geometry_adapter.json'),'--report',str(ROOT/'qa/assembly_geometry.json')],check=True)
report={'scope':'Частичная правка листа 1; геометрия и сохранность других данных.',
'checks':{},'unmet_user_requirement':g['open_requirement'],
'limitations':['Детали сверления и глубина не пересчитывались.','Общая закупка не проверяется адаптером геометрии: он считает монтажные объекты и нарезные детали.','Длины отрезков проводов определяются трассировкой.']}
r=report['checks']
r['placement_identifiers_unchanged']=sorted(p['tag'] for p in g['placements'])==sorted(p['tag'] for p in old['placements'])
r['all_four_vertical']=all(p['h']>p['w'] for p in g['placements'] if p['tag'] in ['PE2','A8','N1','PE1'])
r['both_EQS_below_terminals']=all(p['y']>950 for p in g['placements'] if p['tag'].startswith('EQS'))
r['DIN2_extended']=next(v['w'] for v in g['rails'] if v['tag']=='DIN2')==430
r['remaining_height_below_terminals']=1150-950
r['electrical_model_unchanged_revision']=m['revision']==29
r['connections_retained']=len(m['connections'])
r['terminals_retained']=len(m['terminals'])
with fitz.open(ROOT/'output/X2002_ШС1_Монтажная_схема_Р31.pdf') as pdf:
    r['pages']=len(pdf);r['page1_size_mm']=[round(v*25.4/72,1) for v in pdf[0].rect[2:]]
    t=pdf[0].get_text();r['no_stale_coordinates_in_page1']=all(s not in t for s in ['190','570','1030','192,4','445,4','2,725','4,23','Y = 270'])
    r['expected_labels']=all(s in t for s in ['373','430','410','4,60','2,765','КВ3','PE2','A8','N1','PE1'])
    used={span['font'] for block in pdf[0].get_text('dict')['blocks'] if 'lines' in block for line in block['lines'] for span in line['spans']}
    r['used_fonts_embedded_page1']=all(pdf.extract_font(f[0])[3] for f in pdf[0].get_fonts() if f[3].split('+')[-1] in used)
by={d['tag']:d for d in g['ducts']}
uz=next(d for d in g['placements'] if d['tag']=='UZ1')
k2,k3,k4,kv=[by[tag] for tag in ['К2','К3','К4','КВ3']]
r['UZ1_lower_gap_50']=k4['y']-(uz['y']+uz['h'])==50
r['UZ1_left_gap_30']=uz['x']-(kv['x']+kv['w'])==30
r['vertical_duct_joins_K2_K3_K4']=(kv['y']==k2['y']+k2['h'] and kv['y']+kv['h']==k4['y'] and k3['x']+k3['w']==kv['x'] and kv['y']<=k3['y'] and k3['y']+k3['h']<=kv['y']+kv['h'])
r['rail_ends_5_from_new_duct']=all(kv['x']-(rail['x']+rail['w'])==5 for rail in g['rails'] if rail['tag'] in ['DIN2','DIN3'])
from collections import Counter
budget=json.loads((ROOT/'qa/materials_R31.json').read_text())
planned_ducts=Counter(max(d['w'],d['h']) for d in g['ducts'] if d['w']!=60)
r['duct_cut_plan_matches']=Counter(v for bar in budget['cut_plan_40x60_mm_two_cabinets'] for v in bar)==Counter({k:2*v for k,v in planned_ducts.items()})
r['duct_40x60_two_cabinets_m']=round(sum(sum(bar) for bar in budget['cut_plan_40x60_mm_two_cabinets'])/1000,3)
r['duct_purchase_sufficient_for_panel_cut_pieces']=r['duct_40x60_two_cabinets_m']<10 and all(sum(bar)+3*len(bar)<2000 for bar in budget['cut_plan_40x60_mm_two_cabinets'])
r['rail_cut_plan_matches']=Counter(v for bar in budget['cut_plan_rail_mm_two_cabinets'] for v in bar)==Counter({k:2*v for k,v in Counter(r['w'] for r in g['rails']).items()})
for key,value in r.items():
    if value is False:raise AssertionError(key)
report['source_hashes']={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'baseline/mount_R30.pdf',ROOT/'data/mount_model_R29.json',ROOT/'data/layout_positions_R30.json']}
(ROOT/'qa/continuity_R31.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
