import fs from 'node:fs/promises';
import path from 'node:path';
import {FileBlob,SpreadsheetFile} from '@oai/artifact-tool';
const root=process.argv[2],mode=process.argv[3]||'inspect';
const wb=await SpreadsheetFile.importXlsx(await FileBlob.load(path.join(root,'baseline/equipment_R27.xlsx')));
const sheet=wb.worksheets.getItem('Поставка');
if(mode==='edit'){
  const data=JSON.parse(await fs.readFile(path.join(root,'data/equipment_R31.json'),'utf8'));
  sheet.getRange('A1').values=[['X2002. Перечень поставляемого оборудования. Р31']];
  sheet.getRange('A2').values=[['Комплектующие для ШС1/ШО1 и ШС2/ШО2. «Всего» — количество в поставке, включая запас. Основание: ПЭ3 Р29 и спецификация 12.10.2026. Эталон до замены ШО, сборка 13.10.2026.']];
  sheet.getRange('A109').values=[['Двигатели, весовой комплект, полевые датчики, пневмоклапаны и внешние кабели — оборудование и материалы заказчика, в поставку не входят.']];
  for(const change of data.changes){
    const row=change.position+6;
    for(let col=0;col<10;col++){
      if(change.before[col]!==change.after[col])sheet.getRange(`${String.fromCharCode(65+col)}${row}`).values=[[change.after[col]]];
    }
  }
  sheet.getRange('A8:J8').format.rowHeight=55;
  wb.recalculate();
}
const suffix=mode==='edit'?'after':'before';
const img=await wb.render({sheetName:'Поставка',range:'A1:J10',scale:1.5,format:'png'});
await fs.writeFile(path.join(root,`qa/workbook_${suffix}.png`),new Uint8Array(await img.arrayBuffer()));
if(mode==='edit'){
  const inspection=await wb.inspect({kind:'region',sheetId:'Поставка',range:'A6:J10',maxChars:4500,tableMaxRows:5,tableMaxCols:10});
  await fs.writeFile(path.join(root,'qa/workbook_inspect.txt'),inspection.ndjson);
  const errs=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#N/A|#NAME\\?|#NUM!|#NULL!',options:{useRegex:true,maxResults:20},maxChars:1000});
  await fs.writeFile(path.join(root,'qa/workbook_errors.txt'),errs.ndjson);
  await (await SpreadsheetFile.exportXlsx(wb)).save(path.join(root,'output/X2002_Перечень_поставляемого_оборудования_Р31.xlsx'));
  console.log(JSON.stringify({inspection:inspection.ndjson,errors:errs.ndjson}));
}
