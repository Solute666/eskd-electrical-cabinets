from pathlib import Path
import fitz,json
from draw import Sheet,PAGES
ROOT=Path(__file__).resolve().parent
OUT=ROOT/"output"
READBACK=[]
def merge(code,name):
    out=fitz.open()
    for sheet in PAGES:
        if sheet.code==code:
            with fitz.open(ROOT/"sheets"/(sheet.name+".pdf")) as d:out.insert_pdf(d)
    out.set_metadata({"title":"X2002. Перечень поставляемого оборудования. Р31","subject":"13.10.2026. Эталон до замены ШО; перечень элементов Р29."})
    out.save(OUT/name,garbage=4,deflate=True)

def table_document(code,title,headers,widths,rows,footer,outname,h=2.9):
    from reportlab.pdfbase import pdfmetrics
    def wrap(txt,w,b=False):
        ll=[]
        for para in str(txt).split('\n'):
            line=''
            for word in para.split():
                nxt=(line+' '+word).strip()
                if pdfmetrics.stringWidth(nxt,'SansB' if b else 'Sans',h*72/25.4)*25.4/72>w-3.4 and line:ll.append(line);line=word
                else:line=nxt
            ll.append(line)
        return ll
    prepared=[([wrap(v,w) for v,w in zip(row,widths)],row) for row in rows]
    head=[wrap(v,w,True) for v,w in zip(headers,widths)]
    hh=max(len(x) for x in head)*4.6+6
    intro=[]
    if code=='ИО':
        for txt in ['DI/DO — дискретные входы/выходы; AI/AO — аналоговые входы/выходы.',
                    'Л/П — ряд и позиция вывода сверху. X/Y — адрес ПЛК своей позиции.',
                    'NPN: выход коммутирует 0 В. PNP: датчик выдаёт +24 В.']:
            intro.extend(wrap(txt,185))
    first_y=35+len(intro)*4.55+(3 if intro else 0)
    pages=[];current=[];used=0;capacity=236-(first_y+hh)
    for rr,row in prepared:
        rh=max(12,max(len(v) for v in rr)*4.55+5.5)
        if used+rh>capacity and current:
            pages.append(current);current=[];used=0;capacity=262-(35+hh)
        assert rh<capacity,(row,rh,capacity)
        current.append((rr,rh,row));used+=rh
    if current:pages.append(current)
    for i,page in enumerate(pages,1):
        s=Sheet(code,i,title,'A4',len(pages),True);x=20;y=first_y if i==1 else 35
        if i==1 and intro:s.textlines(22,33,intro,h,4.55)
        def rowdraw(vals,height,bold=False,row_id=None):
            nonlocal y
            s.rect(x,y,sum(widths),height,.25,'NOTES');xx=x
            for j,(col,w) in enumerate(zip(vals,widths)):
                if row_id is not None:READBACK.append({'page':i,'row':row_id,'col':j,'bbox_mm':[xx+.5,y+.5,xx+w-.5,y+height-.5],'expected':'\n'.join(col)})
                if j:s.ln(xx,y,xx,y+height,.2,'NOTES')
                for k,txt in enumerate(col):s.t(xx+1.7,y+4.3+4.55*k,txt,h,bold)
                xx+=w
            y+=height
        rowdraw(head,hh,True)
        for rr,rh,row in page:rowdraw(rr,rh,row_id=row[0])
        s.t(22,244 if i==1 else 269,footer,2.15)
        s.finish()
    merge(code,outname)
    (ROOT/"data/equipment_pdf_cells.json").write_text(json.dumps(READBACK,ensure_ascii=False,indent=2))
