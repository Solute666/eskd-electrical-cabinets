from pathlib import Path
import sys,json,copy
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
from draw import QA,PAGES
from table_document import table_document

model=json.loads((ROOT/'data/mount_model_R29.json').read_text())
old=json.loads((ROOT/'data/customer_tables_R27.json').read_text())
rows=copy.deepcopy(old['equipment'])
changes=[]
for row,e in zip(rows,model['elements']):
    assert row[0]==e['spec']
    prev=copy.deepcopy(row)
    row[1:6]=[e['name'],e['model'],e['brand'],e['purchase'],e['unit']]
    if row!=prev:changes.append({'position':e['spec'],'before':prev,'after':row})
new={'revision':'Р31','basis':'Монтаж Р31; перечень элементов Р29; спецификация от 12.10.2026. Сборка эталонного комплекта 13.10.2026.',
     'equipment':rows,'headers':old['eq_headers'],'changes':changes,
     'note':'Перечень поставки синхронизирован 13.10.2026 для эталона до замены шкафа оператора. Покупной корпус ШО сохранён.'}
(ROOT/'data/equipment_R31.json').write_text(json.dumps(new,ensure_ascii=False,indent=2))
pdfrows=[]
for row in rows:
    note=row[9]
    note+=f'\nВ работе: {row[6]}; запас: {row[7]}.' if isinstance(row[6],(int,float)) else '\nМонтажный материал.'
    detail='; '.join(s for s in [row[3],row[2]] if s)
    pdfrows.append([str(row[0]),row[1]+('\n'+detail if detail else ''),str(row[4]).replace('.',',')+' '+row[5],note])
pdfrows.append(['—','Заказчика: двигатели, весовой комплект, полевые датчики, пневмоклапаны и внешние кабели. WA1 и W7a — из имеющихся материалов.','—','В поставку не включены.'])
table_document('ВО','Перечень поставляемого оборудования',
    ['Поз. СП','Наименование / изготовитель / артикул','Всего','Распределение'],[14,104,22,45],pdfrows,
    'На две позиции ШС/ШО. Основание: перечень элементов Р29, спецификация 12.10.2026.',
    'X2002_Перечень_поставляемого_оборудования_Р31.pdf')
issues=[q for q in QA if q['issues'] or q['dxf_audit']]
(ROOT/'qa/drawing_checks.json').write_text(json.dumps(QA,ensure_ascii=False,indent=2))
assert not issues,issues
print(json.dumps({'pages':len(PAGES),'positions':len(rows),'changed_positions':[r['position'] for r in changes],'issues':issues},ensure_ascii=False))
