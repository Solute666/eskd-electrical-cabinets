from pathlib import Path
import math, json, csv
import ezdxf, fitz
from ezdxf.enums import TextEntityAlignment
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.units import mm

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'sheets'; OUT.mkdir(parents=True,exist_ok=True)
TMP=ROOT/'qa'; TMP.mkdir(parents=True,exist_ok=True)
for n,f in [('Sans','DejaVuSans.ttf'),('SansB','DejaVuSans-Bold.ttf')]:
    pdfmetrics.registerFont(TTFont(n,str(ROOT/'fonts'/f) if (ROOT/'fonts'/f).exists() else '/usr/share/fonts/truetype/dejavu/'+f))

NETS={}; DEVICES={}; SHEETS=[]
def connection(net,*pins):
    for pin in pins:
        if pin in NETS and NETS[pin]!=net:raise ValueError(f'Conflicting net for {pin}: {NETS[pin]} / {net}')
        NETS[pin]=net

class Sheet:
    def __init__(self,n,title,short,size='A2'):
        self.n=n;self.title=title;self.W,self.H=(841,594) if size=='A1' else (594,420);self.size=size
        self.name=f'X2002_ШС1_Э3_Лист_{n:02d}'
        self.c=canvas.Canvas(str(OUT/(self.name+'.pdf')),pagesize=(self.W*mm,self.H*mm))
        self.c.setTitle('X2002.Э3-Р1. '+title);self.c.setAuthor('');self.c.setSubject('ШС1; проект для согласования; 24.09.2026')
        self.doc=ezdxf.new('R2013');self.doc.units=4;self.doc.header['$INSUNITS']=4;self.doc.header['$MEASUREMENT']=1;self.doc.header['$LWDISPLAY']=True
        self.doc.styles.new('CYRILLIC',dxfattribs={'font':'DejaVuSans.ttf'});self.doc.styles.new('CYRILLIC_BOLD',dxfattribs={'font':'DejaVuSans-Bold.ttf'})
        self.doc.linetypes.new('DASHED_SCHEME',dxfattribs={'description':'dashed','pattern':[5,3,-2]})
        for name in ['FRAME','WIRE','PE','SYMBOL','MECHANICAL','TEXT','NOTES']:self.doc.layers.new(name,dxfattribs={'color':7})
        self.msp=self.doc.modelspace();self.texts=[];self.lines=[];self.frame(short);SHEETS.append(self)
    def ln(self,x1,y1,x2,y2,w=.35,layer='WIRE',dash=False):
        c=self.c;c.setLineWidth(w*mm);c.setDash([3*mm,2*mm] if dash else []);c.line(x1*mm,(self.H-y1)*mm,x2*mm,(self.H-y2)*mm)
        a={'layer':layer,'lineweight':round(w*100)}
        if dash:a['linetype']='DASHED_SCHEME'
        self.msp.add_line((x1,self.H-y1),(x2,self.H-y2),dxfattribs=a);self.lines.append((x1,y1,x2,y2,layer))
    def poly(self,p,w=.35,layer='WIRE',dash=False):
        for a,b in zip(p,p[1:]):self.ln(*a,*b,w,layer,dash)
    def rect(self,x,y,w,h,lw=.35,layer='SYMBOL',dash=False):self.poly([(x,y),(x+w,y),(x+w,y+h),(x,y+h),(x,y)],lw,layer,dash)
    def circle(self,x,y,r=1.2,fill=False):
        c=self.c;c.setDash([]);c.setLineWidth(.3*mm);c.circle(x*mm,(self.H-y)*mm,r*mm,stroke=not fill,fill=fill)
        if fill:
            h=self.msp.add_hatch(color=7,dxfattribs={'layer':'WIRE'});h.paths.add_polyline_path([(x+r*math.cos(i*math.tau/16),self.H-y+r*math.sin(i*math.tau/16)) for i in range(16)],is_closed=True)
        else:self.msp.add_circle((x,self.H-y),r,dxfattribs={'layer':'SYMBOL','lineweight':30})
    def dot(self,x,y):self.circle(x,y,.65,True)
    def t(self,x,y,s,h=3.1,b=False,a='left',rot=0,layer='TEXT'):
        s=str(s).replace('*','').replace('−','-').replace('–','-').replace('—','-');f='SansB' if b else 'Sans';width=pdfmetrics.stringWidth(s,f,h*mm)/mm
        xx=x-(width/2 if a=='center' else width if a=='right' else 0)
        c=self.c;c.saveState();c.setFont(f,h*mm);c.translate(x*mm,(self.H-y)*mm);c.rotate(rot)
        {'left':c.drawString,'right':c.drawRightString,'center':c.drawCentredString}[a](0,0,s);c.restoreState()
        e=self.msp.add_text(s,dxfattribs={'height':h*.729,'style':'CYRILLIC_BOLD' if b else 'CYRILLIC','layer':layer,'rotation':rot})
        e.set_placement((x,self.H-y),align={'left':TextEntityAlignment.LEFT,'center':TextEntityAlignment.CENTER,'right':TextEntityAlignment.RIGHT}[a])
        if not rot:self.texts.append({'text':s,'bbox':[xx,y-h*.79,xx+width,y+h*.22],'layer':layer})
    def textlines(self,x,y,lines,h=3.0,step=5.6,b=False):
        for i,s in enumerate(lines):self.t(x,y+i*step,s,h,b)
    def arr(self,x,y,d='right'):
        if d=='right':p=[(x-2.5,y-1.5),(x,y),(x-2.5,y+1.5)]
        elif d=='left':p=[(x+2.5,y-1.5),(x,y),(x+2.5,y+1.5)]
        else:p=[(x-1.5,y-2.5),(x,y),(x+1.5,y-2.5)]
        self.poly(p,.3,'SYMBOL')
    def net(self,x,y,name,ref='',right=False,length=15):
        # Endpoint is x+length (left source) or x-length (right destination).
        if right:
            self.ln(x-length,y,x,y);self.arr(x,y);self.t(x-length,y-2.2,name,2.9)
            if ref:self.t(x-length,y+5,ref,2.6)
        else:
            self.arr(x,y);self.ln(x,y,x+length,y);self.t(x,y-2.2,name,2.9)
            if ref:self.t(x,y+5,ref,2.6)
    def term(self,x,y,label='',above=True):
        self.circle(x,y)
        if label:self.t(x,y-2.2 if above else y+5,label,2.6,a='center')
    def earth(self,x,y,label='PE'):
        self.ln(x,y,x,y+3,.45,'PE')
        for yy,hw in [(3,3),(4.4,2),(5.8,1)]:self.ln(x-hw,y+yy,x+hw,y+yy,.4,'PE')
        if label:self.t(x+4,y+4.8,label,2.8)
    def contact(self,x,y,name,pins=('11','14'),nc=False,ref='',push=False):
        self.ln(x-10,y,x-4,y);self.ln(x+4,y,x+10,y)
        self.circle(x-4,y,.5)
        if nc:
            self.ln(x-4,y,x+4,y-1.0,.35,'SYMBOL');self.ln(x+4,y-3,x+4,y+1,.35,'SYMBOL')
        else:
            self.ln(x-4,y,x+3,y-4,.35,'SYMBOL');self.ln(x+4,y-1.4,x+4,y+1.4,.35,'SYMBOL')
        if push:
            self.ln(x,y-5,x,y-9,.25,'MECHANICAL');self.ln(x-3,y-9,x+3,y-9,.3,'SYMBOL')
        if name:self.t(x,y-7 if not push else y-11,name,3.1,True,'center')
        self.t(x-7,y+4.5,pins[0],2.55,a='center');self.t(x+7,y+4.5,pins[1],2.55,a='center')
        if ref:self.t(x,y+10,ref,2.6,a='center')
    def coil(self,x,y,name,diode=False,ref='',width=14,pins=('A1+','A2-')):
        self.rect(x-width/2,y-4,width,8);self.ln(x-13,y,x-width/2,y);self.ln(x+width/2,y,x+13,y)
        self.t(x,y-7.5,name,3.2,True,'center');self.t(x-16,y+5.4,pins[0],2.5,a='right');self.t(x+16,y+5.4,pins[1],2.5)
        if diode:self.diode(x,y+12,x-13,x+13,y)
        if ref:self.t(x,y+20 if diode else y+12,ref,2.55,a='center')
    def diode(self,x,y,left,right,mainy):
        self.poly([(left,mainy),(left,y),(x-3,y)]);self.poly([(x+3,y),(right,y),(right,mainy)])
        self.poly([(x+2,y-2),(x-2,y),(x+2,y+2),(x+2,y-2)],.3,'SYMBOL');self.ln(x-2,y-2.5,x-2,y+2.5,.3,'SYMBOL')
        self.ln(x-3,y,x-2,y);self.ln(x+2,y,x+3,y);self.dot(left,mainy);self.dot(right,mainy)
    def fuse(self,x,y,name,rating):
        self.ln(x-9,y,x+9,y);self.rect(x-6,y-2,12,4);self.t(x,y-5,name,3.2,True,'center');self.t(x,y+7,rating,2.8,a='center')
    def heading(self,x,y,title,w):
        self.t(x,y,title,3.5,True);self.ln(x,y+3,x+w,y+3,.25,'NOTES')
    def table(self,x,y,widths,headers,rows,rh=8,h=2.8):
        w=sum(widths);height=(len(rows)+1)*rh;self.rect(x,y,w,height,.25,'NOTES')
        xx=x
        for wi in widths[:-1]:xx+=wi;self.ln(xx,y,xx,y+height,.18,'NOTES')
        for k in range(1,len(rows)+1):self.ln(x,y+k*rh,x+w,y+k*rh,.18,'NOTES')
        for i,row in enumerate([headers]+rows):
            xx=x
            for wi,s in zip(widths,row):self.t(xx+2,y+i*rh+rh*.7,s,h,i==0);xx+=wi
