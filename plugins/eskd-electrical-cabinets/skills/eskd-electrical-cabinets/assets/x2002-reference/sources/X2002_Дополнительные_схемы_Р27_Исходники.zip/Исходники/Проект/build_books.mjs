import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { FileBlob, SpreadsheetFile } from '@oai/artifact-tool';

const work=process.env.X2002_PROJECT_ROOT??path.dirname(fileURLToPath(import.meta.url));
const out=process.env.X2002_OUTPUT_DIR??path.join(work,'output');
const data=JSON.parse(await fs.readFile(path.join(work,'data/customer_tables_R27.json'),'utf8'));
const jobs=[
 {kind:'io',name:'X2002_Перечень_сигналов',sheet:'Сигналы',cols:9,headers:data.io_headers,rows:data.io,notes:data.io_notes,title:'X2002. Перечень входных и выходных сигналов. Р27'},
 {kind:'equipment',name:'X2002_Перечень_поставляемого_оборудования',sheet:'Поставка',cols:10,headers:data.eq_headers,rows:data.equipment,notes:data.eq_notes,title:'X2002. Перечень поставляемого оборудования. Р27 / Р18'}
];
await fs.mkdir(out,{recursive:true});
for(const job of jobs){
 const input=path.join(work,'reference','Автоматика установки розлива. ПАККА',job.name+'.xlsx');
 const wb=await SpreadsheetFile.importXlsx(await FileBlob.load(input));
 const s=wb.worksheets.getItem(job.sheet);const lastcol=String.fromCharCode(64+job.cols);
 if(process.argv.includes('--preview')){
  const pic=await wb.render({sheetName:s.name,range:`A1:${lastcol}11`,scale:1,format:'png'});
  await fs.writeFile(path.join(work,'qa','before_'+job.kind+'.png'),new Uint8Array(await pic.arrayBuffer()));
  console.log((await wb.inspect({kind:'sheet',include:'id,name',maxChars:1000})).ndjson);
  continue;
 }
 const tableName=s.tables.items[0]?.name??(job.kind==='io'?'Signals':'Supply');
 for(const t of [...s.tables.items])t.delete();
 s.getRange(`A1:${lastcol}145`).format.fill='#FFFFFF';
 s.getRange(`A1:${lastcol}145`).format.font={name:'Arial',size:10,color:'#000000',bold:false};
 s.getRange(`A1:${lastcol}145`).format.borders={preset:'none'};
 s.getRange(`A6:${lastcol}145`).clear({applyTo:'contents'});
 s.getRange('A1').values=[[job.title]];
 s.getRange(`A1:${lastcol}1`).format.font={name:'Arial',size:14,bold:false,color:'#000000'};
 s.getRange('A1').format.rowHeight=30;
 s.getRange('A2').values=[[job.notes[0]]];
 s.getRange(`A2:${lastcol}3`).format.wrapText=true;
 s.getRange('A2').format.rowHeight=22;s.getRange('A3').format.rowHeight=22;
 s.getRange(`A6:${lastcol}6`).values=[job.headers];
 s.getRange(`A6:${lastcol}6`).format={fill:'#FFFFFF',font:{name:'Arial',size:10,bold:false,color:'#000000'},wrapText:true,horizontalAlignment:'center',verticalAlignment:'center',rowHeight:36};
 const end=6+job.rows.length;
 s.getRange(`A7:${lastcol}${end}`).values=job.rows;
 const table=s.tables.add(`A6:${lastcol}${end}`,true,tableName);
 table.style='TableStyleLight1';table.showBandedColumns=false;
 const body=s.getRange(`A7:${lastcol}${end}`);
 body.format={font:{name:'Arial',size:10,color:'#000000',bold:false},fill:'#FFFFFF',wrapText:true,verticalAlignment:'center',horizontalAlignment:'left'};
 s.getRange(`A6:${lastcol}${end}`).format.borders={preset:'all',style:'thin',color:'#000000'};
 const widths=job.kind==='io'?[16,29,34,28,21,32,28,24,58]:[12,58,36,24,12,12,23,16,28,45];
 for(let c=0;c<widths.length;c++)s.getRange(`${String.fromCharCode(65+c)}1:${String.fromCharCode(65+c)}${end+10}`).format.columnWidth=widths[c];
 for(let i=0;i<job.rows.length;i++){
  let lines=1;
  for(let c=0;c<job.cols;c++){
   const n=String(job.rows[i][c]??'').split('\n').reduce((v,z)=>v+Math.max(1,Math.ceil(z.length/(widths[c]*1.10))),0);
   lines=Math.max(lines,n);
  }
  s.getRange(`A${i+7}:${lastcol}${i+7}`).format.rowHeight=Math.max(38,lines*13+10);
 }
 if(job.kind==='equipment'){
  for(const col of ['A','E','G','H'])s.getRange(`${col}7:${col}${end}`).setNumberFormat('0');
  s.getRange(`E7:H${end}`).format.horizontalAlignment='center';
 }else{s.getRange(`E7:E${end}`).setNumberFormat('@');}
 let nr=end+3;
 for(const note of job.notes.slice(1)){
  const range=s.getRange(`A${nr}:${lastcol}${nr}`);range.merge();
  s.getRange(`A${nr}`).values=[[note]];
  range.format={fill:'#FFFFFF',font:{name:'Arial',size:10,color:'#000000'},wrapText:true,verticalAlignment:'center',rowHeight:32};nr++;
 }
 s.freezePanes.freezeRows(6);s.showGridLines=false;
 wb.recalculate();
 const report=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!',options:{useRegex:true,maxResults:50},summary:'Ошибки итоговой книги'});
 await fs.writeFile(path.join(work,'qa',job.kind+'_inspect.ndjson'),report.ndjson);
 for(const [tag,range] of [['top',`A1:${lastcol}12`],['bottom',`A${Math.max(7,end-6)}:${lastcol}${nr-1}`]]){
  const pic=await wb.render({sheetName:s.name,range,scale:1,format:'png'});
  await fs.writeFile(path.join(work,'qa',job.kind+'_'+tag+'.png'),new Uint8Array(await pic.arrayBuffer()));
 }
 const file=await SpreadsheetFile.exportXlsx(wb);
 await file.save(path.join(out,job.name+'_Р27.xlsx'));
 console.log(JSON.stringify({name:job.name,rows:job.rows.length,range:`A7:${lastcol}${end}`,errors:report.ndjson}));
}
