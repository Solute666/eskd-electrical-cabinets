"""Customer electrical documents from the frozen E3 R27 / specification R18 model."""
from pathlib import Path
import json, sys, re, math, shutil, hashlib, collections, os
ROOT=Path(__file__).resolve().parent
OUT=Path(os.environ.get('X2002_OUTPUT_DIR',str(ROOT/'output')))
OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'src'))
from draw import Sheet,PAGES,QA
import fitz

M=json.loads((ROOT/'data/model_R27.json').read_text())
C=M['connections']; T=M['terminals']; E=M['elements']
def edges(pin):return [e for e in C if pin in (e['a_raw'],e['b_raw'])]
def other(e,p):return e['b_raw'] if e['a_raw']==p else e['a_raw']
def net(pin):
    ns={e['net'] for e in edges(pin)}
    assert len(ns)<=1,(pin,ns)
    return next(iter(ns),'—')
def terminal(p):return next(t for t in T if t['terminal']==p)
def fmt(v):return str(v).replace('.',',') if v is not None else '—'

def merge(code,name):
    d=fitz.open()
    pages=[s for s in PAGES if s.code==code]
    for s in pages:d.insert_pdf(fitz.open(ROOT/'sheets'/(s.name+'.pdf')))
    d.set_metadata({'title':pages[0].title,'author':'','subject':'X2002; Э3 Р27 / спецификация Р18; 29.09.2026'})
    d.set_toc([[1,f'Лист {s.n}. {s.title}',s.n] for s in pages])
    d.save(OUT/name,garbage=4,deflate=True)

def grounding():
    s=Sheet('Э4.1',1,'Схема точек присоединения заземляющего проводника','A1',1)
    s.t(28,54,'Одна позиция: ШС1 + ШО1. Для ШС2 + ШО2 повторить независимо; индексы аппаратов внутри позиции сохраняются.',3.3)
    s.heading(28,75,'ШС1. ШИНА PE1',365)
    s.t(78,92,'W1: PE; 10 мм²',3.1,True)
    s.ln(60,85,60,98,.5,'PE')
    s.rect(43,98,34,8);s.t(60,103.3,'XT1:PE',2.9,a='center')
    s.ln(60,106,60,421,.7,'PE');s.dot(60,111)
    s.t(78,112,'PE1:01; 6 мм²',3.0,True)
    s.dot(60,122);s.ln(60,122,444,122,.55,'PE');s.t(74,118,'PE1:02',3.0,True)
    s.t(273,118,'6 мм²',2.9);s.t(366,118,'PE2:01',3.0,True)
    s.dot(444,122)
    seq=[('03','XPE1:1','A3:EARTH','24 AWG'),('04','XPE1:2','A8:FG','2,5 мм²'),
         ('05',None,'EQS1','2,5 мм²'),('07','XPE1:3','G1:LG','2,5 мм²'),
         ('08','XPE1:4','G2:PE','2,5 мм²'),('09','XPE1:5','Резерв у HL0',None),
         ('10','XPE1:6','M2:PE','2,5 мм²'),('11','XPE1:7','SQ1:PE','2,5 мм²'),
         ('12',None,'UZ1:PE','6 мм²'),('14','XPE1:8','XS1:PE','2,5 мм²'),
         ('15',None,'G2:−V, второй зажим','2,5 мм²; чёрный')]
    for i,(port,tr,target,section) in enumerate(seq):
        y=150+26*i;s.dot(60,y)
        layer='PE' if port!='15' else 'WIRE'
        s.ln(60,y,176,y,.45,layer);s.t(70,y-3,'PE1:'+port,2.9,True)
        if tr:
            s.t(134,y-3,'2,5 мм²',2.7);s.rect(176,y-4,42,8)
            s.t(197,y-6,tr,2.85,a='center');s.t(179,y+1.1,'a',2.6);s.t(213,y+1.1,'b',2.6)
            if section:
                s.ln(218,y,313,y,.45,layer);s.t(233,y-3,section,2.75)
                s.circle(313,y,1.2);s.t(322,y+1.2,target,3)
            else:s.t(234,y+1.2,target,3)
        else:
            s.ln(176,y,274,y,.45,layer);s.t(161,y-3,section,2.8)
            s.circle(274,y,1.2);s.t(282,y+1.2,target,3.0)
            if port=='15':s.t(180,y+7,'Цепь 2: постоянная связь 0 В с PE.',2.8)
    s.t(28,439,'PE1:06 и PE1:13 свободны. XPE1: a — от шины, b — к аппарату.',2.9)
    s.t(28,451,'A3:EARTH — функциональное заземление; белый 24 AWG с обозначением FE на концах.',2.9)
    s.heading(423,75,'ШС1. ШИНА PE2',390)
    s.t(423,94,'PE2:01 соединена с PE1:02 отдельным проводом 6 мм².',3)
    s.ln(444,122,444,304,.7,'PE')
    for i,(port,target,section) in enumerate([
        ('02','XT8:PE → W8:PE → ШО1.XT8:PE','2,5 мм²; W8: 1,5 мм²'),
        ('03','XT10:PE → W2:PE → M1:PE','6 мм²'),
        ('04','ШС1: дверь','6 мм²'),('05','ШС1: корпус','6 мм²'),
        ('06','ШС1: монтажная плита','6 мм²'),('15','FV1:PE','6 мм²')]):
        y=153+i*29;s.dot(444,y);s.ln(444,y,590,y,.45,'PE')
        s.t(454,y-3,'PE2:'+port,2.9,True);s.t(497,y-3,section,2.8)
        s.circle(590,y,1.2);s.t(600,y+1.2,target,3.0)
    s.t(423,318,'PE2:07–14 свободны. Экран W2 не заменяет жилу PE двигателя.',2.9)
    s.heading(423,341,'ШО1. ШИНА PE',390)
    s.t(423,358,'От ШС1: W8:PE → ШО1.XT8:PE → ШО1.PE:01; внутри ШО — 2,5 мм².',3)
    s.poly([(444,367),(444,496)],.7,'PE');s.t(453,374,'ШО1.PE:01',2.9,True)
    for i,(port,target,section) in enumerate([
        ('02','ШО1: корпус','6 мм²'),('03','ШО1: монтажная плита','6 мм²'),
        ('04','ШО1: дверь','6 мм²'),('05','ШО1.XPE1:1 → A7:1 (FG)','2,5 / 2,5 мм²')]):
        y=394+i*30;s.dot(444,y);s.ln(444,y,614,y,.45,'PE')
        s.t(454,y-3,'ШО1.PE:'+port,2.9,True);s.t(542,y-3,section,2.8)
        s.circle(614,y,1.2);s.t(624,y+1.2,target,2.95)
    s.t(423,511,'ШО1.PE:06–15 свободны. В ШО1 связь 0 В с PE не выполнять.',2.9)
    s.heading(28,471,'ЭКРАНЫ КАБЕЛЕЙ И СОЕДИНЕНИЯ',365)
    notes=[
        'PE1:05 → EQS1: 2,5 мм². W2 — экран на EQS1 у ПЧ и на корпус двигателя, контакт по окружности.',
        'WA1, W6, W21 — экраны на EQS1 в ШС1. Противоположные концы экранов изолировать.',
        'W7: экран → A9:IN 3; W7a: экран → A9:OUT 2. Экраны IN/OUT между собой, с EQS1 и PE не соединять.'
    ]
    y=485
    for txt in notes:y=s.para(28,y,txt,365,2.9,4.7)+5
    s.textlines(28,549,[
        'PE: жёлто-зелёный провод. Корпус, дверь и плита каждого шкафа имеют отдельные защитные соединения.',
        'N1 с PE не соединять. Связь 0 В–PE одна на позицию: G2:−V → PE1:15, цепь 2, чёрный 2,5 мм².',
        'XPE1:5b — резерв. Подключение PE светильника HL0 — по защитному исполнению поставленного изделия.',
        'Проводники PE не коммутировать. Непрерывность защитных соединений проверить после монтажа.'
    ],2.9,8)
    s.finish();merge('Э4.1','X2002_Схема_заземления_Р27.pdf')

def singleline():
    s=Sheet('Э3.1',1,'Однолинейная схема питания шкафов управления','A2',1)
    def switch(x,y,tag,rate,breaker=True):
        s.ln(x,y-11,x,y-3,.45);s.ln(x,y+3,x,y+11,.45)
        s.circle(x,y+3,.55);s.ln(x,y+3,x+4,y-3,.4,'SYMBOL');s.ln(x-2,y-3,x+2,y-3,.4,'SYMBOL')
        if breaker:s.poly([(x-2,y-2),(x-4,y-2),(x-4,y+2),(x-2,y+2)],.35,'SYMBOL')
        s.t(x+8,y-1,tag,3.2,True);s.t(x+8,y+6,rate,2.7)
    s.t(28,53,'Две независимые пары: ШС1–ШО1 и ШС2–ШО2. Показана одна пара; ввод 3×380/220 В, 50 Гц, TN-S.',3.1)
    s.rect(32,66,165,25);s.t(114.5,76,'W1, 5G10: L1 / L2 / L3 / N / PE',3,a='center')
    s.t(114.5,85,'Ввод заказчика: XT1:1/2/3/4/PE',2.9,a='center')
    s.ln(114,91,114,109,.55);switch(114,120,'QS1','3P; 63 А; «0–1»',False)
    s.t(155,118,'CHINT LW32-63/C03/2',2.9);s.t(155,126,'Кулачковый переключатель',2.7)
    s.ln(114,131,114,143,.55);switch(114,154,'QF0','3P C40; 6 кА')
    s.ln(114,165,114,178,.55);s.ln(65,178,545,178,.75);s.dot(114,178)
    s.t(252,156,'XL1–XL3: IEK RBD-160; распределение L1 / L2 / L3.',2.8)
    s.t(252,165,'N — N1; PE — PE1/PE2; через QS1 и QF0 не проходят.',2.8)
    branches=[(65,'QF1','3P C32','KM1; 3P, 32 А','UZ1: MS300, 5,5 кВт','M1: насос, 4 кВт','3L; Cu 6 мм²'),
        (152,'QF3','2P C6','G1: AS-PS02','Системная шина ПЛК','A1 → A2 → A3 → A4','L2+N; Cu 2,5'),
        (250,'QF2','2P C10','G2: 24 В / 10 А','DRL-24V240W1EN','FU1–FU6; цепи 24 В','L3+N; Cu 2,5'),
        (350,'QF4','2P C2','HL0: свет, 4 Вт','SK1 → M2: 26 Вт','Свет / вентиляция','L1+N; Cu 2,5'),
        (450,'QFD1','C6; 30 мА','1P+N; тип A; 6 кА','XS1: 230 В, 2P+PE','Нагрузка ≤6 А','L1+N; Cu 2,5'),
        (545,'FV1','T2; 4P','IEK MOP20-4-C','L1/L2/L3/N → PE','Ветвь после QF0','Cu 6; PE 6 мм²')]
    for x,tag,rate,a,b,c,wire in branches:
        s.dot(x,178);s.ln(x,178,x,196,.45)
        if tag=='FV1':
            s.rect(x-3,196,6,22);s.ln(x-5,216,x+5,198,.35,'SYMBOL')
            s.t(x+8,204,tag,3.2,True);s.t(x+8,213,rate,2.6)
        else:switch(x,207,tag,rate)
        s.ln(x,218,x,238,.45);s.t(x-34,232,wire,2.6)
        s.rect(x-37,238,74,47)
        for y,txt in [(249,a),(261,b),(274,c)]:s.t(x,y,txt,2.65,a='center')
        if tag=='FV1':s.ln(x,285,x,292,.5,'PE');s.earth(x,292,'PE2:15')
    s.heading(28,309,'РАСПРЕДЕЛЕНИЕ 24 В DC',364)
    s.textlines(28,323,[
        'FU1 T2,5 А: реле, связь, колонна; FU2 T0,8 А: датчики.',
        'FU3 T0,5 А: аналог; FU4 T0,5 А: KSR1 / STO (запрет момента ПЧ).',
        'FU5 T2 А: силовые выходы KSR1; FU6 T1 А: панель, кнопки, HL1, K15.',
        'FU7–FU10 T8 А: отдельная вставка перед каждым выходом KSR1.',
        'Внутренние фазы: белые; N: синий; +DC: красный; 0 В: чёрный; PE: жёлто-зелёный.',
        'Основные силовые проводники — 6 мм²; вспомогательные AC — 2,5 мм².',
        'N5 после QFD1 не объединять с N1. FV1 защищается QF0.',
        'Подробные соединения: Э3 Р27, листы 1, 2, 8 и 9.'
    ],2.8,10)
    s.heading(414,309,'ШКАФ ОПЕРАТОРА ШО1',163)
    s.textlines(414,323,[
        'От ШС1: W8, 12×1,5 мм² с PE.',
        '10 рабочих жил + PE + резерв; до 15 м.',
        'Ethernet: W4; XJ1 → W5 → A7.',
        'Силовой ввод 230 В в ШО не требуется.'
    ],2.7,8)
    s.finish();merge('Э3.1','X2002_Однолинейная_схема_Р27.pdf')

def io_data():
    rows=[];di={r['plc']:r for r in M['di']};do={r['plc']:r for r in M['do']}
    sourcepins=['SB1:4','SB2:2','SB3:4','SB4:4','SB5:4','B1:OUT','B2:b','B3:b','B4:b','B5:b','UZ1:RA','B6:b','B7:b','KSR1:X1','KV1:14','SQ1:14','B8:b','EXT1:b','B9:b','EXT2:b','KM1:14','SK2:2']
    sources={r['plc']:p for r,p in zip(M['di'],sourcepins)}
    for typ,prefix,index in [('DI','X',di),('DO','Y',do)]:
        for dev in ['A1','A2','A4']:
            for dr in M['device_rows'][dev]:
                if not dr['logical'].startswith(prefix):continue
                r=index.get(dr['pin']); factory=f"{dev}:{dr['label']} [{dr['location']}]"
                addr=factory+'\n'+dr['logical']
                if r is None:
                    rows.append([typ,addr,'Резерв','—','—','—','24 В DC' if typ=='DI' else 'NPN, 24 В DC','Свободен','Не подключён.']);continue
                assert net(dr['pin'])==r['net']
                if typ=='DI':
                    src=sources[r['plc']];org=r['origin']
                    if org.startswith('XT'):
                        t=terminal(org);cab=org+'; '+t['cable']
                    else:cab='Внутри ШС'
                    sig='PNP, 24 В DC' if src=='B1:OUT' else '24 В DC, активный' if src=='KSR1:X1' else '24 В через контакт'
                    state='0 = нажат / обрыв' if src=='SB2:2' else '1 = нажат' if src.startswith('SB') else '1 = перегрев' if src=='SK2:2' else '1 = указанный статус'
                    if edges(src):assert net(src)==r['net'],(src,r)
                    elif org.startswith('XT'):assert terminal(org)['net']==r['net'],(src,r)
                    rows.append([typ,addr,r['label'],src,r['net'],cab,sig,'Занят',state])
                else:
                    relay=r['relay'];reserve=relay=='K16'
                    assert any(other(e,dr['pin'])==relay+':A2' for e in edges(dr['pin']))
                    notes={'K1':'Контакт K1 управляет MI1 ПЧ.', 'K8':'Зелёный свет HL3.', 'K9':'Красный свет HL3 и лампа HL2.', 'K10':'Сухой контакт для АСУТП: XT5:1/2.', 'K11':'Сухой контакт для АСУТП: XT5:3/4.', 'K12':'Сухой контакт для АСУТП: XT5:5/6.', 'K13':'Жёлтый свет HL3.', 'K14':'Звук HL3.', 'K16':'Реле подключено; контакты в резерве.'}
                    if relay in [f'K{i}' for i in range(2,8)]:
                        n=int(relay[1:])-1;notes[relay]=f'Через контакт {relay}: YV{n}, XT3:{2*n-1}/{2*n}.'
                    rows.append([typ,addr,r['label'],relay+':A2',r['net'],'Внутри ШС','NPN, 24 В DC','Резерв с реле' if reserve else 'Занят',notes[relay]])
    for n in [1,3,2,4]:
        pin=f'A3:I{n}+';used=n==1
        rows.append(['AI',f'A3:I{n}+ / VI{n}−\nAI{n}','Давление' if used else 'Резерв','BP1:+/−' if used else '—','112 / 2' if used else '—','XT4:1/2; W21' if used else '—','4–20 мА' if used else 'Аналоговый вход','Занят' if used else 'Свободен','V1+–I1+: перемычка. Шкала по датчику.' if used else 'Не подключён.'])
    for n in [1,2]:
        rows.append(['AO',f'A3:IO{n} / AG\nAO{n}','Задание частоты насоса' if n==1 else 'Резерв','UZ1:ACI / ACM' if n==1 else '—','110 / 111' if n==1 else '—','WA1' if n==1 else '—','4–20 мА' if n==1 else 'Аналоговый выход','Занят' if n==1 else 'Свободен','WA1: экранированная пара из имеющихся материалов.' if n==1 else 'Не подключён; общий AG на левой колодке.'])
    rows.extend([
        ['Аппаратная цепь','SB0.1 → KSR1\nT12 / T22','Аварийный останов','SB0.1:1/2','6 / 13','XT9:1/2; W8:3/4','1 НЗ контакт','Используется','Один канал; состояние через DI X1.5.'],
        ['Аппаратная цепь','SB3 → K15\nKSR1:T31 / T32','Ручной сброс KSR1','SB3:4; K15','22','XT9:5; W8:7','24 В DC','Совместно с DI','Вход X0.2 и реле K15.'],
        ['Связь','A1:COM1 + / −\nSG','Весовой комплект','A10:ACLP-0909','120 / 121 / 122','XT6:1/2/3; W6','RS-485; Modbus RTU','Используется','Цифровое значение веса и статусы. Карта данных — по весовому комплекту.'],
        ['Связь','A1:COM2 + / −\nA9:АС5','Обмен с АСУТП','A9:IN → АСУТП','130/131; 132/133/134','W7a; XT7:1/2/3; W7','RS-485; Modbus RTU','Используется','W7a из имеющихся материалов. Сетевая карта обмена выпускается отдельно.'],
        ['Связь','A1:ETH → A8\nA7:ETH','Панель оператора','A8:1/2; ШО1.XJ1','—','W3 / W4 / W5','Ethernet','Используется','Порт A8:3 — сервис; 4/5 — резерв.']
    ])
    assert collections.Counter(r[0] for r in rows if r[0] in ['DI','DO','AI','AO'])=={'DI':32,'DO':20,'AI':4,'AO':2}
    assert collections.Counter(r[0] for r in rows if r[7]=='Занят')=={'DI':22,'DO':14,'AI':1,'AO':1}
    return rows

def equipment():
    rows=[]
    for e in E:
        qty=e['purchase'];installed=e['total'];spare=e['spare'];category='Оборудование'
        if e['spec']==7:installed=0;spare=qty;category='ЗИП'
        elif installed is None:category='Монтажный материал';installed='По расходу';spare='—'
        elif spare:category='Оборудование и запас'
        short=e['tag'] if e['tag']!='Материалы / запас' else 'Общий комплект двух позиций.'
        rows.append([e['spec'],e['name'],e['model'],e['brand'],qty,e['unit'],installed,spare,category,short])
    assert len(rows)==99 and len({r[0] for r in rows})==99
    assert all((r[0],r[2],r[4])==(e['spec'],e['model'],e['purchase']) for r,e in zip(rows,E))
    return rows

def table_document(code,title,headers,widths,rows,footer,outname,h=2.9):
    from reportlab.pdfbase import pdfmetrics
    def wrap(txt,w,b=False):
        ll=[]
        for para in str(txt).split('\n'):
            line=''
            for word in para.split():
                nxt=(line+' '+word).strip()
                if pdfmetrics.stringWidth(nxt,'SansB' if b else 'Sans',h*72/25.4)*25.4/72>w-3.4 and line:ll.append(line);line=word
                else:line=nxt
            ll.append(line)
        return ll
    prepared=[([wrap(v,w) for v,w in zip(row,widths)],row) for row in rows]
    head=[wrap(v,w,True) for v,w in zip(headers,widths)]
    hh=max(len(x) for x in head)*4.6+6
    intro=[]
    if code=='ИО':
        for txt in ['DI/DO — дискретные входы/выходы; AI/AO — аналоговые входы/выходы.',
                    'Л/П — ряд и позиция вывода сверху. X/Y — адрес ПЛК своей позиции.',
                    'NPN: выход коммутирует 0 В. PNP: датчик выдаёт +24 В.']:
            intro.extend(wrap(txt,185))
    first_y=35+len(intro)*4.55+(3 if intro else 0)
    pages=[];current=[];used=0;capacity=236-(first_y+hh)
    for rr,row in prepared:
        rh=max(12,max(len(v) for v in rr)*4.55+5.5)
        if used+rh>capacity and current:
            pages.append(current);current=[];used=0;capacity=262-(35+hh)
        assert rh<capacity,(row,rh,capacity)
        current.append((rr,rh,row));used+=rh
    if current:pages.append(current)
    for i,page in enumerate(pages,1):
        s=Sheet(code,i,title,'A4',len(pages),True);x=20;y=first_y if i==1 else 35
        if i==1 and intro:s.textlines(22,33,intro,h,4.55)
        def rowdraw(vals,height,bold=False):
            nonlocal y
            s.rect(x,y,sum(widths),height,.25,'NOTES');xx=x
            for j,(col,w) in enumerate(zip(vals,widths)):
                if j:s.ln(xx,y,xx,y+height,.2,'NOTES')
                for k,txt in enumerate(col):s.t(xx+1.7,y+4.3+4.55*k,txt,h,bold)
                xx+=w
            y+=height
        rowdraw(head,hh,True)
        for rr,rh,_ in page:rowdraw(rr,rh)
        s.t(22,244 if i==1 else 269,footer,2.15)
        s.finish()
    merge(code,outname)

def main():
    grounding();singleline()
    io=io_data();eq=equipment()
    compact=[]
    for r in io:
        compact.append([r[0]+'\n'+r[1],r[2],r[3]+'\n'+r[5],r[4].replace('/',' / '),r[6]+'\n'+r[7]+'\n'+r[8]])
    table_document('ИО','Перечень входных и выходных сигналов',
        ['Тип / вывод / адрес','Назначение','Аппарат / клеммы','Цепь','Сигнал / состояние'],
        [35,36,44,19,51],compact,'На позицию: 22/32 DI; 14/20 DO; 1/4 AI; 1/2 AO. Резерв DO включает K16.',
        'X2002_Перечень_сигналов_Р27.pdf')
    eqpdf=[]
    for r in eq:
        note=r[9]
        if isinstance(r[6],(int,float)):note+=f'\nВ работе: {r[6]}; запас: {r[7]}.'
        else:note+='\nМонтажный материал.'
        eqpdf.append([str(r[0]),r[1]+'\n'+r[3]+'; '+r[2],fmt(r[4])+' '+r[5],note])
    eqpdf += [['—','Заказчика: двигатели, весовой комплект, полевые датчики, пневмоклапаны и внешние кабели. WA1 и W7a — из имеющихся материалов.','—','В поставку не включены.']]
    table_document('ВО','Перечень поставляемого оборудования',
        ['Поз. СП','Наименование / изготовитель / артикул','Всего','Распределение'],[14,104,22,45],eqpdf,
        'Количество на ШС1/ШО1 и ШС2/ШО2 вместе. Основание: спецификация Р18.',
        'X2002_Перечень_поставляемого_оборудования_Р27.pdf')
    info={'revision':'Р27','spec_revision':'Р18','io':io,'equipment':eq,
        'io_headers':['Тип','Заводской вывод / адрес ПЛК','Назначение','Аппарат / вывод','Цепь у ПЛК','Клеммы / кабель','Электрический сигнал','Использование','Примечание'],
        'eq_headers':['Поз. СП','Наименование','Артикул','Изготовитель','Всего','Ед.','Установить / монтаж','Запас / ЗИП','Категория','Примечание'],
        'io_notes':['На одну позицию: 32 DI / 20 DO / 4 AI / 2 AO. Занято 22 / 14 / 1 / 1. Резерв 10 / 6 / 3 / 1; один DO подключён к резервному K16.',
        'DI/DO — дискретные входы/выходы; AI/AO — аналоговые входы/выходы. NPN — выход коммутирует 0 В; PNP — датчик выдаёт +24 В.',
        'Выводы перечислены по расположению на устройстве: сначала левый, затем правый ряд. Л/П и номер — положение сверху; это не часть заводской маркировки.',
        'Для ШС2/ШО2 повторить с индексом шкафа 2. Адреса X/Y относятся к ПЛК своей позиции. Токовые каналы A3 показаны по назначению AI1/AO1; программная привязка задаётся в проекте ПЛК.',
        'Цепь — маркировка внутреннего провода у ПЛК. Пустые поля резервов означают отсутствие подключения. Состояния входов приведены по электрическим схемам, без подмены описания алгоритма.'],
        'eq_notes':['Состав комплектующих для двух независимых позиций ШС1/ШО1 и ШС2/ШО2. Количество «Всего» включает установленные изделия и общий запас. Основание: спецификация Р18.',
        'Клеммы и релейные колодки включены отдельными позициями. Запас материалов входит в общее закупочное количество; расход определяется при монтаже.',
        'Двигатели, весовой комплект, полевые датчики, пневмоклапаны и внешние кабели — оборудование и материалы заказчика, в этот перечень поставки не входят.',
        'WA1 (A3 → ПЧ) и W7a (ПЛК → АС5) используются из имеющихся материалов и в закупочный перечень не включены. Сборка шкафов выполняется заказчиком.']}
    (ROOT/'data/customer_tables_R27.json').write_text(json.dumps(info,ensure_ascii=False,indent=2))
    (ROOT/'qa/drawing_checks.json').write_text(json.dumps(QA,ensure_ascii=False,indent=2))
    issues=[q for q in QA if q['issues'] or q['dxf_audit']]
    print(json.dumps({'documents':dict(collections.Counter(s.code for s in PAGES)),'io_rows':len(io),'equipment_rows':len(eq),'issues':issues},ensure_ascii=False))
if __name__=='__main__':main()
