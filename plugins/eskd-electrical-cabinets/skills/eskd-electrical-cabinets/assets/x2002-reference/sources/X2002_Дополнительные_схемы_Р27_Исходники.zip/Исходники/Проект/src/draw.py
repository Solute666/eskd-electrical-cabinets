from pathlib import Path
import json,math,sys
import fitz,ezdxf
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.lib.units import mm
from primitives import Sheet as Base
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'sheets';TMP=ROOT/'qa';PAGES=[];QA=[]
OUT.mkdir(parents=True,exist_ok=True);TMP.mkdir(parents=True,exist_ok=True)
class Sheet(Base):
    def __init__(self,code,n,title,size='A1',total=9,textdoc=False):
        self.code=code;self.n=n;self.title=title;self.size=size;self.total=total;self.textdoc=textdoc
        self.W,self.H={'A1':(841,594),'A2':(594,420),'A3':(420,297),'A4':(210,297)}[size]
        self.name=f'X2002_{code}_Р27_Лист_{n:02d}'
        self.c=canvas.Canvas(str(OUT/(self.name+'.pdf')),pagesize=(self.W*mm,self.H*mm))
        self.c.setTitle(f'X2002.{code}. {title}');self.c.setAuthor('');self.c.setSubject('Э3 Р27 / спецификация Р18; 29.09.2026')
        self.doc=ezdxf.new('R2013');self.doc.units=4;self.doc.header['$INSUNITS']=4
        for name,font in [('CYRILLIC','DejaVuSans.ttf'),('CYRILLIC_BOLD','DejaVuSans-Bold.ttf')]:self.doc.styles.new(name,dxfattribs={'font':font})
        self.doc.linetypes.new('DASHED_SCHEME',dxfattribs={'pattern':[5,3,-2]})
        for name in ['FRAME','WIRE','PE','SYMBOL','MECHANICAL','TEXT','NOTES']:self.doc.layers.new(name,dxfattribs={'color':7})
        self.msp=self.doc.modelspace();self.texts=[];self.lines=[];self.frame_new();PAGES.append(self)
    def frame_new(self):
        W,H=self.W,self.H;self.rect(20,5,W-25,H-10,.5,'FRAME')
        # Inventory strip, outside drawing field.
        self.rect(8,H-150,12,145,.35,'FRAME')
        for y,h,lab in [(H-150,25,'Инв. № подл.'),(H-125,35,'Подп. и дата'),(H-90,25,'Взам. инв. №'),(H-65,25,'Инв. № дубл.'),(H-40,35,'Подп. и дата')]:
            self.ln(8,y,20,y,.25,'FRAME');self.ln(13,y,13,y+h,.25,'FRAME');self.t(11.8,y+h/2,lab,2.3,a='center',rot=90,layer='FRAME')
        stamp_h=(40 if self.textdoc else 55) if self.n==1 else 15
        sx,sy=W-190,H-5-stamp_h;self.stamp_y=sy
        self.rect(sx,sy,185,stamp_h,.5,'FRAME')
        if self.n==1:
            self.ln(sx+65,sy,sx+65,H-5,.35,'FRAME')
            for y in range(5,stamp_h,5):self.ln(sx,sy+y,sx+65,sy+y,.2,'FRAME')
            for x in [17,40,55]:self.ln(sx+x,sy,sx+x,H-5,.2,'FRAME')
            self.ln(sx+7,sy,sx+7,sy+15,.2,'FRAME')
            for x,t in [(3.5,'Изм.'),(12,'Лист'),(28.5,'№ докум.'),(47.5,'Подп.'),(60,'Дата')]:self.t(sx+x,sy+13.5,t,2.1,a='center',layer='FRAME')
            for i,t in enumerate(['Разраб.','Пров.','Н.контр.','Утв.']):self.t(sx+1,sy+18.5+5*i,t,2.5,layer='FRAME')
            self.ln(sx+65,sy+15,sx+185,sy+15,.35,'FRAME')
            self.t(sx+125,sy+10,'X2002.'+self.code+'-Р27',4.1,a='center',layer='FRAME')
            if self.textdoc:
                self.t(sx+125,sy+22,'Установка розлива. ШС1 / ШО1',2.9,a='center',layer='FRAME')
                self.t(sx+125,sy+28,{'ПЭ3':'Перечень элементов','ТЭ4':'Таблица соединений','ИО':'Перечень сигналов','ВО':'Поставляемое оборудование'}.get(self.code,self.title),2.7,a='center',layer='FRAME')
                self.t(sx+125,sy+35,f'Лист {self.n}     Листов {self.total}',2.7,a='center',layer='FRAME')
            else:
                self.ln(sx+135,sy+15,sx+135,sy+55,.35,'FRAME')
                self.ln(sx+65,sy+40,sx+185,sy+40,.35,'FRAME')
                for yy in [20,35]:self.ln(sx+135,sy+yy,sx+185,sy+yy,.2,'FRAME')
                for xx in [150,167]:self.ln(sx+xx,sy+15,sx+xx,sy+35,.2,'FRAME')
                for yy,txt in [(22,'Установка розлива'),(28,'Шкафы ШС1 / ШО1'),(34,{'Э3.1':'Однолинейная схема','Э4.1':'Точки заземления'}.get(self.code,'Схема соединений'))]:self.t(sx+100,sy+yy,txt,2.8,a='center',layer='FRAME')
                for xx,txt in [(142.5,'Лит.'),(158.5,'Масса'),(176,'Масштаб')]:self.t(sx+xx,sy+18.7,txt,2.4,a='center',layer='FRAME')
                self.t(sx+176,sy+29,'-',3.5,a='center',layer='FRAME')
                self.t(sx+139,sy+38.7,'Лист 1',2.4,layer='FRAME');self.t(sx+161,sy+38.7,f'Листов {self.total}',2.4,layer='FRAME')
                self.t(sx+100,sy+49,'ПАККА. X2002',2.8,a='center',layer='FRAME')
        else:
            for x in [7,17,40,55,65,175]:self.ln(sx+x,sy,sx+x,sy+15,.25,'FRAME')
            for y in [5,10]:self.ln(sx,sy+y,sx+65,sy+y,.25,'FRAME')
            for x,t in [(3.5,'Изм.'),(12,'Лист'),(28.5,'№ докум.'),(47.5,'Подп.'),(60,'Дата')]:self.t(sx+x,sy+13.5,t,2.1,a='center',layer='FRAME')
            self.t(sx+120,sy+9.5,'X2002.'+self.code+'-Р27',4.1,a='center',layer='FRAME')
            self.t(sx+180,sy+4,'Лист',2.2,a='center',layer='FRAME');self.t(sx+180,sy+11.6,self.n,3.6,a='center',layer='FRAME')
        if not self.textdoc:
            self.t(28,22,self.title,4.7,True)
            self.t(28,31,'ПАККА. ШС1 / ШО1; ШС2 / ШО2 аналогично. Основание: Э3 Р27, спецификация Р18.',3.0)
            self.t(W-12,40,'29.09.2026   РЕДАКЦИЯ 27',2.9,a='right')
        else:
            self.t(25,16,self.title,3.8,True)
            self.t(25,23,'29.09.2026. Р27. Две одинаковые позиции: ШС1/ШО1 и ШС2/ШО2.' if self.code in ('ИО','ВО') else 'Один ШС1 + ШО1. 29.09.2026. Р27. Монтаж по согласованным решениям.',2.5)
        self.t(W-8,H-1.5,'Формат '+self.size,2.3,a='right',layer='FRAME')
    def wrap(self,text,width,h=3,b=False):
        out=[]
        for para in str(text).split('\n'):
            line=''
            for word in para.split():
                nxt=(line+' '+word).strip()
                if pdfmetrics.stringWidth(nxt,'SansB' if b else 'Sans',h*mm)/mm>width and line:out.append(line);line=word
                else:line=nxt
            out.append(line)
        return out
    def para(self,x,y,text,width,h=3,step=4.8,b=False):
        ll=self.wrap(text,width,h,b)
        self.textlines(x,y,ll,h,step,b);return y+len(ll)*step
    def dim(self,x1,y1,x2,y2,label):
        self.ln(x1,y1,x2,y2,.2,'MECHANICAL')
        if y1==y2:
            for x in [x1,x2]:self.ln(x-1.5,y1+1.5,x+1.5,y1-1.5,.3,'MECHANICAL')
            self.t((x1+x2)/2,y1-2,label,2.8,a='center')
        else:
            for y in [y1,y2]:self.ln(x1-1.5,y+1.5,x1+1.5,y-1.5,.3,'MECHANICAL')
            self.t(x1-3,(y1+y2)/2,label,2.8,a='center',rot=90)
    def finish(self):
        self.c.showPage();self.c.save();self.doc.set_modelspace_vport(height=self.H+20,center=(self.W/2,self.H/2))
        la=self.doc.layouts.get('Layout1');la.page_setup(size=(self.W,self.H),margins=(0,0,0,0),units='mm');la.add_viewport(center=(self.W/2,self.H/2),size=(self.W,self.H),view_center_point=(self.W/2,self.H/2),view_height=self.H)
        self.doc.saveas(OUT/(self.name+'.dxf'))
        d=fitz.open(OUT/(self.name+'.pdf'));page=d[0]
        scale=min(1.2,1600/page.rect.width)
        page.get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False).save(TMP/(self.name+'.png'))
        issues=[]
        tt=[t for t in self.texts if t['layer']!='FRAME']
        for t in tt:
            x,y,r,bt=t['bbox']
            if x<20 or r>self.W-5 or y<5 or bt>self.H-20:issues.append(['bounds',t['text']])
        for i,a in enumerate(tt):
            for b in tt[i+1:]:
                x,y,r,bt=a['bbox'];xx,yy,rr,bb=b['bbox']
                if min(r,rr)-max(x,xx)>.5 and min(bt,bb)-max(y,yy)>.6:issues.append(['overlap',a['text'],b['text']])
        (OUT/(self.name+'.svg')).write_text(page.get_svg_image(text_as_path=False))
        QA.append(dict(file=self.name,size=[self.W,self.H],dxf_audit=len(ezdxf.readfile(OUT/(self.name+'.dxf')).audit().errors),issues=issues))
        (TMP/(self.name+'_geometry.json')).write_text(json.dumps({'texts':self.texts,'lines':self.lines},ensure_ascii=False))
