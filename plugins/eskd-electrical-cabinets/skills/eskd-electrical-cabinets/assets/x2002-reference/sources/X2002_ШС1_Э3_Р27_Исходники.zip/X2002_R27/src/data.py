import json, copy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
BASE=json.loads((ROOT/'data/base_connections.json').read_text())
# Р12: терминальные группы только для широко разветвлённых цепей 3 и 2.
REMOVED_BANKS={b['tag'] for b in BASE['banks']}
OLD_EDGES=[copy.deepcopy(e) for e in BASE['edges'] if e['net']!='10' and 'HL0:PE_условно' not in (e['a'],e['b'])]
EDGES=[e for e in OLD_EDGES if not any(p.split(':')[0] in REMOVED_BANKS for p in (e['a'],e['b']))]
LOOPS=[]
def connect(n,a,b,size=.75,note='',kind='Провод'):
    EDGES.append(dict(net=str(n),a=a,b=b,size=size,color='синий' if str(n)=='2' else 'белый',note=note,kind=kind,route='Внутри шкафа',id=f'R12-{len(EDGES)+1:03d}'))
def loop(n,pins,size=.75,title=''):
    LOOPS.append(dict(net=str(n),pins=pins,size=size,title=title))
    for i,(a,b) in enumerate(zip(pins,pins[1:])):
        connect(n,a,b,size,('Шлейф; НШВИ(2) в промежуточных зажимах. '+title).strip())
# Последовательные провода; в каждом промежуточном зажиме две жилы одного сечения.
loop('1',['G2:+V']+[f'FU{i}:1' for i in range(1,7)],1.5,'Входы FU1–FU6')
loop('4',['FU2:2']+[f'XT2:{i}' for i in [1,4,7,10,13,16,19,22,24,26,28]],.75,'Питание датчиков по внутренней стороне XT2')
loop('5',['FU3:2','XT4:1','A3:24V'],.75,'BP1 и A3')
loop('6',['FU4:2','FU7:1','FU8:1','KSR1:A1','KSR1:T33','XT9:1'],.75,'KSR1 и питание SB0')
loop('7',['FU5:2','FU9:1','FU10:1'],1.5,'Входы FU9–FU10')
loop('9',['KSR1:34']+[f'K{i}:11' for i in range(2,8)],1.5,'Питание контактов клапанов')
loop('150',['XT11:3','K9:21','K13:11','K8:21','K14:11'],.75,'Изолированный общий колонны')
loop('8',['ШО1.XT8:1','A7:3','HL1:+','SB1:3','SB2:1','SB3:3','SB4:3','SB5:3'],.75,'Местное питание ШО1')
loop('2',['ШО1.XT8:2','A7:2','HL1:-','HL2:-'],.75,'Местный 0 В ШО1')
for b in ['K15:A1','A1:X0.2']:connect('22','XT9:5',b,.75,'Два отходящих провода в НШВИ(2) 2×0,75 на внутренней стороне XT9:5')
connect('13','XT9:2','KSR1:T12',.75,'Два отходящих провода к T12 / T22 в НШВИ(2) 2×0,75')
for n,a,bs in [('A9','QF4:2',['SK1:1','HL0:L']),('N4','QF4:4',['M2:N','HL0:N'])]:
    for b in bs:connect(n,a,b,1.5,'Два отходящих провода в НШВИ(2) 2×1,5 на выходе QF4')
BRANCHES={
 'XD3':[
  (['K1:A1']+[f'K{i}:A1' for i in range(2,15)]+['K16:A1'],.75,'3.1'),
  (['KV1:A1','KV1:11'],.75,'2.3'),
  (['UZ1:RC'],.75,'4.1'),
  (['K9:11'],.75,'5.3'),
  (['SQ1:13'],.75,'6.3'),
  (['KM1:13','SK2:1'],.75,'6.3'),
  (['XT11:1'],.75,'5.2'),
  (['A8:P1+','A9:PWR.1'],.75,'7.3')],
 'XD2':[
  (['A1:C0.1','A1:C0.2','A1:S/S.1','A1:S/S.2'],.75,'3.1'),
  (['A2:S/S.1','A2:S/S.2','A2:S/S.3','A2:S/S.4'],.75,'3.2'),
  (['A3:0V','A3:VI1-'],.75,'3.3'),
  (['A4:C0.1','A4:C0.2','A4:S/S.1','A4:S/S.2'],.75,'3.4'),
  (['A8:P1-','A9:PWR.2'],.75,'7.3'),
  (['KSR1:A2','K15:A2','KV1:A2','KM1:A2'],.75,'2.2'),
  (['UZ1:DCM','K1:11'],.75,'4.1'),
  (['XT2:2'],.75,'6.1'),
  ([f'XT3:{i}' for i in [2,4,6,8,10,12]],1.5,'5.1'),
  (['XT8:2'],1.5,'8.1'),
  (['XT11:2'],.75,'5.2')]
}
BANKS=[]
for tag,branches in BRANCHES.items():
    n=tag[-1];qty=len(branches)
    source='FU1:2' if n=='3' else 'G2:-V'
    connect(n,source,tag+':01a',1.5 if n=='3' else 2.5,'Ввод на распределительную группу')
    BANKS.append(dict(tag=tag,net=n,qty=qty,source=source,jumper='01–08' if n=='3' else '01–10; провод 10a–11a'))
    for i,(pins,size,section) in enumerate(branches,1):
        loop(n,[f'{tag}:{i:02d}b']+pins,size,'Ветвь '+tag+f':{i:02d}')
    if n=='2':connect(n,'XD2:10a','XD2:11a',1.5,'Проводная перемычка, продолжение общей цепи 2 на клемму 11')
# Контроль: ни один функциональный вывод прежней схемы не потерян.
def functional_members(edges):
    return {(e['net'],p) for e in edges for p in (e['a'],e['b']) if p.split(':')[0] not in REMOVED_BANKS and not p.startswith(('XD2:','XD3:'))}
assert functional_members(OLD_EDGES)<=functional_members(EDGES), functional_members(OLD_EDGES)-functional_members(EDGES)
assert not any(p.split(':')[0] in REMOVED_BANKS for e in EDGES for p in (e['a'],e['b']))
# Р14: удалён второй НЗ SB0.2 и местная перемычка цепи 12.
# Контроль состава Р12 выше относится к входной исторической модели.
PREVIOUS_EDGES=copy.deepcopy(EDGES)
EDGES=[e for e in EDGES if not (e['net']=='12' and {e['a'],e['b']}=={'SB0.1:2','SB0.2:1'})]
for e in EDGES:
    for end in ('a','b'):
        if e[end]=='SB0.2:2':e[end]='SB0.1:2'
assert not any('SB0.2:' in p for e in EDGES for p in (e['a'],e['b']))
PINS={}
for e in EDGES:
    for p in ['a','b']:
        if e[p] in PINS and PINS[e[p]]!=e['net']:raise ValueError(e)
        PINS[e[p]]=e['net']
PINS['KSR1:T11']='NC';PINS['KSR1:T21']='NC'
def peers(pin):
    return [e['b'] if e['a']==pin else e['a'] for e in EDGES if pin in (e['a'],e['b'])]
def feed(pin):
    pp=peers(pin)
    return pp[0] if pp else '—'
def net(pin):return PINS[pin]
def addr(netid):
    for row in DI:
        if row['net']==str(netid):return row['plc']
    return ''
DI=[]
labels=['Пуск','Стоп','Сброс','Головка вверх','Головка вниз','Тара на позиции','Головка вверху','Головка внизу','Лоток выдвинут','Лоток задвинут','ПЧ готов','Отсечка открыта','Отсечка закрыта','Цепь останова включена','24 В в норме','Дверь закрыта','Давление воздуха','Аспирация готова','Нет протечки','Разрешение АСУТП','Контактор включён','Перегрев шкафа']
origins=['XT9:3','XT9:4','XT9:5','XT9:6','XT9:7','XT2:3','XT2:6','XT2:9','XT2:12','XT2:15','UZ1:RA','XT2:18','XT2:21','KSR1:X1','KV1:14','SQ1:14','XT2:23','XT2:25','XT2:27','XT2:29','KM1:14','SK2:2']
pages=[8,8,2,8,8,6,6,6,6,6,4,6,6,2,2,6,6,6,6,6,6,6]
for i,(label,origin,page) in enumerate(zip(labels,origins,pages)):
    dev='A1' if i<8 else 'A2' if i<16 else 'A4';ch=i if i<8 else i-8 if i<16 else i-16
    logical=('X0.' if i<8 else 'X1.' if i<16 else 'X2.')+str(ch)
    physical=('X' if dev=='A1' else '')+str(ch)
    DI.append(dict(plc=dev+':'+logical,dev=dev,logical=logical,physical=physical,net=str(20+i),label=label,origin=origin,page=page))
DO=[]
names=['Пуск насоса','Головка вверх','Головка вниз','Отсечка открыть','Отсечка закрыть','Лоток выдвинуть','Лоток задвинуть','Колонна: зелёный','Красный / HL2','Готов к циклу','Цикл выполняется','Авария в АСУТП','Колонна: жёлтый','Звуковой сигнал','Резерв K16']
for i,name in enumerate(names):
    dev='A1' if i<12 else 'A4';ch=i if i<12 else i-12
    DO.append(dict(dev=dev,plc=dev+':'+('Y0.' if i<12 else 'Y1.')+str(ch),logical=('Y0.' if i<12 else 'Y1.')+str(ch),physical=('Y' if i<12 else '')+str(ch),net=str(50+i if i<14 else 65),relay='K'+str(i+1 if i<14 else 16),label=name))
FUSES=[('FU1','2,5','3','XD3','Реле, индикация, связь'),('FU2','0,8','4','XT2:1','Датчики и разрешения'),('FU3','0,5','5','XT4:1','Аналоговый модуль / BP1'),('FU4','0,5','6','FU7:1','KSR1 и входы STO'),('FU5','2','7','FU9:1','Катушки KM1 и YV1–YV6'),('FU6','1','8','XT8:1','ШО1: A7, кнопки, HL1')]
FU_SAFETY=[('FU7','6','155','13'),('FU8','6','156','23'),('FU9','7','157','33'),('FU10','7','158','43')]
SENSORS=[('B1','Тара на позиции',1,'25','W11'),('B2','Головка вверху',4,'26','W12'),('B3','Головка внизу',7,'27','W13'),('B4','Лоток выдвинут',10,'28','W14'),('B5','Лоток задвинут',13,'29','W15'),('B6','Отсечка открыта',16,'31','W16'),('B7','Отсечка закрыта',19,'32','W17')]
PERM=[('B8','Давление воздуха',22,'36','W18'),('EXT1','Аспирация готова',24,'37','W19'),('B9','Нет протечки',26,'38','W20'),('EXT2','Разрешение АСУТП',28,'39','W22')]
PARAMS=[('00-20','2','Задание частоты: аналоговый вход'),('00-21','1','Команда работы: внешние клеммы'),('02-00','1','Двухпроводное управление; MI1 = вперёд/стоп'),('02-13','9','Релейный выход RA–RC = готовность ПЧ'),('03-00','0','AVI не используется'),('03-01','1','ACI = задание частоты'),('03-29','0','ACI: 4–20 мА'),('03-19','3','Потеря ACI: немедленный останов; ACE, ручной сброс'),('06-44','0','Событие STO: ручной сброс'),('02-35','0','Запрет пуска при сохранённой команде после питания/сброса')]
# Р25: единственная перестановка монтажных адресов — сигнал/резерв в XT2.
# Исторические файлы Р14 оставлены для сравнения; рабочие структуры согласованы.
from terminal_map_r25 import remap
EDGES=remap(EDGES);BASE=remap(BASE);PINS=remap(PINS)
DI=remap(DI);origins=remap(origins);LOOPS=remap(LOOPS);BRANCHES=remap(BRANCHES)

# Р26: резервная жила W8:11 изолирована, электрического соединения нет.
EDGES=[e for e in EDGES if e['net']!='Резерв W8/11']
# Способ оконцевания определяет монтажник по допустимым зажимам аппарата.
# Электрическая топология ответвлений сохранена; обязательного НШВИ(2) нет.
for e in EDGES:
    if 'НШВИ(2)' in e.get('note',''):
        e['note']='Местное соединение; оконцевание по допустимым зажимам аппарата.'
PINS={p:e['net'] for e in EDGES for p in (e['a'],e['b'])}
PINS.update({'KSR1:T11':'NC','KSR1:T21':'NC'})

# Р27. Материалы и маркировка по спецификации Р18 и решению 29.09.2026.
import re
for e in EDGES:
    e.pop('length_est',None) # Длины старой компоновки больше не применяются.
    for end in ('a','b'):e[end]=e[end].replace(':IN16',':IN')
    if e['kind']=='Провод':
        z=e.get('size')
        e['size']={16:6,10:6,1.5:2.5,.5:.75}.get(z,z)
        n=e['net']
        e['color']=('ж/з' if n=='PE' else 'белый' if re.fullmatch(r'[ABC]\d+',n) else 'синий' if n.startswith('N') else 'чёрный' if n=='2' or n=='108' or (n.isdigit() and 50<=int(n)<=65) or n=='111' else 'красный')
        if any(x.startswith('A3:') for x in (e['a'],e['b'])):
            e['size']=.205;e['color']='белый; идентификация на концах'
            e['note']='A3: 24 AWG; неподвижная прокладка. '+e.get('note','')
        if n in ['110','111']:
            e['note']='WA1: экранированная витая пара 24 AWG, из имеющихся материалов; экран — EQS1, у ПЧ изолировать.'
            e['material']='WA1 (из имеющихся материалов)'
        if n in ['130','131']:
            e['material']='W7a (из имеющихся материалов)';e['size']=None;e['color']='по кабелю'
            e['note']='W7a: экранированная витая пара из имеющихся материалов; сечение по фактическому кабелю в диапазоне зажимов ПЛК / АС5.'
        if n in ['120','121']:
            e['note']='Пару 120/121 скрутить; R1 на разъёме COM1 ПЛК.'
        e['note']=e.get('note','').replace('Местное соединение; оконцевание по допустимым зажимам аппарата.','').replace('IEK РБД-160А; ввод в зажим 16 мм²','IEK РБД-160А; ввод Cu 6 мм². IN/O — проектные номера зажимов.')
    elif e['kind']=='Кабель W8':e['color']='ж/з' if e['net']=='PE' else 'по номеру жилы'
    elif e['kind'] in ['Экран','Ethernet','Вывод детали']:e['color']='—'
# Экранные соединения были показаны на Э3/9.3, но отсутствовали в старой таблице.
for cab in ['W6','W21']:
    EDGES.append(dict(net='PE',a='EQS1:шина экранов',b=cab+':экран',size=None,color='—',note='Экран на EQS1 в ШС1; противоположный конец изолировать.',kind='Экран',route='Сигнал',id='R27-'+cab))
PINS={p:e['net'] for e in EDGES for p in (e['a'],e['b'])}
PINS.update({'KSR1:T11':'NC','KSR1:T21':'NC'})

# Р27: согласованные подписи сечений во всех монтажных примечаниях.
for e in EDGES:
    if e['kind']=='Провод':
        e['note']=e.get('note','').replace('Выходной зажим РБД-160А; 10 мм²','РБД-160А; провод Cu 6 мм². O — проектный номер зажима.').replace('нейтраль УЗИП 10 мм²','нейтраль УЗИП 6 мм²')
        if e.get('material','').startswith('WA1'):e['color']='по кабелю'

# G9SE has 0.25–1.5 mm² terminals; use the approved 0.75 mm² size at this device.
# Source: OMRON J198-E1, Wiring p.18. Branch FU5 upstream is T2 A.
for e in EDGES:
    if e['kind']=='Провод' and any(p.startswith('KSR1:') for p in (e['a'],e['b'])):
        e['size']=.75
        if e['net'] in ['9','19','157','158']:e['note']='У KSR1 провод 0,75 мм²: диапазон его зажимов 0,25–1,5 мм².'
