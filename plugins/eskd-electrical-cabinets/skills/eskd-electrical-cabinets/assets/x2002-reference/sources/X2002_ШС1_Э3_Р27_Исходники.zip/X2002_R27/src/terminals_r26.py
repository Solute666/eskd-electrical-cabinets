"""Р25. Лист 10: прямоугольные клеммы XT1–XT11 в порядке монтажа."""
from draw import *
from data import *
from dc_sheet_r26 import ControlSheet

COVERAGE=set()
PHYSICAL={d['plc']:d['dev']+':'+d['physical'] for d in DI}
PHYSICAL.update({'A1:RS485.1':'A1:COM1 +','A1:RS485.2':'A1:COM1 −','A1:RS485.3':'A1:COM1 SG',
                 'A1:C0.1':'A1:C0 (верх.)','A2:S/S.1':'A2:S/S (верх.)','A4:C0.1':'A4:C0 (верх.)'})

def label(pin):
    return PHYSICAL.get(pin,pin).replace('A9:IN.','A9:IN ').replace('A9:OUT.','A9:OUT ').replace('-','−')

def internal_peers(pin):
    return [e['b'] if e['a']==pin else e['a'] for e in EDGES
            if pin in (e['a'],e['b']) and not e['kind'].startswith('Кабель')]

def mark(pin,net,sheet):
    register(pin,net,sheet);COVERAGE.add(pin)

TERMINAL_LAYOUT=[]
GROUP_ORDER=[]

def terminals_external():
    s=ControlSheet(10,'Клеммы ШС1. Внешние подключения','A1',revision=27)
    s.t(28,42,'Группы XT1–XT11 — по порядку слева направо, сверху вниз. Над клеммой — местный провод; ниже границы — внешний кабель.',2.5)
    base={e['terminal']:dict(e) for e in BASE['external']}
    current=json.loads((ROOT/'data/external_connections_R23.json').read_text())['connections']
    base.update({e['terminal']:e for e in current})
    cores={r['left']:str(r['core']) for r in BASE['intercab']}
    cores.update({'XT8:1':'1','XT8:2':'2','XT8:PE':'PE','XT9:9':'11'})

    def terminal(xx,yy,num,pin,netid):
        s.c.saveState();s.c.setFillColorRGB(1,1,1)
        s.c.rect((xx-5)*mm,(s.H-yy-3.5)*mm,10*mm,7*mm,stroke=0,fill=1);s.c.restoreState()
        s.rect(xx-5,yy-3.5,10,7,.3)
        s.term_windows.append((xx-5,yy-3.5,xx+5,yy+3.5))
        s.t(xx,yy+1.2,str(num),2.5,a='center')
        mark(pin,netid,10)
        TERMINAL_LAYOUT.append(dict(pin=pin,net=netid,x=xx,y=yy,shape='rectangle'))

    def card(x,y,w,title,tag,nums,cable,device,ref,power=False,remote=False,note='',colors=False,pitch=None):
        if not GROUP_ORDER or GROUP_ORDER[-1]!=tag:GROUP_ORDER.append(tag)
        s.t(x+w/2,y,title,2.5,True,'center')
        tagtext=tag+(':'+str(nums[0])+'–'+str(nums[-1]) if tag in ['XT2','XT3'] else '')
        s.t(x+w/2,y+8,tagtext+' /'+ref,2.5,a='center')
        count=len(nums);pitch=pitch or min(32,(w-18)/max(1,count-1))
        if tag=='XT6':pitch=36
        xs=[x+w/2+(i-(count-1)/2)*pitch for i in range(count)]
        ty=y+55;by=y+93;bottom=y+125
        active=[xx for xx,num in zip(xs,nums) if not base[tag+':'+str(num)]['net'].startswith('Резерв')]
        device_xs=xs if remote else active
        left=min(device_xs)-10;right=max(device_xs)+10
        s.rect(left,by,right-left,bottom-by,.25,'MECHANICAL',True)
        s.ln(x+2,y+72,x+w-2,y+72,.25,'MECHANICAL',True)
        s.t(min(active)-3,y+84,cable,2.5,True,'right')
        for xx,num in zip(xs,nums):
            pin=tag+':'+str(num);e=base[pin];n=e['net'];reserve=n.startswith('Резерв')
            nn=PINS.get(pin,'NC') if reserve else n
            pp=internal_peers(pin)
            if reserve:s.t(xx,y+25,'Резерв',2.5,a='center')
            else:
                for j,p in enumerate(pp):
                    if tag=='XT6':
                        s.t(xx,y+23,'A1:COM1',2.5,a='center')
                        s.t(xx,y+30,['+','−','SG'][int(num)-1],2.5,a='center')
                    else:s.t(xx,y+23+7*j,label(p),2.5,a='center')
                s.ln(xx,y+38,xx,by+(6 if remote else 0),.5 if power else .35)
                s.t(xx-3,y+45,n,2.5,a='right')
            terminal(xx,ty,num,pin,nn)
            if remote:
                terminal(xx,by+6,num,'ШО1.'+pin,nn)
                if not reserve:s.t(xx+3,y+84,cores[pin],2.5)
            elif not reserve:
                s.circle(xx,by,.7)
                p=e.get('pin')
                if colors:p={'BK1':'Чёрный','BK2':'Чёрный','BN':'Коричневый','RD':'Красный','YE':'Жёлтый','GN':'Зелёный','GY':'Серый'}[p]
                if p:s.t(xx,by+8,p.replace('-','−'),2.5,a='center')
        s.t((left+right)/2,by+23,device,3,True,'center')
        if note:s.t(x+w/2,bottom+8,note,2.5,a='center')

    s.heading(28,55,'10.1  XT1–XT2 · Ввод, датчики и внешние разрешения',796)
    card(28,70,116,'Ввод ШС1','XT1',['1','2','3','4','PE'],'W1','Сеть заказчика','1.1',True,note='380 В; 5×10 мм²')
    xx=157
    for dev,title,t,n,cab in SENSORS:
        card(xx,70,69,title,'XT2',[str(t),str(t+1),str(t+2)],cab,dev,'6.1',pitch=23);xx+=69
    for dev,title,t,n,cab in PERM:
        card(xx,70,46,title,'XT2',[str(t),str(t+1)],cab,dev,'6.2',pitch=23);xx+=46

    s.heading(28,217,'10.2  XT3–XT6 · Клапаны, давление, сигналы АСУТП и весовой канал',796)
    functions=['Головка вверх','Головка вниз','Отсечка открыть','Отсечка закрыть','Лоток выдвинуть','Лоток задвинуть']
    for i in range(6):card(28+i*65,232,65,functions[i],'XT3',[str(2*i+1),str(2*i+2)],'W9.'+str(i+1),'YV'+str(i+1),'5.1')
    card(426,232,94,'Давление','XT4',['1','2'],'W21','BP1','4.2',note='4–20 мА; экран')
    card(528,232,176,'Готов / Цикл / Авария','XT5',list(map(str,range(1,7))),'W23','АСУТП','5.3',note='Пары 1–2 / 3–4 / 5–6')
    card(712,232,112,'Весовой канал','XT6',['1','2','3'],'W6','A10 · ACLP-0909','7.1',note='Витая пара + SG; экран')

    s.heading(28,379,'10.3  XT7–XT11 · Связь, ШО1, насос и сигнальная колонна',796)
    card(28,394,106,'Связь с АСУТП','XT7',['1','2','3'],'W7','АСУТП','7.2',note='RS-485; экран')
    card(140,394,104,'Питание ШО1','XT8',['1','2','PE'],'W8','ШО1.XT8','8.1',remote=True)
    card(250,394,272,'SB0, кнопки и лампа HL2','XT9',list(map(str,range(1,10))),'W8','ШО1.XT9','8.1',remote=True)
    card(528,394,136,'Насос 4 кВт','XT10',['1','2','3','PE'],'W2','M1','1.1',True,note='4G6 мм²; экран')
    card(670,394,154,'Сигнальная колонна','XT11',list(map(str,range(1,8))),'W10','HL3','5.2',colors=True)

    s.t(28,545,'XT2: группы B2–B7 — питание, сигнал, резерв. Свободны 6, 9, 12, 15, 18, 21; провода и перемычки не подключать.',2.5)
    s.t(28,554,'XT8 — питание ШО1 (+24 В, 0 В, PE); XT9 — SB0, кнопки и HL2. Обе группы соединяются одним кабелем W8.',2.5)
    s.t(28,563,'XT9:9 свободна с обеих сторон; жила W8:11 изолирована. Распределительные клеммы, шины и местные подключения ШО1 — лист 11.',2.5)
    s.finish()

def terminals_internal():
    s=ControlSheet(11,'Распределительные клеммы и шины. Подключения','A1',revision=27)
    s.t(28,43,'Показаны существующие клеммы и точки шин. Адрес у линии — непосредственный конец монтажного провода.',2.5)

    def group(x,y,w,title,rows,rh=10,power=False,bus=False,subtitle='',bus_count=None,links=(),wire_numbers=False):
        s.heading(x,y,title,w)
        if subtitle:s.t(x,y+9,subtitle,2.5)
        cy=y+23;cx=x+w*.43
        if bus:s.ln(cx,cy,cx,cy+((bus_count or len(rows))-1)*rh,.6)
        for first,last,netid in links:
            y1=cy+first*rh;y2=cy+last*rh
            s.ln(cx,y1,cx-12,y1);s.ln(cx-12,y1,cx-12,y2);s.ln(cx-12,y2,cx,y2)
            s.t(cx-16,(y1+y2)/2+1,netid,2.5,a='right')
        for i,(num,left,right,netid,pins) in enumerate(rows):
            yy=cy+i*rh
            if left:s.ln(cx-12,yy,cx,yy);s.t(cx-16,yy+1,left,2.5,a='right')
            if right:
                free=right in ('Свободно','Свободна','Резерв HL0')
                if not free:
                    s.ln(cx,yy,cx+12,yy)
                    if wire_numbers:s.t(cx+7,yy-3.2,netid,2.5,a='center')
                s.t(cx+16,yy+1,right,2.5)
            if power:
                s.rect(cx-5,yy-3,10,6,.3)
                s.c.saveState();s.c.setFillColorRGB(1,1,1);s.c.rect((cx-5)*mm,(s.H-yy-3)*mm,10*mm,6*mm,stroke=0,fill=1);s.c.restoreState()
                s.rect(cx-5,yy-3,10,6,.3);s.term_windows.append((cx-5,yy-3,cx+5,yy+3))
                s.t(cx,yy+1.2,num,2.5,a='center')
            else:
                s.term(cx,yy);s.t(cx-3,yy-3.2,num,2.5,a='right')
            for p in pins:mark(p,netid,11)
        return cy+(len(rows)-1)*rh+7

    def banks(tag):
        rows=[]
        for i,(targets,size,sec) in enumerate(BRANCHES[tag],1):
            a=f'{tag}:{i:02d}a';b=f'{tag}:{i:02d}b'
            left=', '.join(label(p) for p in internal_peers(a))
            if tag=='XD2' and i in (10,11):left=''
            rows.append((f'{i:02d}',left,label(targets[0]),tag[-1],[a,b]))
        return rows

    group(28,60,250,'11.1  XD3 · цепь 3 · +24 В',banks('XD3'),rh=12,bus=True,subtitle='01–08: общая перемычка; a слева, b справа.')
    group(28,194,250,'11.2  XD2 · цепь 2 · 0 В',banks('XD2'),rh=12,bus=True,bus_count=10,links=[(9,10,'2')],subtitle='01–10: перемычка. 10a–11a: провод 2,5 мм².')
    s.t(28,357,'От клеммы — к первому аппарату; продолжение шлейфа',2.5)
    s.t(28,366,'показано на листах 2–8. C0 / S/S: верхний зажим.',2.5)

    sho=[]
    cores={r['left']:str(r['core']) for r in BASE['intercab']}
    cores.update({'XT8:1':'1','XT8:2':'2','XT8:PE':'PE'})
    for tag,nums in [('ШО1.XT8',['1','2','PE']),('ШО1.XT9',list(map(str,range(1,10))))]:
        for num in nums:
            pin=tag+':'+num;nn=PINS.get(pin,'NC')
            pp=internal_peers(pin)
            cable='' if nn=='NC' else 'W8:'+cores[pin.removeprefix('ШО1.')]
            sho.append((('XT8:' if '.XT8' in tag else 'XT9:')+num,cable,', '.join(label(p) for p in pp) or 'Свободна',nn,[pin]))
    group(28,390,250,'11.3  ШО1 · XT8 и XT9',sho,rh=12,wire_numbers=True,subtitle='Слева — жила W8; справа — местный провод.')
    s.t(28,564,'XT9:9 в обоих шкафах свободна; жила W8:11',2.5)
    s.t(28,573,'изолирована с обоих концов. PE — отдельная жила.',2.5)

    def bus_rows(tag,qty):
        rows=[]
        for i in range(1,qty+1):
            p=f'{tag}:{i:02d}';pp=internal_peers(p);n=PINS.get(p,'N' if tag=='N1' else 'PE')
            dest=label(pp[0]) if pp else 'Свободно'
            dest=dest.replace('EQS1:шина экранов','EQS1').replace('ШС1:плита','ШС1:монтажная плита').replace('ШО1:плита','ШО1:монтажная плита')
            rows.append((f'{i:02d}','',dest,n,[p]))
        return rows

    group(294,60,248,'11.4  N1 · нейтраль N',bus_rows('N1',15),rh=10,power=True,bus=True,subtitle='DKC 5015N; /1.1')
    s.t(294,241,'XL1–XL3: IN / O1–O4 — адреса проекта.',2.5)
    yy=249
    for j in range(1,4):
        tag=f'XL{j}';ports=['IN']+['O'+str(k) for k in range(1,5 if j==1 else 4)]
        rows=[(p,'',label(internal_peers(tag+':'+p)[0]),'ABC'[j-1]+'3',[tag+':'+p]) for p in ports]
        yy=group(294,yy,248,f'{tag} · фаза '+str(j)+' · цепь '+'ABC'[j-1]+'3',rows,rh=10,power=True,bus=True)+14
    rows=[]
    for i in range(1,9):
        a=f'XPE1:{i}a';b=f'XPE1:{i}b';aa=internal_peers(a);bb=internal_peers(b)
        rows.append((str(i),label(aa[0]),label(bb[0]) if bb else 'Резерв HL0','PE',[a,b]))
    group(294,479,248,'11.5  XPE1 · проходные PE-клеммы',rows,rh=9,subtitle='a слева, b справа; /9.1')
    s.t(294,580,'XJ1: W4 → RJ45 → W5; все 8 контактов 1:1.',2.5)
    s.t(294,587,'A8: Ethernet, порт 2 → A7:ETH; /7.3, /8.2.',2.5)

    group(564,60,260,'11.6  PE1 · ШС1',bus_rows('PE1',15),rh=9,bus=True,subtitle='DKC T1615; точка 15 — провод 2 от G2:−V.')
    group(564,229,260,'11.7  PE2 · ШС1',bus_rows('PE2',15),rh=9,bus=True,subtitle='DKC T1615; /9.1')
    group(564,398,260,'11.8  PE · ШО1',bus_rows('ШО1.PE',15),rh=8,bus=True,subtitle='Точка 05 → XPE1:1 → A7:1; /9.2')
    group(564,546,260,'ШО1.XPE1:1', [('1','ШО1.PE:05','A7:1 (FG)','PE',['ШО1.XPE1:1a','ШО1.XPE1:1b'])],rh=9)
    s.finish()
