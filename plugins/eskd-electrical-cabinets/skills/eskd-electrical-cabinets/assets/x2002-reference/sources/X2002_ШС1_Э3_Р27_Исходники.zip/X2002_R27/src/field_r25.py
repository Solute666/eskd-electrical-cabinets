"""Р25. Принятый лист 6: обновлены адреса сигналов и резервов XT2."""
from draw import *
from data import *
from dc_sheet_r26 import ControlSheet

def field():
    s=ControlSheet(6,'Датчики, внешние разрешения и контроль состояния','A1',revision=27)
    s.heading(28,49,'6.1  Датчики механизма',494)
    s.t(28,64,'Питание 4 — от FU2; местный шлейф по XT2. Обзор клемм — лист 10.',2.5)

    def inside(y,terminal,n,peer,ref,function='',right=522,tx=246):
        s.ln(tx,y,right,y);s.arr(right,y,'left' if n in ['4','2'] else 'right')
        s.t(tx+56,y-3.2,n,2.5,a='center')
        s.t(right-73,y-4,peer,2.5,a='center')
        s.t(right-2,y-4,n+' /'+ref,2.5,a='right')
        if function:s.t(right-2,y+7,function,2.5,a='right')
        s.term(tx,y,'ШС1.XT2:'+str(terminal),pin='XT2:'+str(terminal),net=n)

    s.rect(50,75,96,81,.25,'MECHANICAL',True)
    s.t(92,98,'B1',3,True,'center');s.t(92,111,'PNP',2.5,a='center')
    s.t(196,104,'W11',3,True,'center')
    for y,p,n,t,peer,ref,desc in [
        (90,'+','4',1,'FU2:2','2.1','+24 В'),
        (114,'0','2',2,'XD2:08','2.4','0 В'),
        (138,'OUT','25',3,'A1:X5','3.1','Тара на позиции')]:
        s.ln(146,y,246,y);s.pin(146,y,'B1:'+p,n,p,'right')
        inside(y,t,n,peer,ref,desc)

    def field_contact(x,yt,tag,netid,cable,terminal,target,ref,function,tx,right,previous):
        # Условные a/b — два вывода внешнего сухого контакта.
        w=96 if x==50 else 74;edge=x+w;yc=yt+14;cx=x+w/2
        s.rect(x,yt-14,w,59,.25,'MECHANICAL',True)
        s.contact(cx,yc,tag,('a','b'))
        s.poly([(cx-12,yc),(x+10,yc),(x+10,yt),(tx,yt)])
        s.poly([(cx+12,yc),(edge-13,yc),(edge-13,yt+28),(tx,yt+28)])
        register(tag+':a','4',6);register(tag+':b',netid,6)
        s.t((edge+tx)/2,yt+16,cable,3,True,'center')
        inside(yt,terminal,'4',previous,'6.1' if tag in [r[0] for r in SENSORS[1:]] or tag=='B8' else '6.2','',right,tx)
        inside(yt+28,terminal+1,netid,target,ref,function,right,tx)

    for i,(tag,function,t,n,cable) in enumerate(SENSORS[1:]):
        row=next(d for d in DI if d['net']==n)
        field_contact(50,191+62*i,tag,n,cable,t,row['dev']+':'+row['physical'],'3.1' if row['dev']=='A1' else '3.2',function,246,522,'XT2:'+str(1 if i==0 else t-3))
    s.lines(28,560,[
        'XT2:6, 9, 12, 15, 18, 21 — резерв; провода и перемычки не подключать.',
        'Шлейф 4: XT2:1–4–7–10–13–16–19–22–24–26–28; 0,75 мм².',
        'Выводы + / 0 / OUT и a / b — функциональные; номера по документации датчика.'
    ],2.5,9)

    s.heading(550,49,'6.2  Внешние разрешения',274)
    for i,(tag,function,t,n,cable) in enumerate(PERM):
        row=next(d for d in DI if d['net']==n)
        field_contact(550,91+67*i,tag,n,cable,t,row['dev']+':'+row['physical'],'3.4',function,681,824,'XT2:'+str(19 if i==0 else t-2))
    s.t(550,349,'Контакт замкнут — разрешение присутствует.',2.5)

    s.heading(550,375,'6.3  Состояние шкафа',274)
    for i,(tag,ports,n,peer,power,ref,function) in enumerate([
        ('SQ1',('13','14'),'35','A2:7','XD3:05','2.4','Дверь закрыта'),
        ('KM1',('13','14'),'40','A4:4','XD3:06','2.4','Контактор включён'),
        ('SK2',('1','2'),'41','A4:5','KM1:13','6.3','Перегрев · замыкается при 40 °C')]):
        y=406+61*i
        s.ln(550,y,646,y);s.arr(550,y)
        s.t(552,y-4,'3 /'+ref,2.5);s.t(552,y+7,power,2.5)
        s.t(626,y-3.2,'3',2.5,a='center');s.contact(658,y,tag,ports)
        s.ln(670,y,824,y);s.arr(824,y)
        s.t(704,y-3.2,n,2.5,a='center');s.t(761,y-4,peer,2.5,a='center')
        s.t(822,y-4,n+(' /3.2' if i==0 else ' /3.4'),2.5,a='right')
        s.t(822,y+7,function,2.5,a='right')
        if tag=='KM1':s.t(658,y+19,'Катушка /2.3',2.5,a='center')
        register(tag+':'+ports[0],'3',6);register(tag+':'+ports[1],n,6)
    s.lines(550,557,['SQ1:11–12 свободны. SQ1:PE — /9.1.',
                     'KM1:13 → SK2:1 — местный шлейф, 0,75 мм².'],2.5,9)
    s.finish()
