"""Р25. Компоновка принятого листа 3; шесть адресов XT2 согласованы с переносом резервов."""
from draw import *
from data import *
from dc_sheet_r26 import ControlSheet

PIN_LAYOUT=[]
EXTERNAL_LAYOUT=[]
BUS_COMMENT='Системная шина: G1 /1.1 → A1 → A2 → A3 → A4. Соединение штатными боковыми разъёмами.'
INTERCAB_INPUTS={r['net']:r for r in BASE['intercab'] if r['net'] in ['20','21','22','23','24']}
FIELD_INPUTS={r['terminal']:r for r in BASE['external'] if r['net'] in ['25','26','27','28','29','31','32','36','37','38','39','112']}


class MirrorPanel:
    """Зеркальная компоновка участка; текст остаётся читаемым, привязки зеркалятся."""
    def __init__(self,sheet,xsum):self.sheet=sheet;self.xsum=xsum
    def x(self,x):return self.xsum-x
    @staticmethod
    def side(side):return {'left':'right','right':'left','center':'center'}.get(side,side)
    def t(self,x,y,text,h=2.5,b=False,a='left',**kw):return self.sheet.t(self.x(x),y,text,h,b,self.side(a),**kw)
    def lines(self,x,y,ss,h=2.5,step=6,b=False):
        for i,text in enumerate(ss):self.t(x,y+i*step,text,h,b)
    def ln(self,x,y,u,v,*args,**kw):return self.sheet.ln(self.x(x),y,self.x(u),v,*args,**kw)
    def poly(self,pts,*args,**kw):return self.sheet.poly([(self.x(x),y) for x,y in pts],*args,**kw)
    def rect(self,x,y,w,h,*args,**kw):return self.sheet.rect(self.x(x)-w,y,w,h,*args,**kw)
    def circle(self,x,y,*args,**kw):return self.sheet.circle(self.x(x),y,*args,**kw)
    def dot(self,x,y,*args,**kw):return self.sheet.dot(self.x(x),y,*args,**kw)
    def arr(self,x,y,d='right'):return self.sheet.arr(self.x(x),y,self.side(d))
    def pin(self,x,y,p,n,label=None,side='left'):return self.sheet.pin(self.x(x),y,p,n,label,self.side(side))
    def term(self,x,y,*args,**kw):return self.sheet.term(self.x(x),y,*args,**kw)


def plc():
    sheet=ControlSheet(3,'ПЛК, модули и входы / выходы','A1',revision=27)
    sheet.t(28,43,BUS_COMMENT,2.5)

    def device(x,y,w,h,tag,model):
        s.rect(x,y,w,h,.5)
        s.t(x+w/2,y+9,tag+' · '+model,3,True,'center')
        s.ln(x,y+14,x+w,y+14,.25,'SYMBOL')

    def pin(dev,x,y,p,n,label,side,addr=None):
        s.pin(x,y,dev+':'+p,n,label,side)
        if addr:
            s.t(x+(28 if side=='left' else -28),y+1,addr,2.5,a='left' if side=='left' else 'right')
        PIN_LAYOUT.append(dict(dev=dev,pin=p,net=n,label=label,side=s.side(side),x=s.x(x),y=y))

    def wire_number(x,y,n):
        # Номер расположен над конкретным проводом; пояснение — под ним.
        s.t(x,y-2.5,n,2.5,a='center')

    def feed(x,y,end,n,ref,side,label='',origin=None,tx=None,mark_offset=14):
        s.ln(x,y,end,y)
        s.arr(end,y,'right' if side=='left' else 'left')
        s.t(end+(2 if side=='left' else -2),y-4,n+' /'+ref,2.5,a='left' if side=='left' else 'right')
        # После полевой клеммы оставлен самостоятельный номер монтажного провода.
        mx=tx+(20 if x>tx else -20) if origin and tx is not None else x+(-mark_offset if side=='left' else mark_offset)
        wire_number(mx,y,n)
        if label:s.t(min(x,end)+2,y+6.5,label,2.5)
        if origin:
            if origin.startswith('XT'):s.term(tx,y,origin,pin=origin,net=n)
            else:s.t(tx,y-4,origin,2.5,a='center')

    def external_signal(dev,x,y,n,terminal,label):
        # Координаты ниже — на готовом листе, без зеркального преобразования.
        # Внешний участок подписан аппаратом / кабелем, местный — номером провода.
        px=s.x(x)
        sx,cx,tx,mx={'A1':(38,105,149,171),
                     'A2':(516,553,604,626),
                     'A3':(38,105,149,171),
                     'A4':(515,540,570,593)}[dev]
        if n in INTERCAB_INPUTS:
            r=INTERCAB_INPUTS[n]
            assert r['left']==terminal
            source=r['pin'];remote=r['right'];cable=r['cable'];core=r['core']
            sheet.ln(sx,y,82,y)
            sheet.ln(82,y,tx,y)
            sheet.term(82,y,remote.split('.',1)[1],pin=remote,net=n)
            sheet.t(114,y-3.2,'жила '+str(core),2.5,a='center')
        else:
            r=FIELD_INPUTS[terminal]
            assert r['net']==n
            source=r['device']+':'+r['pin'];remote=None;cable=r['cable'];core=None
            sheet.ln(sx,y,tx,y)
            sheet.t(cx,y-3.2,cable,2.5,a='center')
        sheet.term(sx,y,pin=source,net=n)
        sheet.t(31 if dev in ['A1','A3'] else 506,y-3.2,source,2.5)
        sheet.ln(tx,y,px,y)
        sheet.term(tx,y,'ШС1.'+terminal,pin=terminal,net=n)
        sheet.t(mx,y-2.5,n,2.5,a='center')
        sheet.t(px-2,y+6.5,label,2.5,a='right')
        EXTERNAL_LAYOUT.append(dict(dev=dev,net=n,source=source,remote=remote,
                                    cable=cable,core=core,terminal=terminal,
                                    terminal_x=tx,wire_number_x=mx,input_x=px))

    def signal(dev,x,y,row,end,tx):
        if row['net'] in INTERCAB_INPUTS or row['origin'] in FIELD_INPUTS:
            external_signal(dev,x,y,row['net'],row['origin'],row['label'])
        else:
            feed(x,y,end,row['net'],section_for(row['page'],row['net']),'right',row['label'],row['origin'],tx)
        pin(dev,x,y,row['logical'],row['net'],row['physical'],'right',row['logical'])

    def relay(x,y,end,cx,r,refs=()):
        s.ln(end,y,cx-8,y);s.ln(cx+8,y,x,y)
        s.t(cx-11,y-2.5,'A1+',2.5,a='right')
        s.t(cx+11,y-2.5,'A2−',2.5)
        wire_number((x+cx+8)/2,y,r['net'])
        wire_number((end+cx-8)/2,y,'3')
        s.t(cx+31,y+6.5,r['label'],2.5)
        s.rect(cx-8,y-3,16,6)
        s.t(cx,y-5,r['relay'],2.8,True,'center')
        if refs:s.t(cx,y+7.5,'Контакты /'+', /'.join(refs),2.5,a='center')
        s.dot(end,y)
        register(r['relay']+':A1','3',3)
        register(r['relay']+':A2',r['net'],3)
        for sec in refs:REFERENCES.append({'from':3,'to':int(sec.split('.')[0]),'section':sec,'label':r['relay']+' — контакты'})

    def commons(dev,side,x,ys,end,tag,ref,source,tx):
        for k,y in enumerate(ys):pin(dev,x,y,tag+'.'+str(k+1),'2',tag,side)
        feed(x,ys[0],end,'2',ref,side)
        bx=x+(-10 if side=='left' else 10)
        s.ln(bx,ys[0],bx,ys[-1])
        for y in ys[1:]:
            s.ln(bx,y,x,y)
            wire_number((bx+x)/2,y,'2')
        for y in ys[:-1]:s.dot(bx,y)
        s.t(tx,ys[0]-4,source,2.5,a='center')

    # A1: DI X0–X7 слева; DO Y0–Y11 справа, без разделения по чётности.
    sheet.heading(28,57,'3.1  A1 · контроллер и реле K1–K12',460)
    s=MirrorPanel(sheet,516)
    device(201,70,100,278,'A1','AS320T-B')
    for x,txt,a in [(205,'DO','left'),(229,'Адрес','left'),(273,'Адрес','right'),(297,'DI','right')]:s.t(x,90,txt,2.5,a=a)
    commons('A1','left',201,[98,110],34,'C0','2.4','XD2:01',127)
    commons('A1','right',301,[98,110],487,'S/S','3.1','От C0 · местная перемычка',393)
    sheet.rect(28,116,67,98,.25,'MECHANICAL',True)
    sheet.t(61,122,'ШО1',2.5,True,a='center')
    sheet.t(114,122,'W8',2.5,True,a='center')
    a1=[r for r in DI if r['dev']=='A1']
    for i,r in enumerate(a1):signal('A1',301,132+i*18,r,487,393)
    s.ln(34,126,34,330);s.arr(34,126,'down');s.t(36,122,'3 /2.4',2.5)
    refs=[('4.1','2.2')]+[('5.1',)]*6+[('5.2',),('5.2','5.3')]+[('5.3',)]*3
    for i,r in enumerate(DO[:12]):
        y=132+i*18
        pin('A1',201,y,r['logical'],r['net'],r['physical'],'left',r['logical'])
        relay(201,y,34,98,r,refs[i])
    s.t(297,274,'RS-485',2.5,True,a='right')
    for i,(mark,port,n,ref) in enumerate([('+','COM1 D+','120','7.1'),('−','COM1 D−','121','7.1'),('SG','SG','122','7.1'),('+','COM2 D+','130','7.2'),('−','COM2 D−','131','7.2')]):
        y=282+i*12
        feed(301,y,487,n,ref,'right',str(i+1)+' · '+port,mark_offset=60)
        pin('A1',301,y,'RS485.'+str(i+1),n,mark,'right')
    s.t(34,346,'DO типа NPN: катушки A1+ → 3; A2− → выход ПЛК.',2.5)
    s.t(303,346,'Ethernet: A8 /7.3. USB: сервис.',2.5)

    # A2: все DI слева, номера 0–15 по порядку; четыре S/S на той же стороне.
    sheet.heading(506,57,'3.2  A2 · дополнительные DI',318)
    s=MirrorPanel(sheet,1330)
    device(566,70,100,270,'A2','AS16AM10N-A')
    for x,txt,a in [(638,'Адрес','right'),(662,'DI (IN)','right')]:s.t(x,90,txt,2.5,a=a)
    commons('A2','right',666,[97,108,119,130],824,'S/S','2.4','XD2:02',758)
    s.t(688,111,'Все S/S соединены перемычками.',2.5)
    s.t(688,123,'Вход активен при +24 В на DI.',2.5)
    a2=[r for r in DI if r['dev']=='A2']
    for i in range(16):
        y=149+i*12
        if i<8:
            signal('A2',666,y,a2[i],824,758)
        else:
            pin('A2',666,y,'X1.'+str(i),'NC',str(i),'right','X1.'+str(i))
            s.t(668,y+1,'Резерв DI',2.5)
    s.lines(688,252,[
        'S/S и C0 каждого аппарата соединены местными перемычками.',
        '0 В: XD2:01 → A1; XD2:02 → A2; XD2:03 → A3; XD2:04 → A4.',
        'Катушки реле: цепь 3 от XD3:01, проводной шлейф 0,75 мм².',
        'K1–K9: KIPPRIBOR MR-203.D [M01]; 2 переключающих контакта.',
        'Колодки PYF-022BE/2; модули LM-CF24.G.',
        'K10–K14, K16: SR-203.D; защита встроена в колодку.',
        'K16 — резерв; его контакты свободны.'
    ],2.5,7)

    # A3: все AI слева, AO справа. AG физически один.
    sheet.heading(28,365,'3.3  A3 · AI / AO',460)
    s=MirrorPanel(sheet,516)
    device(201,378,100,184,'A3','AS06XA-A')
    s.t(205,399,'AO',2.5,True);s.t(297,399,'AI',2.5,True,a='right')
    for ch in range(1,5):
        for k,tail in enumerate([f'V{ch}+',f'I{ch}+',f'VI{ch}−']):
            y=405+(ch-1)*39+k*11
            n='112' if ch==1 and k<2 else '2' if ch==1 else 'NC'
            pin('A3',301,y,tail.replace('−','-'),n,tail,'right')
        s.t(269,417+(ch-1)*39,'AI'+str(ch),2.5,a='right')
        if ch>1:s.t(331,417+(ch-1)*39,'AI'+str(ch)+' · резерв',2.5)
    external_signal('A3',301,416,'112','XT4:2','BP1 · давление, 4–20 мА')
    s.poly([(322,416),(322,405),(301,405)]);s.dot(322,416)
    wire_number((322+301)/2,405,'112')
    s.poly([(301,427),(314,427),(314,555)])
    s.t(320,435,'2',2.5,a='left')
    s.t(331,436,'Местные перемычки: V1+–I1+; VI1−–0V.',2.5)
    pin('A3',301,555,'0V','2','0V','right')
    feed(301,555,487,'2','2.4','right',mark_offset=6)
    s.dot(314,555);s.t(393,551,'XD2:03 · 0 В',2.5,a='center')
    for p,n,y in [('VO1','NC',405),('IO1','110',422),('AG','111',439),('VO2','NC',468),('IO2','NC',485)]:
        pin('A3',201,y,p,n,p,'left')
        if n=='NC':s.t(34,y+1,'Не используется в токовом режиме' if p=='VO1' else 'AO2 · резерв',2.5)
        else:
            s.ln(34,y,201,y);s.arr(34,y,'left');s.t(36,y-4,n+' /4.1',2.5)
            wire_number(187,y,n)
            s.t(36,y+6.5,'UZ1:ACI · задание ПЧ' if p=='IO1' else 'UZ1:ACM · общий AO',2.5)
    s.t(231,423,'AO1',2.5);s.t(231,480,'AO2',2.5)
    s.t(34,499,'AI1 / AO1: 4–20 мА; A3 — 24 AWG.',2.5)
    pin('A3',201,516,'24V','5','24V','left')
    feed(201,516,34,'5','4.2','left','От XT4:1 · +24 В')
    pin('A3',201,545,'FE','PE',None,'left')
    s.circle(211,545,3.2)
    s.ln(211,542.6,211,545,.3,'SYMBOL')
    for yy,half in [(545,2.2),(546.1,1.5),(547.2,.7)]:s.ln(211-half,yy,211+half,yy,.3,'SYMBOL')
    feed(201,545,34,'PE','9.1','left','Заземление')
    s.t(34,562,'AG — один общий зажим AO1 и AO2.',2.5)

    # A4: DI 0–7 слева, DO 0–7 справа; C0 и S/S остаются сбоку.
    sheet.heading(506,365,'3.4  A4 · DI / DO и реле K13, K14, K16',318)
    s=MirrorPanel(sheet,1330)
    device(625,378,94,184,'A4','AS16AP11T-A')
    for x,txt,a in [(629,'DO (OUT)','left'),(653,'Адрес','left'),(691,'Адрес','right'),(715,'DI (IN)','right')]:s.t(x,399,txt,2.5,a=a)
    commons('A4','left',625,[408,423],511,'C0','2.4','XD2:04',579)
    commons('A4','right',719,[408,423],824,'S/S','3.4','От C0',767)
    a4=[r for r in DI if r['dev']=='A4']
    s.ln(511,436,511,481);s.arr(511,436,'down');s.t(513,432,'3 /3.1',2.5)
    for i in range(8):
        y=441+i*15
        if i<6:signal('A4',719,y,a4[i],824,767)
        else:
            pin('A4',719,y,'X2.'+str(i),'NC',str(i),'right','X2.'+str(i))
            s.t(728,y+1,'Резерв DI',2.5)
        y=[441,461,481,502,513,524,535,546][i]
        n=DO[12+i]['net'] if i<3 else 'NC'
        pin('A4',625,y,'Y1.'+str(i),n,str(i),'left','Y1.'+str(i))
        if i<3:relay(625,y,511,552,DO[12+i],('5.2',) if i<2 else ())
        else:s.t(513,y+1,'Резерв DO',2.5)
    sheet.t(28,573,'DI/DO — дискретные входы/выходы; AI/AO — аналоговые входы/выходы. IN/OUT — заводские обозначения групп.',2.5)
    sheet.t(28,583,'Резерв: 10 DI; 6 DO (в т. ч. Y1.2 с K16); 3 AI; 1 AO. Клеммы S/S и C0 подписаны без дополнительных индексов.',2.5)
    sheet.finish()
