"""Р25: в тройках B2–B7 сигнал идёт вторым, резерв третьим."""
import re

XT2_SWAP={5:6,6:5,8:9,9:8,11:12,12:11,14:15,15:14,17:18,18:17,20:21,21:20}

def remap(value):
    if isinstance(value,str):
        return re.sub(r'XT2:(\d+)(?!\d)',lambda m:'XT2:'+str(XT2_SWAP.get(int(m[1]),int(m[1]))),value)
    if isinstance(value,list):return [remap(v) for v in value]
    if isinstance(value,tuple):return tuple(remap(v) for v in value)
    if isinstance(value,dict):return {remap(k):remap(v) for k,v in value.items()}
    return value
