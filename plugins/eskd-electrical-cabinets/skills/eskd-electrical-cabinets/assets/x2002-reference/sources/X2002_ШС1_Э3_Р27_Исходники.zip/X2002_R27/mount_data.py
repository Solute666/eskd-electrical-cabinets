"""One mounting model derived from E3 R27 and approved procurement R18."""
import sys,json,re,collections
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
import data
OUT=ROOT/'mount_output';OUT.mkdir(exist_ok=True)
SPEC=json.loads((ROOT/'data/spec_R18.json').read_text())
EDGES=data.EDGES
DEV=json.loads((ROOT/'data/device_terminals_R17.json').read_text())['devices']

# Actual factory mark plus physical position, where identical marks repeat.
MAP={};LOGICAL={};DEVICE_ROWS={}
for dev,obj in DEV.items():
 rows=[]
 for side in ['left','right']:
  for idx,label in enumerate(obj[side]):
   loc=('Л' if side=='left' else 'П')+str(idx+1).zfill(2)
   logical='';pin=None
   if dev=='A1':
    if label=='S/S':pin=dev+':S/S.'+('1' if side=='left' else '2')
    elif label=='C0':pin=dev+':C0.'+('1' if side=='left' else '2')
    else:
     logical=('X0.' if label.startswith('X') else 'Y0.')+label[1:];pin=dev+':'+logical
   elif dev=='A2':
    if label=='S/S':pin=dev+':S/S.'+str(idx+1+(0 if side=='left' else 2))
    else:logical='X1.'+label;pin=dev+':'+logical
   elif dev=='A3':pin=dev+':'+label.replace('−','-').replace('EARTH','FE')
   elif dev=='A4':
    if label in ['S/S','C0']:pin=dev+':'+label+'.'+str(idx+1)
    else:logical=('X2.' if side=='left' else 'Y1.')+label;pin=dev+':'+logical
   physical=dev+':'+label
   if label in ['S/S','C0'] or dev in ['A2','A4']:physical+=' ['+loc+']'
   MAP[pin]=physical
   if logical:LOGICAL[pin]=logical
   rows.append(dict(side=side,row=idx+1,location=loc,label=label,pin=pin,physical=physical,logical=logical))
 DEVICE_ROWS[dev]=rows
for i,label in enumerate(['COM1 +','COM1 −','SG','COM2 +','COM2 −'],1):MAP['A1:RS485.'+str(i)]='A1:'+label
MAP.update({'A8:P1':'A8:ETH 1','A8:P2':'A8:ETH 2','A3:FE':'A3:EARTH','A7:1':'A7:1 (FG)','A7:2':'A7:2 (−)','A7:3':'A7:3 (+)','XJ1:IN':'ШО1.XJ1:IN','XJ1:OUT':'ШО1.XJ1:OUT'})

def physical(pin):
 return MAP.get(pin,pin.replace('A9:PWR.','A9:PWR ').replace('A9:IN.','A9:IN ').replace('A9:OUT.','A9:OUT ').replace('IN16','IN')).replace('−','−')
def natural(s):return [int(t) if t.isdigit() else t for t in re.split(r'(\d+)',str(s))]
def adjacent(pin):
 return [e for e in EDGES if pin in [e['a'],e['b']]]
def size(e):
 v=e['size']
 if v==.205:return '24 AWG'
 if v is None:return 'по кабелю' if e.get('material','').startswith('W7a') else '—'
 return str(v).replace('.',',')+' мм²'
def wirecolor(e):
 if e['size']==.205 and not e.get('material'):return 'белый¹'
 return e['color']
def peer(e,pin):return e['b'] if e['a']==pin else e['a']
def zone(e):
 if e['kind']=='Кабель W8' or e['route']=='Внешний':return 'ШС1 ↔ ШО1'
 p=e['a']+' '+e['b']
 return 'ШО1' if any(s in p for s in ['ШО1.','A7:','SB0.','SB1:','SB2:','SB3:','SB4:','SB5:','HL1:','HL2:','XJ1:']) else 'ШС1'

CONNECTIONS=[]
for i,e in enumerate(sorted(EDGES,key=lambda e:(zone(e),natural(e['net']),natural(e['a']),natural(e['b']))),1):
 note=e.get('note','').strip()
 if e['kind']=='Провод' and e['size']==.205 and not e.get('material'):note='24 AWG, белый; функциональные обозначения на концах. Неподвижно.'
 CONNECTIONS.append(dict(num=i,net=e['net'],a=physical(e['a']),b=physical(e['b']),section=size(e),color=wirecolor(e),zone=zone(e),kind=e['kind'],material=e.get('material',''),note=note,source_id=e['id'],a_raw=e['a'],b_raw=e['b']))

# All external terminal points, sequential arrangement; spare points retained.
EXT=json.loads((ROOT/'data/external_connections_R25.json').read_text())['connections']
TERMINALS=[]
for e in EXT:
 t=e['terminal'];g,n=t.split(':');net=data.PINS.get(t,'NC');cab=e.get('cable','—')
 if g=='XT9' and n=='9':net='NC';cab='W8:11 — изолировать'
 peers=[physical(peer(w,t)) for w in adjacent(t) if w['kind']!='Кабель W8']
 ext=e.get('device','')+':'+str(e.get('pin') or '')
 if g in ['XT8','XT9']:ext='ШО1.'+t
 model='MTU-10PE' if g=='XT1' and n=='PE' else 'MTU-10BL' if g=='XT1' and n=='4' else 'MTU-10' if g=='XT1' else 'MTU-6PE' if g=='XT10' and n=='PE' else 'MTU-6' if g=='XT10' else 'MTU-2.5PE' if n=='PE' else 'MTU-2.5BL' if net=='2' else 'MTU-2.5'
 TERMINALS.append(dict(terminal=t,net=net,local='; '.join(peers) or 'Свободна',external='Не подключать' if net=='NC' else ext,cable=cab,model=model,zone='ШС1'))
for g,nums in [('XT8',['1','2','PE']),('XT9',list(map(str,range(1,10))))]:
 for n in nums:
  p='ШО1.'+g+':'+n;net=data.PINS.get(p,'NC');loc=[physical(peer(w,p)) for w in adjacent(p) if w['kind']!='Кабель W8'];model='MTU-6PE' if n=='PE' else 'MTU-2.5BL' if net=='2' else 'MTU-2.5'
  TERMINALS.append(dict(terminal=p,net=net,local='; '.join(loc) or 'Свободна',external='Не подключать' if net=='NC' else g+':'+n,cable='W8:11 — изолировать' if net=='NC' else 'W8',model=model,zone='ШО1'))
for g,qty,net in [('XD2',11,'2'),('XD3',8,'3'),('XPE1',8,'PE'),('ШО1.XPE1',1,'PE')]:
 for i in range(1,qty+1):
  n=str(i).zfill(2) if g.startswith('XD') else str(i);a=g+':'+n+'a';b=g+':'+n+'b'
  TERMINALS.append(dict(terminal=g+':'+n,net=net,local='; '.join(physical(peer(w,a)) for w in adjacent(a)) or ('Перемычка 01–10' if g=='XD2' and i<=10 else 'Перемычка 01–08' if g=='XD3' else '—'),external='; '.join(physical(peer(w,b)) for w in adjacent(b)) or 'Свободна',cable='a / b — стороны клеммы',model='MTU-2.5PE' if net=='PE' else 'MTU-2.5BL' if net=='2' else 'MTU-2.5',zone='ШО1' if 'ШО1' in g else 'ШС1'))
for g in ['N1','PE1','PE2','ШО1.PE']:
 for i in range(1,16):
  p=g+':'+str(i).zfill(2);es=adjacent(p)
  TERMINALS.append(dict(terminal=p,net=data.PINS.get(p,'NC'),local='; '.join(physical(peer(w,p)) for w in es) or 'Свободна',external='—',cable='Общая шина',model='5015N' if g=='N1' else 'T1615',zone='ШО1' if 'ШО1' in g else 'ШС1'))

# Coordinated procurement positions with installed quantities per one pair.
ASSIGN={1:('ШС1',1),2:('ШО1',1),3:('HL0',1),4:('M2',1),5:('EF1',1),6:('SK1, SK2',2),8:('QS1',1),9:('QF0',1),10:('QF1',1),11:('QF2',1),12:('QF3',1),13:('QF4',1),14:('QFD1',1),15:('KM1',1),16:('Z1',1),17:('FV1',1),18:('XL1–XL3',3),19:('UZ1',1),20:('G2',1),21:('A1',1),22:('G1',1),23:('A2',1),24:('A3',1),25:('A4',1),26:('A7',1),27:('A8',1),28:('A9',1),29:('KSR1',1),30:('KV1',1),31:('K15',1),32:('R1, R2',2),33:('W3, W5',2),34:('ШО1.XJ1',1),35:('ШО1.XJ1',1),36:('K1–K9',9),37:('K1–K9 (колодки)',9),38:('K1–K9 (зажимы)',9),39:('K1–K9 (модули)',9),40:('K10–K14, K16',6),41:('K10–K14, K16 (колодки)',6),42:('SB0',1),43:('SB1',1),44:('SB2',1),45:('SB3',1),46:('SB4, SB5',2),47:('HL1',1),48:('HL2',1),49:('SQ1',1),50:('XS1',1),51:('HL3',1),55:('N1',1),56:('PE1, PE2, ШО1.PE',3),58:('EQS1 (опоры)',2),59:('EQS1 (экраны W6, W21, WA1)',3),60:('EQS1 (экран W2)',1),66:('XT / XD — серые 2,5',82),67:('XT / XD — синие 2,5',21),68:('XPE1, XT8:PE, ШО1.XPE1',10),69:('XT10:1–3',3),70:('XT1:1–3',3),71:('XT1:4',1),72:('XT1:PE',1),73:('XT10:PE, ШО1.XT8:PE',2),75:('XD2:01–10, XD3:01–08',2),77:('FU1–FU10 (держатели)',10),78:('FU1',1),79:('FU2',1),80:('FU3, FU4',2),81:('FU5',1),82:('FU6',1),83:('FU7–FU10',4)}
# 4 clamps per cabinet in procurement; 3 in service + 1 spare (the motor clamp is separate).
ELEMENTS=[]
for row in SPEC:
 n,name,model,brand,qty,unit,note=row;tag,installed=ASSIGN.get(n,('Материалы / запас',None))
 place='ШО1' if n in [2,26,34,35,42,43,44,45,46,47,48] else 'ШС1 / ШО1' if n in [33,56,66,67,68,73] else 'Рама установки' if n==51 else 'ШС1' if installed is not None else 'Общий комплект'
 ELEMENTS.append(dict(spec=n,tag=tag,name=name,model=model,brand=brand,installed=installed,total=installed*2 if installed is not None else None,purchase=qty,spare=qty-installed*2 if installed is not None else None,unit=unit,place=place,note=note or ''))
# Verify exact installed terminal counts from the terminal layout.
c=collections.Counter(t['model'] for t in TERMINALS if t['model'].startswith('MTU'))
for n,model in [(66,'MTU-2.5'),(67,'MTU-2.5BL'),(68,'MTU-2.5PE'),(69,'MTU-6'),(70,'MTU-10'),(71,'MTU-10BL'),(72,'MTU-10PE'),(73,'MTU-6PE')]:assert c[model]==ASSIGN[n][1],(model,c[model],ASSIGN[n])
assert len([t for t in TERMINALS if t['zone']=='ШС1' and t['terminal'].startswith('XT')])==83
assert all(e['spare'] is None or e['spare']>=0 for e in ELEMENTS)
MODELS={}
for n,(tag,qty) in ASSIGN.items():
 if n in [37,38,39,41,35,77] or n>=52 and n not in [55,56]:continue
 for t in tag.split(', '):MODELS[t]=SPEC[n-1][2]
for i in range(1,10):MODELS['K'+str(i)]='MR-203.D [M01] / PYF-022BE/2'
for i in list(range(10,15))+[16]:MODELS['K'+str(i)]='SR-203.D / PYF-011BE/3.24DC.24DC'
MODELS.update({'SB4':SPEC[45][2],'SB5':SPEC[45][2],'SK1':SPEC[5][2],'SK2':SPEC[5][2]})
EXPORT=dict(revision='Р27',spec_revision='Р18',connections=CONNECTIONS,terminals=TERMINALS,elements=ELEMENTS,device_rows=DEVICE_ROWS,models=MODELS,field=data.BASE['field'],counts=dict(connections=len(CONNECTIONS),wire=sum(e['kind']=='Провод' for e in EDGES),terminals=c),notes=[
'Комплект относится к одной паре ШС1 + ШО1; ШС2 + ШО2 выполнить аналогично и независимо.',
'Номер цепи повторяется на электрически общей цепи. № строки в таблице соединений — только идентификатор строки, не маркировка провода.',
'24 AWG применяется на выводах A3. ¹ Белая жила: идентификация цепи и функции на обоих концах; FE не использовать как сигнальный общий.',
'Основные внутренние проводники: 6; 2,5; 0,75 мм². Фазы белые; N синий; +24 В красный; 0 В и коммутируемый минус чёрный; PE жёлто-зелёный.',
'WA1 и W7a — экранированные пары из имеющихся материалов. WA1 должен подходить к зажимам A3: жилы 24 AWG; W7a — по диапазону зажимов ПЛК и АС5.',
'Таблица не задаёт обязательный способ оконцевания. Длины отрезков определять после установки аппаратов и трассировки.',
'Сечение внешнего W1 5G10 и межшкафного W8 12×1,5 сохранено по последней спецификации; замены 16/10/1,5 относятся к внутренним проводам.',
'KSR1 (G9SE): проводники у зажимов 0,75 мм²; допустимый диапазон по OMRON J198-E1 0,25–1,5 мм². Z1 — параллельно KM1:A1–A2.',
'Все адреса у зажимов — непосредственный второй конец провода. Для ПЛК заводская маркировка и программный адрес приведены раздельно.'
])
(OUT/'mount_model_R27.json').write_text(json.dumps(EXPORT,ensure_ascii=False,indent=2))
if __name__=='__main__':print(json.dumps(EXPORT['counts'],ensure_ascii=False))
