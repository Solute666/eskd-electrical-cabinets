#!/usr/bin/env python3
"""Vector mounting diagrams, element schedule and connection table, R27."""
from pathlib import Path
import sys,json,re,math,collections
import fitz
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
import draw
from mount_data import *
draw.OUT=OUT
draw.SHEETS.clear();draw.PINS.clear();draw.REFERENCES.clear()
E4=[];TEXTDOC=[];GRAPH_PINS=set();PLACEMENTS=[]

def new(n,title,code='Э4',size='A1',total=12):
 s=draw.Sheet(n,title,size,27,code,total)
 (E4 if code=='Э4' else TEXTDOC).append(s)
 return s

def note(s,x,y,text,w=790):return s.paragraph(x,y,text,w,2.5,6)
def table(s,x,y,widths,heads,rows,rh=11,h=2.5):
 allrows=[heads]+rows
 yy=y
 for k,row in enumerate(allrows):
  lines=[s.wrap('' if v is None else str(v),w-4,h,k==0) for v,w in zip(row,widths)]
  ht=max(rh,max(len(t) for t in lines)*5.1+4)
  xx=x
  for txt,w in zip(lines,widths):
   s.rect(xx,yy,w,ht,.2,'NOTES')
   for j,line in enumerate(txt):s.t(xx+2,yy+5.5+j*5.1,line,h,k==0)
   xx+=w
  yy+=ht
 return yy

def dim(s,x1,y1,x2,y2,label):
 s.ln(x1,y1,x2,y2,.2,'MECHANICAL')
 if y1==y2:
  for x in [x1,x2]:s.ln(x-1.5,y1+1.5,x+1.5,y1-1.5,.25,'MECHANICAL')
  s.t((x1+x2)/2,y1-2,label,2.5,a='center')
 else:
  for y in [y1,y2]:s.ln(x1-1.5,y+1.5,x1+1.5,y-1.5,.25,'MECHANICAL')
  s.t(x1-3,(y1+y2)/2,label,2.5,a='center',rot=90)

def board():
 s=new(1,'ШС1. Размещение аппаратов и трассы')
 ox,oy,k=50,65,.50
 def box(x,y,w,h,tag,desc='',rotate=False):
  s.rect(ox+x*k,oy+y*k,w*k,h*k,.35,'MECHANICAL')
  if tag:s.t(ox+(x+w/2)*k,oy+(y+h/2)*k+1,tag,2.4,True,'center',rot=90 if rotate else 0)
  PLACEMENTS.append([tag,x,y,w,h,desc])
 def duct(x,y,w,h,text):
  s.rect(ox+x*k,oy+y*k,w*k,h*k,.25,'MECHANICAL',True)
  s.t(ox+(x+w/2)*k,oy+(y+h/2)*k+1,text,2.3,a='center',rot=90 if h>w else 0)
 s.rect(ox,oy,750*k,950*k,.6,'MECHANICAL');dim(s,ox,oy-8,ox+750*k,oy-8,'750*');dim(s,ox-12,oy,ox-12,oy+950*k,'950*')
 duct(0,0,40,950,'Управление · 40×60');duct(690,0,60,950,'Силовые цепи · 60×80')
 duct(40,170,650,40,'40×60');duct(40,410,460,40,'40×60');duct(40,805,460,40,'40×60')
 x=60
 for tag,w in [('QF0',54),('QF1',54),('QF2',36),('QF3',36),('QF4',36),('QFD1',36),('FV1',72),('XL1',28),('XL2',28),('XL3',28)]:
  box(x,25,w,85,tag,rotate=w<45);x+=w+7
 box(530,125,114,27,'PE2')
 box(65,265,40,123.6,'G2',rotate=True);box(175,245,40,130,'A8',rotate=True);box(245,245,54,106,'A9')
 box(330,245,18,93,'KV1',rotate=True);box(460,505,22.5,124,'KSR1',rotate=True)
 box(430,245,84,68,'FU1–10');box(545,245,57,86,'KM1')
 box(530,400,114,30,'N1')
 s.rect(ox+55*k,oy+450*k,382.6*k,208.3*k,.2,'MECHANICAL',True)
 s.rect(ox+450*k,oy+455*k,42.5*k,224*k,.2,'MECHANICAL',True)
 x=110
 for tag,w in [('G1',78),('A1',80),('A2',38.2),('A3',38.2),('A4',38.2)]:box(x,505,w,98.3,tag);x+=w
 box(550,500,109,207,'UZ1');s.rect(ox+520*k,oy+450*k,169*k,307*k,.2,'MECHANICAL',True)
 s.t(ox+300*k,oy+640*k,'Свободная зона ПЛК ≥50 мм',2.3,a='center')
 x=80
 for i in range(1,17):
  w=16 if i<=9 else 6.2 if i==15 else 6.3
  box(x,690,w,95,'K'+str(i),rotate=True);x+=w+3
 box(355,710,57.2,56.5,'XD2',rotate=True);box(418,710,41.6,56.5,'XD3',rotate=True);box(466,710,41.6,56.5,'XPE1',rotate=True)
 box(530,780,114,27,'PE1');box(670,760,10,150,'EQS1',rotate=True)
 x=60
 for g in ['XT'+str(i) for i in range(1,12)]:
  ts=[t for t in TERMINALS if t['terminal'].split(':')[0]==g]
  w=sum(10.2 if '10' in t['model'] else 8.2 if t['model'].startswith('MTU-6') else 5.2 for t in ts)
  box(x,875,w,50,'');s.t(ox+(x+w/2)*k,oy+(866 if int(g[2:])%2 else 941)*k,g,2.1,a='center')
  PLACEMENTS[-1][0]=g;x+=w+8
 s.t(50,551,'* Компоновочное поле. Фактическую плату корпуса сверить перед разметкой.',2.5)
 s.t(50,560,'ШС1: 1000×800×400 мм. Вид спереди; масштаб изображения 1:2.',2.5)
 s.heading(450,55,'Ряды и оборудование',374)
 table(s,450,67,[35,339],['Зона','Состав и назначение'],[
 ['Верх','QF0–QF4, QFD1, FV1, XL1–XL3; PE2 рядом с FV1.'],
 ['Ряд 2','G2, A8, A9, KV1, FU1–FU10, KM1 с Z1.'],
 ['Ряд 3','G1 → A1 → A2 → A3 → A4; KSR1; UZ1 справа.'],
 ['Ряд 4','K1–K16; XD2, XD3 и XPE1.'],
 ['Низ','XT1–XT11 слева направо. Номера внутри группы возрастают слева направо.'],
 ['Боковина','QS1 — правая стенка, доступная рукоятка 0–1; M2 — внизу, EF1 — вверху противоположной стороны.'],
 ['Прочее','HL0 — сверху внутри; XS1 — внутри двери; SQ1 — у двери; SK1/SK2 — в верхней зоне.']
 ],rh=24)
 y=290
 for text in [
 'Корпус DKC R5ST1084 с комплектной монтажной платой. Координаты аппаратов — для компоновки; отверстия выполняются по шаблонам фактически поставленных изделий.',
 'Пунктир вокруг ПЛК, KSR1 и ПЧ — зона охлаждения. KSR1: сверху/снизу 50 мм. Зазоры ПЧ: сверху/снизу не менее 50 мм, по бокам не менее 30 мм. В этих зонах не устанавливать другие аппараты.',
 'Силовые провода UZ1 и W2 вести по правой трассе. Сигналы, Ethernet, RS-485 и WA1 — по левой трассе; пересечение с силовыми проводами под прямым углом.',
 'Шлейфы и ответвления выполнять по адресам таблицы соединений. Длины проводов определять по фактической трассе; длины старой компоновки не применять.',
 'Эта схема размещения не является шаблоном сверления. Учитывать вводы кабелей, загибы жил, открывание двери и доступ к зажимам.'
 ]:y=note(s,450,y,text,374)+9
 s.finish()

def operator_layout():
 s=new(2,'ШО1. Расположение и межшкафные подключения')
 s.heading(28,52,'Дверь · вид спереди',350)
 ox,oy,k=58,79,.65
 s.rect(ox,oy,400*k,500*k,.5,'MECHANICAL');dim(s,ox,oy-8,ox+400*k,oy-8,'400');dim(s,ox-10,oy,ox-10,oy+500*k,'500')
 s.rect(ox+95*k,oy+55*k,210*k,155*k,.35);s.t(ox+200*k,oy+120*k,'A7',4,True,'center');s.t(ox+200*k,oy+141*k,'OTP210-070E',2.7,a='center')
 for x,y,tag,label in [(75,300,'SB0','Аварийный стоп'),(200,300,'SB1','Пуск'),(325,300,'SB2','Стоп'),(75,395,'SB3','Сброс'),(200,395,'SB4','Головка вверх'),(325,395,'SB5','Головка вниз'),(150,455,'HL1','Сеть'),(280,455,'HL2','Авария')]:
  s.circle(ox+x*k,oy+y*k,7);s.t(ox+x*k,oy+y*k-10,tag,2.7,True,'center');s.t(ox+x*k,oy+y*k+15,label,2.5,a='center')
 note(s,28,428,'ШО1: DKC R5ST0542, 500×400×200 мм. Положение показано схемно; размеры выреза A7 и отверстий — по шаблонам поставленных аппаратов.',350)
 s.heading(402,52,'Плата и внутренняя сторона двери',422)
 s.rect(445,78,350*.62,450*.62,.5,'MECHANICAL');dim(s,445,70,662,70,'350');dim(s,436,78,436,357,'450')
 s.rect(463,290,90,31,.35);s.t(508,308,'XT8 → XT9',3,True,'center')
 s.rect(579,290,63,31,.35);s.t(610.5,308,'XJ1',3,True,'center')
 s.rect(463,245,70,22,.35);s.t(498,260,'PE',3,True,'center')
 s.rect(550,245,35,22,.35);s.t(567.5,260,'XPE1',2.5,True,'center')
 s.t(553.5,105,'Резерв места / зона за панелью A7',2.5,a='center')
 note(s,685,93,'W8: ввод через нижнюю стенку. XT8 — питание; XT9 — аварийный стоп, кнопки и HL2. Нумерация клемм одинакова в обоих шкафах.',135)
 note(s,685,205,'W4: Ethernet через XJ1. W5: XJ1 → A7. PE двери отдельным гибким проводом 6 мм².',135)
 table(s,402,382,[30,39,66,103,184],['Кабель','Жила','Цепь','ШС1 → ШО1','Назначение'],[
 ['W8','1','8','XT8:1 → XT8:1','+24 В ШО1'],['W8','2','2','XT8:2 → XT8:2','0 В'],['W8','PE','PE','XT8:PE → XT8:PE','Защитный проводник'],['W8','3–10','6, 13, 20–24, 107','XT9:1–8 → XT9:1–8','SB0; SB1–SB5; HL2'],['W8','11','—','XT9:9 свободны','Жилу изолировать с двух сторон'],['W4','RJ45','Ethernet','A8:2 → XJ1:IN','8 контактов, 1:1']
 ],rh=18)
 note(s,28,480,'Местное питание ШО1 — шлейфом по Э3/8.2. Дополнительные группы XD8 и XD2 в ШО1 не устанавливать. В ШО1 не соединять 0 В с PE.',350)
 note(s,28,534,'HL3 устанавливается на раме машины и подключается к XT11 силового шкафа.',350)
 s.finish()

def plc_sheet(n,devices):
 s=new(n,'ПЛК и модули. Монтажные адреса · '+', '.join(devices))
 note(s,28,48,'Вид спереди. Заводские обозначения у корпуса; Л/П — сторона и номер позиции сверху. Программный адрес подписан отдельно.')
 for xx,dev in zip([28,436],devices):
  w=386;dx=xx+148;dw=90;top=93;rows=DEVICE_ROWS[dev];count=max(r['row'] for r in rows);pitch=31 if count<=10 else 27
  s.t(xx+w/2,73,dev+' · '+MODELS[dev],3.3,True,'center');s.rect(dx,top,dw,count*pitch+10,.45)
  for side in ['left','right']:
   for r in [z for z in rows if z['side']==side]:
    yy=top+19+(r['row']-1)*pitch;left=side=='left';x=dx if left else dx+dw;p=r['pin'];es=adjacent(p);GRAPH_PINS.add(p)
    s.circle(x,yy,1.1)
    s.t(x+(3 if left else -3),yy+1,r['label'],2.5,a='left' if left else 'right')
    s.t(x+(3 if left else -3),yy+9,r['location']+(' · '+r['logical'] if r['logical'] else ''),2,a='left' if left else 'right')
    if not es:
     s.t(x+(-5 if left else 5),yy+1,'Свободно',2.5,a='right' if left else 'left');continue
    net=es[0]['net'];a=x-23 if left else x+23
    s.ln(a,yy,x,yy,.35);s.t((a+x)/2,yy-3,net,2.5,a='center')
    dest='; '.join(physical(peer(e,p)) for e in es)
    lines=s.wrap(dest,118,2.4)
    for j,line in enumerate(lines):s.t(xx+2 if left else x+27,yy-3+j*5.5,line,2.4)
  s.t(xx+193,top+count*pitch+26,'Все адреса — непосредственные концы проводов.',2.4,a='center')
 if n==3:
  note(s,28,484,'Системная шина: G1 → A1 → A2 → A3 → A4. Соединение штатными боковыми разъёмами.')
  table(s,28,500,[50,96,151,100,399],['A1 · COM','Вывод','Номер цепи','Элемент','Подключение'],[
  ['COM1','+ / − / SG','120 / 121 / 122','R1 = 120 Ом','XT6:1 / 2 / 3; R1 между + и − COM1.'],['COM2','+ / −','130 / 131','R2 = 120 Ом','W7a → A9:OUT 1 / OUT 3; R2 между + и − COM2.']
  ],rh=18)
 else:
  note(s,28,482,'A3: все проводники у модуля — 24 AWG. WA1: экранированная пара 24 AWG из имеющихся материалов; экран только на EQS1.')
  note(s,28,499,'A3: V1+ соединить с I1+ для токового AI1. VI1− — цепь 2; IO1 — цепь 110; AG — цепь 111. VO1 не подключать.')
  note(s,28,516,'A4: левые 0–7 — DI, правые 0–7 — DO. Адреса X2.n / Y1.n не являются заводской маркировкой клемм.')
  note(s,28,533,'Каналы A2:8–15, A4:DI6–7 и DO3–7 свободны; DO2 подключён к резервному K16.')
 s.finish()

def device_pins(dev):
 ps={p for e in EDGES for p in [e['a'],e['b']] if p.split(':')[0]==dev}
 if re.fullmatch(r'K\d+',dev):
  i=int(dev[1:]);ps|={dev+':'+p for p in (['A1','A2','11','12','14','21','22','24'] if i<=9 else ['A1','A2','11','12','14'])}
 if dev=='KSR1':ps|={'KSR1:'+p for p in ['T11','T21']}
 if dev=='KV1':ps.add('KV1:12')
 def order(p):
  pin=p.split(':',1)[1]
  order=['A1','A2','T11','T12','T21','T22','T31','T32','T33','13','14','23','24','33','34','43','44','X1'] if dev=='KSR1' else ['A1','A2','11','12','14','21','22','24'] if dev.startswith('K') and dev!='KM1' else []
  return (0,order.index(pin)) if pin in order else (1,natural(pin))
 return sorted(ps,key=order)

def card(s,x,y,w,dev,pins=None):
 pins=pins if pins is not None else device_pins(dev)
 rowh=11;titleh=24;h=titleh+len(pins)*rowh+4
 s.rect(x,y,w,h,.4,'SYMBOL');s.t(x+4,y+7,dev,3.2,True)
 model=MODELS.get(dev,'')
 for j,line in enumerate(s.wrap(model,w-42,2.3)):
  s.t(x+40,y+6+j*5,line,2.3)
 s.ln(x,y+19,x+w,y+19,.2,'NOTES')
 s.t(x+4,y+24,'Вывод',2,True);s.t(x+45,y+24,'Цепь',2,True);s.t(x+78,y+24,'Непосредственное соединение',2,True)
 for i,p in enumerate(pins):
  yy=y+32+i*rowh;es=adjacent(p);GRAPH_PINS.add(p)
  mark=physical(p).split(':',1)[1] if ':' in physical(p) else physical(p)
  s.t(x+4,yy,mark,2.3)
  s.t(x+47,yy,es[0]['net'] if es else '—',2.3)
  dest='; '.join(physical(peer(e,p)) for e in es) if es else 'Свободно'
  lines=s.wrap(dest,w-80,2.3)
  if len(lines)>2:raise ValueError(('too many',dev,p,dest))
  for j,line in enumerate(lines):s.t(x+78,yy+j*4.9,line,2.3)
 return h

def cards_page(n,title,devs,columns=3):
 s=new(n,title);note(s,28,47,'Адресный способ: напротив каждого вывода указан второй конец провода. «Цепь» — его маркировка; свободные контакты не подключать.')
 width=(796-(columns-1)*10)/columns;ys=[59]*columns
 for dev in devs:
  pins=device_pins(dev);ht=28+len(pins)*11;col=min(range(columns),key=lambda j:ys[j])
  if ys[col]+ht>564:raise ValueError(('page overflow',n,dev,ys,ht))
  actual=card(s,28+col*(width+10),ys[col],width,dev,pins);ys[col]+=actual+11
 if n==6:
  note(s,28,550,'KSR1: все проводники 0,75 мм². Z1 SR2-A подключить параллельно KM1:A1–A2 (цепи 19 / 2).')
 s.finish()

def terminal_pages():
 for n,(a,b) in enumerate([(1,2),(3,7),(8,11)],9):
  s=new(n,f'Клеммы ШС1. XT{a}–XT{b}')
  note(s,28,47,'Внутри шкафа показаны номер цепи и непосредственный конец провода; справа — внешний кабель и устройство. Клеммы прямоугольные.')
  ts=[t for t in TERMINALS if t['zone']=='ШС1' and t['terminal'].startswith('XT') and a<=int(t['terminal'].split(':')[0][2:])<=b]
  y=59
  table(s,28,y,[37,21,234,105,70,329],['Клемма','Цепь','Внутренние провода → аппарат','Тип клеммы','Кабель','Внешняя сторона → устройство'],[[t[k] for k in ['terminal','net','local','model','cable','external']] for t in ts],rh=12)
  note(s,28,551,'Свободные клеммы XT2:6, 9, 12, 15, 18, 21 и XT9:9 сохранены. На проводах вне шкафа местные номера цепей не дублируются как межлистовые ссылки.')
  s.finish()
 s=new(12,'Внутренние распределительные клеммы и шины')
 note(s,28,47,'a — сторона ввода, b — сторона отходящего провода; a/b — проектное различение сторон одной проходной клеммы.')
 ts=[t for t in TERMINALS if t['terminal'].startswith(('XD','XPE1','ШО1.XPE1'))]
 table(s,28,61,[40,20,105,191,440],['Клемма','Цепь','Тип','Сторона a','Сторона b'],[[t[k] for k in ['terminal','net','model','local','external']] for t in ts],rh=13)
 note(s,28,473,'XD3: штатная перемычка 01–08. XD2: штатная перемычка 01–10 и отдельный провод 2,5 мм² между 10a и 11a.')
 note(s,28,491,'Шины N1, PE1, PE2 и ШО1.PE: назначения каждого из 15 зажимов приведены в Excel «Клеммы» и на Э3/11; защитные связи — Э3/9.')
 note(s,28,509,'XL1–XL3: IN и O1…O4 — проектные обозначения зажимов распределительного блока, заводские номера не предполагаются.')
 note(s,28,527,'Связь 0 В–PE: G2:−V → PE1:15, чёрный 2,5 мм²; единственная постоянная связь. PE UZ1: PE1:12 → UZ1:PE, 6 мм².')
 note(s,28,545,'EQS1: экраны W2, WA1, W6, W21. W7 и W7a к EQS1 не подключать; экраны заканчиваются на раздельных сторонах АС5.')
 s.finish()

# Text documents use A2 landscape: legible print tables, repeated headers.
def paginated_table(code,title,widths,heads,rows,maxy=347,notes=()):
 # Precompute pagination with same font metrics.
 dummy=draw.Sheet.__new__(draw.Sheet)
 pages=[];page=[];yy=59
 for row in rows:
  height=max(11,max(len(dummy.wrap('' if v is None else str(v),w-4,2.5)) for v,w in zip(row,widths))*5.1+4)
  if yy+height>maxy and page:pages.append(page);page=[];yy=59
  page.append(row);yy+=height
 if page:pages.append(page)
 for i,rows2 in enumerate(pages,1):
  s=new(i,title,code,'A2',len(pages));note(s,28,45,'Основание: X2002.Э3 Р27 и спецификация Р18 от 29.09.2026. Одна позиция ШС1 + ШО1; вторая — аналогично.',558)
  table(s,28,54,widths,heads,rows2,rh=11)
  y=360
  for text in notes[:3]:y=note(s,28,y,text,350 if i==1 else 558)+5
  s.finish()
 return pages

board();operator_layout();plc_sheet(3,['A1','A2']);plc_sheet(4,['A3','A4'])
cards_page(5,'Промежуточные реле K1–K9',['K'+str(i) for i in range(1,10)])
cards_page(6,'Промежуточные реле, безопасность и контроль',['KSR1','K15','KV1','K10','K11','K12','K13','K14','K16','KM1'])
cards_page(7,'Силовые и вспомогательные аппараты',['QS1','QF0','QF1','QF2','QF3','QF4','QFD1','FV1','G1','G2','M2','HL0','XS1','SK1','SK2','SQ1'],columns=4)
# UZ1 and interfaces + FU groups. To keep drawings uncluttered, fuse routes tabulated below.
s=new(8,'ПЧ, связь и предохранители. Монтажные адреса')
note(s,28,47,'WA1 и W7a — из имеющихся материалов. Подключать по маркировке зажимов, сохраняя экран и полярность пары.')
card(s,28,62,260,'UZ1');card(s,302,62,252,'A9');card(s,568,62,256,'A8')
rows=[]
for i in range(1,11):
 p1,p2=f'FU{i}:1',f'FU{i}:2';es1,es2=adjacent(p1),adjacent(p2);GRAPH_PINS.update([p1,p2])
 rows.append([f'FU{i}',next((r[1] for r in data.FUSES if r[0]==f'FU{i}'),'8')+' A',data.net(p1),'; '.join(physical(peer(e,p1)) for e in es1),data.net(p2),'; '.join(physical(peer(e,p2)) for e in es2)])
table(s,28,333,[30,25,22,290,22,407],['FU','Вставка','Цепь 1','Вывод 1 →','Цепь 2','Вывод 2 →'],rows,rh=16)
note(s,28,537,'FU1–FU10: 1/2 — проектное обозначение входа/выхода держателя. Свободные выводы UZ1 не подключать; +24V–S1–S2 снять по Э3/4.')
note(s,28,553,'Питание A8: P1+/P1−; P2+/P2− свободны. Порты Ethernet: 1 — ПЛК, 2 — ШО1, 3 — сервис, 4–5 — резерв.')
s.finish()
terminal_pages()

rows=[[str(r['num']),r['net'],r['a'],r['b'],r['section'],r['color'],r['zone'],(r['material']+'; ' if r['material'] else '')+r['note']] for r in CONNECTIONS]
paginated_table('ТЭ4','Таблица электрических соединений',[14,23,83,83,36,40,29,248],['№','Цепь','Откуда: вывод','Куда: вывод','Сечение','Цвет','Шкаф','Примечание'],rows,notes=['¹ Белый 24 AWG у A3: функция и номер цепи на обоих концах. Длина — по фактической трассе.','№ строки не является маркировкой провода. Адреса с Л/П — позиции зажимов при виде спереди.'])
rows=[[e['tag'],e['name'],e['model'],str(e['installed']) if e['installed'] is not None else '—',str(e['total']) if e['total'] is not None else '—',str(e['purchase']),str(e['spare']) if e['spare'] is not None else '—',e['unit'],str(e['spec'])] for e in ELEMENTS]
paginated_table('ПЭ3','Перечень элементов и материалов',[87,199,130,26,26,28,28,17,15],['Обозначение','Наименование','Тип / артикул','На пару','На 2 пары','Закупка','ЗИП / запас','Ед.','Спец.'],rows,notes=['Колонки «На пару / На 2 пары» — установленное оборудование; закупка и запас отдельно.','«—» у материалов: расход по месту, а не нулевое количество. Метраж сохранён по спецификации Р18.','WA1 и W7a используются из имеющихся материалов; в закупку не включены.'])

# Combine PDFs; make a single, compact report for final geometry and connectivity QA.
for code,title,outname in [('Э4','Монтажные схемы','X2002_ШС1_Монтажная_схема_Р27.pdf'),('ПЭ3','Перечень элементов','X2002_ШС1_Перечень_элементов_Р27.pdf'),('ТЭ4','Таблица соединений','X2002_ШС1_Таблица_соединений_Р27.pdf')]:
 sheets=sorted([s for s in draw.SHEETS if s.code==code],key=lambda s:s.n);d=fitz.open()
 for s in sheets:
  with fitz.open(OUT/(s.name+'.pdf')) as part:d.insert_pdf(part)
 d.set_toc([[1,f'{s.n}. {s.title}',s.n] for s in sheets]);d.set_metadata({'title':'X2002. '+title+'. Р27','subject':'Э3 Р27 / спецификация Р18; 29.09.2026','author':''});d.save(OUT/outname,garbage=4,deflate=True)

bounds=[];overlap=[];audits=[]
for s in draw.SHEETS:
 ts=[t for t in s.texts if t['layer']=='TEXT' and t['text']]
 for t in ts:
  x,y,r,b=t['bbox']
  if x<21 or r>s.W-6 or y<5 or b>s.H-20:bounds.append([s.code,s.n,t['text'],t['bbox']])
 for i,a in enumerate(ts):
  for b in ts[i+1:]:
   aa=a['bbox'];bb=b['bbox'];dx=min(aa[2],bb[2])-max(aa[0],bb[0]);dy=min(aa[3],bb[3])-max(aa[1],bb[1])
   if dx>.6 and dy>.6:overlap.append([s.code,s.n,a['text'],b['text']])
 au=s.doc.audit();audits.append([s.code,s.n,len(au.errors),len(au.fixes)])
(OUT/'layout_positions_R27.json').write_text(json.dumps(PLACEMENTS,ensure_ascii=False,indent=2))
report=dict(pages={code:len([s for s in draw.SHEETS if s.code==code]) for code in ['Э4','ПЭ3','ТЭ4']},bounds=bounds,overlaps=overlap,dxf_audits=audits,connections=len(CONNECTIONS),terminals=len(TERMINALS),terminal_counts=EXPORT['counts']['terminals'],graph_pins=len(GRAPH_PINS),all_connections_listed=True)
(OUT/'Проверка_монтажа_Р27.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,ensure_ascii=False,indent=2))
if bounds or overlap or any(a[2] or a[3] for a in audits):sys.exit(2)
