"""Лист 2 Р15. Уточнено изображение выводов 11 и 14 KV1."""
from draw import *
from data import *


class ControlSheet(Sheet):
    """Круглые зажимы цепей управления; другие листы не затрагиваются."""
    def term(self,x,y,label='',below=False,pin=None,net=None):
        r=1.15
        self.term_windows.append((x-r,y-r,x+r,y+r))
        self.c.saveState()
        self.c.setFillColorRGB(1,1,1)
        self.c.circle(x*mm,(self.H-y)*mm,r*mm,stroke=0,fill=1)
        self.c.restoreState()
        self.circle(x,y,r)
        if label:self.t(x,y+(8.8 if below else -3.2),label,2.5,a='center')
        if pin is not None:register(pin,net,self.n)

    def fuse(self,x,y,tag,rating):
        self.ln(x-14,y,x+14,y)
        self.rect(x-5,y-2,10,4)
        self.rect(x-14,y-5,28,10,.2,'MECHANICAL',True)
        self.term(x-14,y,'1',True)
        self.term(x+14,y,'2',True)
        self.t(x,y-9,tag,3,True,'center')
        self.t(x,y+12,rating,2.5,a='center')


def incoming(s,x,y,end,n,ref,label=''):
    s.ln(x,y,end,y);s.arr(x,y)
    s.t(x+2,y-4,f'{n} /{ref}',2.5)
    if label:s.t(x+2,y+7,label,2.5)


def outgoing(s,x,y,end,n,ref,label=''):
    s.ln(x,y,end,y);s.arr(end,y)
    s.t(end-2,y-4,f'{n} /{ref}',2.5,a='right')
    if label:s.t(end-2,y+7,label,2.5,a='right')


def dc():
    s=ControlSheet(2,'Питание 24 В, предохранители и аварийный останов','A1',revision=27)
    s.heading(28,49,'2.1  Питание 24 В и предохранители',280)
    s.rect(32,89,64,66)
    s.t(64,104,'G2',3.5,True,'center')
    s.t(64,116,'DRL-24V240W1EN',2.5,a='center')
    s.t(64,128,'24 В DC; 10 А',2.5,a='center')
    for x,p,n in [(45,'L','C8'),(83,'N','N3')]:
        s.ln(x,68,x,89);s.arr(x,89,'down')
        s.t(x,64,n+' /1.1',2.5,a='center')
        s.t(x,94,p,2.5,a='center');register('G2:'+p,n,2)
    s.pin(96,139,'G2:+V','1','+V','right')
    s.ln(96,139,116,139);s.dot(116,139)
    s.ln(116,82,116,242,.5)
    s.t(121,69,'1 · +24 В',2.5)
    s.pin(96,149,'G2:-V','2','−V','right')
    s.poly([(96,149),(104,149),(104,273),(218,273)],.5)
    s.arr(218,273);s.t(216,269,'2 /2.4',2.5,a='right')
    s.pin(50,155,'G2:-V','2')
    s.t(50,151,'−V (2)',2.5,a='center')
    s.ln(50,155,50,199);s.earth(50,199)
    s.lines(29,216,['2 → PE1:15 /9.1','Постоянная связь','0 В–PE; 2,5 мм².'],2.5,7)
    fuse_dest=[('2.4','Реле, индикация, связь'),('6.1','Датчики и разрешения'),
               ('4.2','Аналоговый модуль, BP1'),('2.2,2.3','KSR1 и входы STO'),
               ('2.3','Контактор и клапаны'),('8.2','ШО1: панель и кнопки')]
    for i,(fu,rating,n,bank,function) in enumerate(FUSES):
        y=82+32*i
        s.dot(116,y);s.ln(116,y,146,y)
        s.t(129,y-4,'1',2.5)
        s.fuse(160,y,fu,'T '+rating+' А')
        s.ln(174,y,307,y);s.arr(307,y)
        ref,desc=fuse_dest[i]
        s.t(305,y-4,n+' /'+ref,2.5,a='right')
        s.t(199,y+11,desc,2.5)
        if i==5:s.term(229,y,'XT8:1',pin='XT8:1',net='8')
        register(fu+':1','1',2);register(fu+':2',n,2)
    s.t(118,287,'Входы FU1–FU6: проводной шлейф 2,5 мм².',2.5)

    s.heading(340,49,'2.2  KSR1 · аварийный останов и ручной сброс',480)
    s.rect(617,76,97,215,.5)
    s.t(665.5,88,'KSR1',3.5,True,'center')
    s.t(665.5,103,'G9SE-401',3,True,'center')
    s.t(665.5,116,'24 В DC',2.5,a='center')
    for y,p,n in [(96,'A1','6'),(119,'T33','6'),(157,'T12','13'),
                  (180,'T22','13'),(215,'T31','16'),(257,'T32','15')]:
        s.pin(617,y,'KSR1:'+p,n,p)
    for y,p,n in [(157,'T11','NC'),(180,'T21','NC'),(237,'X1','33'),(277,'A2','2')]:
        s.pin(714,y,'KSR1:'+p,n,p,'right')
    incoming(s,544,96,617,'6','2.1')
    s.poly([(595,96),(595,119),(617,119)]);s.dot(595,96)
    s.t(602,115,'6',2.5)
    s.t(548,87,'+24 В от FU4',2.5)
    s.lines(735,112,['T33: +24 В — ручной сброс.','T11 и T21 не подключать:','одноканальный вход.'],2.5,8)
    for y in [157,180]:
        s.ln(714,y,731,y);s.t(737,y+1,'Свободен',2.5)
    outgoing(s,714,237,817,'33','3.2','A2:IN5 · состояние KSR1')
    outgoing(s,714,277,817,'2','2.4')

    incoming(s,341,157,464,'6','2.1')
    s.term(385,157,'XT9:1',pin='XT9:1',net='6')
    s.rect(412,130,139,70,.25,'MECHANICAL',True)
    s.t(416,138,'ШО1 · SB0 · кабель W8 /8.2',2.5,True)
    s.contact(476,157,'SB0.1',('1','2'),True)
    register('SB0.1:1','6',2);register('SB0.1:2','13',2)
    s.ln(488,157,617,157);s.t(562,153,'13',2.5)
    s.term(583,157,'XT9:2',pin='XT9:2',net='13')
    s.poly([(583,157),(583,180),(617,180)])
    s.t(605,176,'13',2.5)
    s.lines(418,184,['Один НЗ контакт; 2 жилы W8.','+24 В через SB0.1 → T12 и T22.'],2.5,8)

    s.ln(568,215,617,215);s.arr(568,215,'left')
    s.t(572,211,'16 /2.2',2.5)
    s.t(570,224,'К K15:11',2.5)
    incoming(s,341,257,405,'16','2.2','От KSR1:T31')
    s.contact(417,257,'K15',('11','14'))
    s.ln(429,257,493,257);s.t(461,253,'14',2.5,a='center')
    s.contact(505,257,'K1',('21','22'),True)
    s.ln(517,257,617,257);s.t(567,253,'15',2.5,a='center')
    s.t(417,278,'Катушка ниже /2.2',2.5,a='center')
    s.t(505,278,'Катушка /3.1',2.5,a='center')
    s.t(674,343,'K1: команда пуска снята.',2.5)
    s.t(674,351,'Контроль залипания KM1 отсутствует.',2.5)
    for p,n in [('K15:11','16'),('K15:14','14'),('K1:21','14'),('K1:22','15')]:register(p,n,2)
    s.t(341,302,'SB3 · общий сброс с панели ШО1',3,True)
    incoming(s,341,322,512,'22','8.2')
    s.term(406,322,'XT9:5',pin='XT9:5',net='22')
    s.coil(528,322,'K15',internal=True)
    outgoing(s,544,322,650,'2','2.4')
    s.poly([(406,322),(406,350),(614,350)]);s.arr(614,350)
    s.t(612,346,'22 /3.1',2.5,a='right')
    s.t(612,359,'A1:X2 · адрес X0.2',2.5,a='right')
    s.lines(674,307,['K15 · Finder 38.51.7.024.5050',
                     'SB0 отпущен; K1 выключен.',
                     'SB3: нажать ≥0,3 с и отпустить.',
                     'От XT9:5 два провода: к K15 и ПЛК.'],2.5,8)
    register('K15:A1','22',2);register('K15:A2','2',2)

    s.heading(340,382,'2.3  Выходы KSR1 и контроль 24 В',480)
    for i,(fu,src,n,pin) in enumerate(FU_SAFETY):
        y=[414,451,488,535][i]
        incoming(s,341,y,374,src,'2.1')
        s.fuse(388,y,fu,'T 8 А')
        s.ln(402,y,464,y);s.t(435,y-4,n,2.5,a='center')
        op=str(int(pin)+1);s.contact(476,y,'KSR1',(pin,op))
        on=['17','18','9','19'][i]
        if i<3:
            ref='4.1' if i<2 else '5.1'
            label=['UZ1:S1 · STO 1','UZ1:S2 · STO 2','K2–K7 · клапаны'][i]
            outgoing(s,488,y,639,on,ref,label)
        else:
            s.ln(488,y,648,y);s.t(561,y-4,'19',2.5,a='center')
            s.coil(664,y,'KM1',left='',right='')
            s.t(640,y+6,'A1+',2.5,a='right');s.t(688,y+6,'A2−',2.5)
            outgoing(s,680,y,817,'2','2.4')
            s.poly([(648,y),(648,y+18),(652,y+18)])
            s.rect(652,y+15.5,7,5);s.ln(659,y+18,668,y+18)
            s.ln(668,y+14,668,y+22);s.ln(672,y+14,672,y+22)
            s.poly([(672,y+18),(680,y+18),(680,y)])
            s.dot(648,y);s.dot(680,y)
            s.t(693,y+20,'Z1 · SR2-A',2.5)
            s.t(591,570,'KM1 · NC1-3210Z · 24 В DC',2.5)
            s.t(341,560,'Все провода у KSR1 — 0,75 мм².',2.5)
            s.t(817,570,'Силовые контакты /1.1',2.5,a='right')
            register('KM1:A1','19',2);register('KM1:A2','2',2)
        for p,nn in [(fu+':1',src),(fu+':2',n),('KSR1:'+pin,n),('KSR1:'+op,on)]:register(p,nn,2)

    s.rect(711,403,92,97)
    s.t(757,415,'KV1',3,True,'center')
    s.t(757,426,'РКН-1М-15',2.5,a='center')
    for y,p,n in [(439,'A1+','3'),(458,'A2−','2')]:
        incoming(s,664,y,711,n,'2.4')
        s.pin(711,y,'KV1:'+('A1' if n=='3' else 'A2'),n,p)
    incoming(s,664,479,711,'3','2.4')
    s.ln(711,479,745,479)
    s.contact(757,479,'',('',''))
    s.ln(769,479,803,479)
    outgoing(s,803,479,817,'34','3.2')
    s.pin(711,479,'KV1:11','3')
    s.pin(803,479,'KV1:14','34')
    s.t(715,486,'11',2.5)
    s.t(799,486,'14',2.5,a='right')
    s.t(757,496,'24 В в норме',2.5,a='center')
    s.t(652,509,'KV1: 24 В DC; окно; задержка 0,5 с.',2.5)
    s.t(652,518,'U< = 22,8 В (−5%); U> = 25,2 В (+5%).',2.5)

    s.heading(28,308,'2.4  Распределительные клеммы XD3 и XD2',280)
    for tag,tx,xbus,labelx in [('XD3',61,39,83),('XD2',198,176,220)]:
        n=tag[-1];branches=BRANCHES[tag];qty=len(branches)
        s.t(tx,322,tag,3,True,'center')
        s.t(labelx,322,('3 · +24 В' if n=='3' else '2 · 0 В'),2.5)
        top=350;step=13
        s.ln(xbus,336,xbus,top+(qty-1)*step,.5)
        s.arr(xbus,336,'down');s.t(xbus+6,338,n+' /2.1',2.5)
        for i,(pins,size,sec) in enumerate(branches):
            y=top+i*step
            s.dot(xbus,y);s.ln(xbus,y,tx+14,y)
            s.term(tx,y,f'{i+1:02d}',pin=f'{tag}:{i+1:02d}a',net=n)
            register(f'{tag}:{i+1:02d}b',n,2)
            s.arr(tx+14,y)
            s.t(labelx,y+1,pins[0]+' /'+sec,2.5)
    s.lines(28,502,['XD3: 8 серых MTU2.5; перемычка 01–08.',
                    'XD2: 11 синих MTU2.5-BL; перемычка 01–10.',
                    'Между XD2:10a и 11a — провод 2,5 мм².',
                    'Стрелка ведёт к первому зажиму ветви; далее — шлейф.',
                    'Местные ответвления выполнять по зажимам аппаратов.'],2.5,8)
    s.lines(28,555,['FU1–FU10: держатель IEK CXF4, AF-CT44-00-K03-004, 10 А.',
                    'Вставки Eaton S505H: T, 5×20 мм; номинал — рядом с FU.',
                    'Круг — зажим; пунктир вокруг FU — держатель; 1 — вход, 2 — выход.',
                    'Пример ссылки: 33 /3.2 — цепь 33, лист 3, участок 3.2.'],2.5,8)
    s.finish()
