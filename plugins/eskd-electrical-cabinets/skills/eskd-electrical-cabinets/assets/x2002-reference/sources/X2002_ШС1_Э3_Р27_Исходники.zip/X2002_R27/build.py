#!/usr/bin/env python3
"""Rebuild the complete R27 E3 from the coordinated connection model."""
import sys,json,re
from pathlib import Path
import fitz
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'src'))
import draw,data
from power import power
from dc_sheet_r26 import dc
from plc_r26 import plc
from drive_r26 import drive
from outputs_r23 import outputs
from field_r25 import field
from comms_r26 import comms
from operator_r26 import operator
from pe_r26 import pe
from terminals_r26 import terminals_external,terminals_internal,COVERAGE,GROUP_ORDER
OUT=ROOT/'output'
for fn in [power,dc,plc,drive,outputs,field,comms,operator,pe,terminals_external,terminals_internal]:fn()
aliases={'A9:OUT.1':'A9:OUT1','A9:OUT.2':'A9:OUT2','A9:OUT.3':'A9:OUT3','A9:IN.5':'A9:IN5','A9:IN.2':'A9:IN2','A9:IN.3':'A9:IN3'}
pins=draw.PINS
mismatch={p:[v['net'],data.PINS[aliases.get(p,p)]] for p,v in pins.items() if aliases.get(p,p) in data.PINS and v['net'] not in ['NC','SCREEN_OUT'] and v['net']!=data.PINS[aliases.get(p,p)]}
old=json.loads((ROOT/'data/connections_R26.json').read_text())
key=lambda e:(e['net'],e['a'].replace(':IN16',':IN'),e['b'].replace(':IN16',':IN'))
oldset={key(e) for e in old};newset={key(e) for e in data.EDGES}
checks={'Сохранены все прежние электрические соединения':oldset<=newset,
'Добавлены только ранее показанные на Э3 экраны W6 и W21':newset-oldset=={('PE','EQS1:шина экранов',c+':экран') for c in ['W6','W21']},
'Выводы чертежей согласованы с моделью':not mismatch,
'KSR1: принятая схема Р26 сохранена':all(pins['KSR1:'+p]['net']=='NC' for p in ['T11','T21']) and all(pins['KSR1:'+p]['net']=='13' for p in ['T12','T22']),
'Ручной сброс T31–K15–K1–T32 сохранён':all(data.net(p)==n for p,n in [('KSR1:T31','16'),('K15:11','16'),('K15:14','14'),('K1:21','14'),('K1:22','15'),('KSR1:T32','15')]),
'Один контакт SB0.1':not any('SB0.2:' in p for e in data.EDGES for p in (e['a'],e['b'])),
'Внутренние провода: 6; 2,5; 0,75; A3 24 AWG; W7a из наличия':all(e['size'] in [6,2.5,.75,.205] or e.get('material','').startswith('W7a') for e in data.EDGES if e['kind']=='Провод'),
'A3: все подключения 24 AWG':all(e['size']==.205 for e in data.EDGES if e['kind']=='Провод' and any(p.startswith('A3:') for p in [e['a'],e['b']])),
'Внутренние фазные цепи белые, N синий, 0 В чёрный':all(e['color']==('белый' if re.fullmatch(r'[ABC]\d+',e['net']) else 'синий' if e['net'].startswith('N') else 'чёрный') for e in data.EDGES if e['kind']=='Провод' and (re.fullmatch(r'[ABC]\d+',e['net']) or e['net'].startswith('N') or e['net']=='2') and e['size']!=.205)}
bounds=[];overlap=[];wire_hits=[]
for sh in draw.SHEETS:
 texts=[t for t in sh.texts if t['layer']=='TEXT' and t['text']]
 for t in texts:
  x0,y0,x1,y1=t['bbox']
  if x0<21 or x1>sh.W-6 or y0<5 or y1>sh.H-5:bounds.append({'sheet':sh.n,**t})
 for i,a in enumerate(texts):
  for b in texts[i+1:]:
   aa=a['bbox'];bb=b['bbox'];dx=min(aa[2],bb[2])-max(aa[0],bb[0]);dy=min(aa[3],bb[3])-max(aa[1],bb[1])
   if dx>.8 and dy>.6:overlap.append({'sheet':sh.n,'a':a['text'],'b':b['text'],'overlap':[dx,dy]})
 for t in texts:
  a,b,c,d=t['bbox'];a+=.35;b+=.25;c-=.35;d-=.25
  for x,y,u,v,layer in sh.segments:
   if layer not in ['WIRE','PE']:continue
   hit=(abs(y-v)<1e-5 and b<y<d and min(c,max(x,u))-max(a,min(x,u))>.8) or (abs(x-u)<1e-5 and a<x<c and min(d,max(y,v))-max(b,min(y,v))>.8)
   if hit:wire_hits.append({'sheet':sh.n,'text':t['text'],'line':[x,y,u,v]})
referr=[r for r in draw.REFERENCES if '.' in r.get('section','') and r['section'] not in draw.SECTIONS]
checks['Межлистовые ссылки на существующие участки']=not referr
required={p for e in data.EDGES for p in (e['a'],e['b']) if p.split(':')[0] in {'XT'+str(i) for i in range(1,12)}|{'XD2','XD3','N1','XL1','XL2','XL3','PE1','PE2','XPE1','ШО1.XT8','ШО1.XT9','ШО1.PE','ШО1.XPE1'}}
checks['Все клеммы показаны на листах 10–11']=not(required-COVERAGE)
checks['Порядок XT1–XT11 сохранён']=GROUP_ORDER==['XT'+str(i) for i in range(1,12)]
final=fitz.open()
for sh in sorted(draw.SHEETS,key=lambda s:s.n):
 with fitz.open(OUT/(sh.name+'.pdf')) as d:final.insert_pdf(d)
final.set_metadata({'title':'X2002.Э3 — Р27. Электрические схемы','subject':'Согласовано со спецификацией Р18, 29.09.2026. Все 11 листов.','author':''})
final.set_toc([[1,f'{sh.n}. {sh.title}',sh.n] for sh in draw.SHEETS])
final.save(OUT/'X2002_ШС1_Э3_Р27_Комплект.pdf',garbage=4,deflate=True)
text='\n'.join(p.get_text() for p in final)
checks['Нет K1 Finder 38.52, обязательных наконечников и старого внутреннего сечения']=all(x not in text for x in ['38.52.7.024.5050','НШВИ','16 мм²','провод 10 мм²','провод 1,5 мм²'])
checks['K1–K9 MR-203.D; WA1 и W7a из имеющихся материалов']='KIPPRIBOR MR-203.D [M01]' in text and text.count('из имеющихся материалов')>=2
checks['11 листов; версия 27']=len(final)==11 and all('Р27' in p.get_text() for p in final)
audits=[]
for sh in draw.SHEETS:
 d=draw.ezdxf.readfile(OUT/(sh.name+'.dxf'));a=d.audit();audits.append({'file':sh.name,'errors':len(a.errors),'fixes':len(a.fixes),'units':d.units})
checks['DXF: миллиметры, ошибок нет']=all(a['errors']==a['fixes']==0 and a['units']==4 for a in audits)
(ROOT/'data/connections_R27.json').write_text(json.dumps(data.EDGES,ensure_ascii=False,indent=2))
(OUT/'Маркировка_выводов.json').write_text(json.dumps(pins,ensure_ascii=False,indent=2))
r=dict(revision='Р27',connections=len(data.EDGES),checks=checks,missing_terminals=sorted(required-COVERAGE),net_mismatches=mismatch,text_out_of_bounds=bounds,text_overlap_candidates=overlap,text_wire_candidates=wire_hits,reference_errors=referr,dxf=audits)
(OUT/'Проверка_Э3_Р27.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in r.items() if k!='dxf'},ensure_ascii=False,indent=2))
if not all(checks.values()) or bounds or overlap or wire_hits:sys.exit(2)
