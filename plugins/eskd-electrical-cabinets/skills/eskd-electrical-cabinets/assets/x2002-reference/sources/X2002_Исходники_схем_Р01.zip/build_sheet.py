#!/usr/bin/env python3
"""X2002: one A4 management logic sheet, PDF and editable SVG.
Dependencies: reportlab, python-docx, Pillow; pdftoppm; DejaVu Sans fonts.
"""
from pathlib import Path
from copy import deepcopy
import sys, html, math, subprocess, zipfile
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from PIL import Image

MM=72/25.4
for tag,file in [('D','DejaVuSans.ttf'),('DB','DejaVuSans-Bold.ttf')]:
    pdfmetrics.registerFont(TTFont(tag,'/usr/share/fonts/truetype/dejavu/'+file))
OUT=Path(sys.argv[1] if len(sys.argv)>1 else 'output').resolve()
OUT.mkdir(parents=True,exist_ok=True)
STEM='X2002_Логическая_схема_и_алгоритм_Р01'

class Drawing:
    def __init__(self,c):self.c=c;self.svg=[]
    def line(self,pts,width=.3,arrow=False):
        self.svg.append('<polyline points="'+' '.join(f'{x},{y}' for x,y in pts)+f'" stroke="black" fill="none" stroke-width="{width}"/>')
        c=self.c;c.setStrokeColor(colors.black);c.setLineWidth(width*MM)
        p=c.beginPath();p.moveTo(pts[0][0]*MM,(297-pts[0][1])*MM)
        for x,y in pts[1:]:p.lineTo(x*MM,(297-y)*MM)
        c.drawPath(p)
        if arrow:
            (x0,y0),(x,y)=pts[-2:];length=math.hypot(x-x0,y-y0);ux=(x-x0)/length;uy=(y-y0)/length
            self.poly([(x,y),(x-2.1*ux-.7*uy,y-2.1*uy+.7*ux),(x-2.1*ux+.7*uy,y-2.1*uy-.7*ux)],fill='black',width=.15)
    def poly(self,pts,fill='white',width=.4):
        self.svg.append('<polygon points="'+' '.join(f'{x},{y}' for x,y in pts)+f'" fill="{fill}" stroke="black" stroke-width="{width}"/>')
        c=self.c;c.setLineWidth(width*MM);c.setFillColor(colors.black if fill=='black' else colors.white)
        p=c.beginPath();p.moveTo(pts[0][0]*MM,(297-pts[0][1])*MM)
        for x,y in pts[1:]:p.lineTo(x*MM,(297-y)*MM)
        p.close();c.drawPath(p,fill=1,stroke=1)
    def rect(self,x,y,w,h,width=.35,fill=False,r=0):
        self.svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" stroke="black" stroke-width="{width}" fill="'+('white' if fill else 'none')+'"/>')
        c=self.c;c.setLineWidth(width*MM);c.setFillColor(colors.white)
        if r:c.roundRect(x*MM,(297-y-h)*MM,w*MM,h*MM,r*MM,fill=fill,stroke=1)
        else:c.rect(x*MM,(297-y-h)*MM,w*MM,h*MM,fill=fill,stroke=1)
    def text(self,x,y,txt,size=10,bold=False,anchor='start',rot=0):
        self.svg.append(f'<text x="{x}" y="{y}" font-family="DejaVu Sans" font-size="{size/MM}" font-weight="'+('bold' if bold else 'normal')+f'" text-anchor="{anchor}"'+(f' transform="rotate({rot},{x},{y})"' if rot else '')+'>'+html.escape(str(txt))+'</text>')
        c=self.c;c.saveState();c.setFillColor(colors.black);c.setFont('DB' if bold else 'D',size);c.translate(x*MM,(297-y)*MM);c.rotate(-rot)
        if anchor=='middle':c.drawCentredString(0,0,str(txt))
        elif anchor=='end':c.drawRightString(0,0,str(txt))
        else:c.drawString(0,0,str(txt))
        c.restoreState()
    def center(self,x,y,txt,width,size=10,bold=False):
        lines=[]
        for s in txt.split('\n'):
            current=''
            for word in s.split():
                candidate=(current+' '+word).strip()
                if current and pdfmetrics.stringWidth(candidate,'DB' if bold else 'D',size)>width*MM:lines.append(current);current=word
                else:current=candidate
            lines.append(current)
        lead=size*1.2/MM
        for i,line in enumerate(lines):self.text(x,y+(i-(len(lines)-1)/2)*lead+size*.34/MM,line,size,bold,'middle')
        return len(lines)*lead
    def box(self,x,y,w,h,txt,size=10.2,kind='process'):
        if kind=='decision':self.poly([(x,y-h/2),(x+w/2,y),(x,y+h/2),(x-w/2,y)])
        else:self.rect(x-w/2,y-h/2,w,h,.4,True,h/2 if kind=='terminal' else 0)
        height=self.center(x,y,txt,w*(.72 if kind=='decision' else 1)-5,size)
        assert height<h-1,(txt,height,h)
    def arrow(self,*pts):self.line(pts,arrow=True)
    def save_svg(self,path):
        Path(path).write_text('<svg xmlns="http://www.w3.org/2000/svg" width="210mm" height="297mm" viewBox="0 0 210 297">\n'+ '\n'.join(self.svg)+'\n</svg>',encoding='utf-8')

def frame(d):
    d.rect(20,5,185,287,.5)
    # Form 1, GOST R 2.104-2023: 185 x 55 mm.
    x,y=20,237
    d.rect(x,y,185,55,.5)
    for xx in [7,17,40,55,65]:d.line([(x+xx,y),(x+xx,y+25)],.25)
    for xx in [17,40,55,65]:d.line([(x+xx,y+25),(x+xx,y+55)],.25)
    for yy in range(5,55,5):d.line([(x,y+yy),(x+65,y+yy)],.25)
    for a,b,txt in [(0,7,'Изм.'),(7,17,'Лист'),(17,40,'№ докум.'),(40,55,'Подп.'),(55,65,'Дата')]:d.center(x+(a+b)/2,y+22.5,txt,b-a-1,6.5)
    for j,role in enumerate(['Разраб.','Пров.','Т. контр.','','Н. контр.','Утв.']):d.text(x+1,y+28.5+j*5,role,6.7)
    d.line([(x+65,y+15),(x+185,y+15)],.35)
    d.line([(x+175,y),(x+175,y+15)],.25);d.line([(x+175,y+5),(x+185,y+5)],.25)
    d.center(x+120,y+7.5,'X2002',105,13)
    d.center(x+180,y+2.5,'Вер.',9,6.5);d.center(x+180,y+10,'01',9,8)
    d.line([(x+135,y+15),(x+135,y+55)],.35)
    d.line([(x+65,y+40),(x+185,y+40)],.35)
    d.center(x+100,y+27.5,'Установка розлива X2002\nБлок-схема управления',65,10)
    for xx in [150,167]:d.line([(x+xx,y+15),(x+xx,y+35)],.25)
    d.line([(x+135,y+20),(x+185,y+20)],.25)
    for xx in [140,145]:d.line([(x+xx,y+20),(x+xx,y+35)],.25)
    d.line([(x+135,y+35),(x+185,y+35)],.25);d.line([(x+155,y+35),(x+155,y+40)],.25)
    for cx,txt in [(142.5,'Лит.'),(158.5,'Масса'),(176,'Масштаб')]:d.center(x+cx,y+17.5,txt,15,6.5)
    d.center(x+145,y+37.5,'Лист 1',19,7.5);d.center(x+170,y+37.5,'Листов 1',28,7.5)
    d.center(x+160,y+47.5,'ООО «Смарт-Инжиниринг»',47,8.2)
    yy=292
    for height,label in [(25,'Инв. № подл.'),(35,'Подп. и дата'),(25,'Взам. инв. №'),(25,'Инв. № дубл.'),(35,'Подп. и дата')]:
        yy-=height;d.rect(8,yy,12,height,.25);d.line([(13,yy),(13,yy+height)],.25);d.text(11.5,yy+height/2,label,6.5,anchor='middle',rot=-90)
    d.rect(20,5,70,14,.35);d.text(55,10.5,'X2002',10,anchor='middle',rot=180)
    d.text(204,295.7,'Формат А4',6.5,anchor='end')

def diagram(d):
    frame(d)
    d.text(95,11,'Установка розлива X2002',11.2,True)
    d.text(95,17.5,'Блок-схема автоматического цикла',8.5)

    # Normal cycle: one vertical sequence, no return lines or connectors.
    x=78
    d.box(x,32,106,14,'Установить тару.\nЗадать массу дозы',10.2,'terminal')
    d.box(x,55,106,18,'При готовности нажать «Пуск».\nПо стабильному весу\nзапомнить массу тары',10.2)
    d.arrow((x,39),(x,46))
    d.box(x,80,106,16,'Отвести лоток.\nОпустить головку в тару',10.2)
    d.arrow((x,64),(x,72))
    d.box(x,106,106,19,'Открыть клапан, затем включить насос.\nГрубый налив — большая подача',10.0)
    d.arrow((x,88),(x,96.5))
    d.box(x,135,106,14,'Точный налив — малая подача',10.2)
    d.arrow((x,115.5),(x,128))
    d.text(82,122.9,'Достигнут порог малой подачи',8.5)
    d.box(x,163,106,20,'Выключить насос, закрыть клапан.\nВыдержать время стекания\nи останова насоса',10.0)
    d.arrow((x,142),(x,153))
    d.text(82,148.5,'Масса отсечки достигнута',8.5)
    d.box(x,189,106,18,'Поднять головку.\nВернуть лоток под головку.\nДождаться стабильного веса',10.0)
    d.arrow((x,173),(x,180))
    d.box(x,212,106,21,'Масса дозы\nв допуске?',10.2,'decision')
    d.arrow((x,198),(x,201.5))
    d.box(x,231,106,9,'Доза завершена. Снять тару',10.2,'terminal')
    d.arrow((x,222.5),(x,226.5));d.text(81,225.4,'Да',8.3)

    # One common stop branch, with no automatic resumption shown.
    d.text(171,164,'На любом этапе',9.2,False,'middle')
    d.box(171,178,60,18,'«Стоп»\nили неисправность',9.6,'terminal')
    d.box(171,212,60,24,'Останов цикла.\nПодача прекращена.\nСообщение оператору',9.4,'terminal')
    d.arrow((171,187),(171,200))
    d.arrow((131,212),(141,212));d.text(132,208.5,'Нет',8.5)

    # Only explanations needed to read this overview.
    d.center(171,40,'Одна позиция розлива.\nДля второй позиции\nалгоритм аналогичен.',59,9.2)
    d.center(171,86,'Масса отсечки — порог\nотключения подачи\nс учётом стекания продукта.',59,9.2)
    d.center(171,129,'Допуск итоговой массы:\nзадание ± 1 кг.',59,9.2)

def docx_from_pdf_image(png):
    from docx import Document
    from docx.shared import Mm, Pt
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    doc=Document();doc.core_properties.title='X2002. Блок-схема управления';doc.core_properties.author=''
    doc.core_properties.subject='Один лист А4';doc.core_properties.comments='Редактируемый векторный исходник схемы — SVG в архиве исходников.'
    s=doc.sections[0];s.page_width=Mm(210);s.page_height=Mm(297)
    s.top_margin=Mm(0);s.bottom_margin=Mm(0);s.left_margin=Mm(0);s.right_margin=Mm(0);s.header_distance=Mm(0);s.footer_distance=Mm(0)
    p=s.header.paragraphs[0];p.paragraph_format.line_spacing=Pt(1)
    inline=p.add_run().add_picture(str(png),width=Mm(210),height=Mm(297))._inline
    a=OxmlElement('wp:anchor')
    for key,val in [('distT','0'),('distB','0'),('distL','0'),('distR','0'),('simplePos','0'),('relativeHeight','0'),('behindDoc','1'),('locked','0'),('layoutInCell','1'),('allowOverlap','1')]:a.set(key,val)
    e=OxmlElement('wp:simplePos');e.set('x','0');e.set('y','0');a.append(e)
    for axis in ['H','V']:
        e=OxmlElement('wp:position'+axis);e.set('relativeFrom','page');o=OxmlElement('wp:posOffset');o.text='0';e.append(o);a.append(e)
    a.append(deepcopy(inline.find(qn('wp:extent'))))
    e=OxmlElement('wp:effectExtent')
    for key in ['l','t','r','b']:e.set(key,'0')
    a.append(e);a.append(OxmlElement('wp:wrapNone'))
    for tag in ['wp:docPr','wp:cNvGraphicFramePr','a:graphic']:a.append(deepcopy(inline.find(qn(tag))))
    inline.getparent().replace(inline,a)
    p=doc.add_paragraph();p.paragraph_format.line_spacing=Pt(1);p.paragraph_format.space_after=Pt(0);p.add_run('').font.size=Pt(1)
    doc.save(OUT/(STEM+'.docx'))

if __name__=='__main__':
    pdf=OUT/(STEM+'.pdf');svg=OUT/'X2002_Блок_схема_управления.svg'
    c=canvas.Canvas(str(pdf),pagesize=(210*MM,297*MM),pageCompression=1)
    c.setTitle('X2002. Блок-схема логики управления установкой розлива');c.setAuthor('');c.setSubject('Один лист А4')
    d=Drawing(c);diagram(d);d.save_svg(svg);c.showPage();c.save()
    qa=OUT/'_qa';qa.mkdir(exist_ok=True)
    subprocess.run(['pdftoppm','-r','160','-singlefile','-png',str(pdf),str(qa/'sheet')],check=True)
    with Image.open(qa/'sheet.png') as im:im.verify()
    docx_from_pdf_image(qa/'sheet.png')
    archive=OUT/'X2002_Исходники_схем_Р01.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        z.write(svg,svg.name);z.write(Path(__file__),'build_sheet.py')
        z.writestr('README.txt','X2002. Блок-схема управления, один лист А4.\nSVG — редактируемая векторная схема.\nДля печати используйте PDF, масштаб 100%.\nИсходник: build_sheet.py. Python 3; reportlab, python-docx, Pillow; Poppler; DejaVu Sans.\n')
    print(pdf)
