X2002. Блок-схема управления, один лист А4.
SVG — редактируемая векторная схема.
Для печати используйте PDF, масштаб 100%.
Исходник: build_sheet.py. Python 3; reportlab, python-docx, Pillow; Poppler; DejaVu Sans.
